# HEXZAM

Reconnaissance musicale Android, **noir et blanc**, un projet **CENTRAL-HEX**. Un appui : HEXZAM écoute et trouve le titre, comme Shazam.

> ⚠️ Écrit sans pouvoir être compilé ni testé (pas d'Android SDK à disposition). Attendez-vous à corriger quelques erreurs au premier build. La qualité de reconnaissance locale n'est pas mesurée, et l'API AudD n'a pas été appelée en vrai.

## Structure (trois pages, glissez de gauche à droite)
- **Bibliothèque** : Titres, Artistes, Favoris, Playlists pour vous (automatiques : cette semaine, ce mois-ci, découvertes en ligne…), Ma musique locale, **Explorer** (vos artistes et genres préférés), **Récents** en grille de pochettes avec menu ⋮.
- **Écouter** (page centrale) : grand bouton à cercles concentriques. Il ouvre un écran d'écoute plein écran (cercles qui pulsent avec le son, ✕ pour annuler), puis l'écran du titre.
- **Les Tops** : Top 50 par pays (France, USA, Maroc, Algérie, Sénégal…) et Albums populaires, depuis le flux public d'Apple Music (sans clé). Ce ne sont **pas** les classements de Shazam.
- **Paramètres** (⚙ en haut à gauche) : conseils, barre de notification, pop-up flottant, Auto-HEXZAM, application de musique par défaut, préférences, reconnaissance en ligne, données, CENTRAL-HEX, aide (Info, FAQ), compte.

## Fonctions
- **Reconnaissance de n'importe quelle musique** via le service **AudD** (votre clé API, à coller dans Paramètres). Aucune musique à ajouter. Reconnaissance **locale** d'abord (votre bibliothèque facultative, sans réseau).
- **Écran du titre** : pochette (noir et blanc ou couleur), extrait 30 s, favori ♥, ouverture dans l'application de musique choisie (Spotify, YouTube, Apple Music, Deezer), paroles (recherche Genius), partage, page du titre.
- **Hors-ligne** : sans réseau, l'extrait est gardé sur le téléphone et reconnu au retour de la connexion (notification de résultat).
- **Barre de notification** avec bouton Écouter, **tuile** des réglages rapides, **widget** d'écran d'accueil, **pop-up flottant** déplaçable (autorisation « affichage par-dessus les autres applications »), **Auto-HEXZAM** (écoute continue en arrière-plan avec notification et bouton Arrêter), **Reconnaître au démarrage**.
- Historique avec recherche, export CSV, favoris, vibration, thème Noir / Blanc / Système, durée d'écoute 5 / 8 / 12 s, exigence Souple / Normal / Strict.
- Section **CENTRAL-HEX** : communauté (canal WhatsApp), partage de l'application.

## Pas inclus (et pourquoi)
Classements Shazam (Top mondial, Radio Spins, genres), compte et synchronisation, reconnaissance du son interne du téléphone, paroles synchronisées, concerts. Ils exigent des données ou des accords que HEXZAM n'a pas.

## Obtenir l'APK
1. Mettez le projet (ou `Hexzam.zip`) à la racine d'un dépôt GitHub, avec `.github/workflows/build.yml`.
2. **Actions** → **Build HEXZAM (Android)** → **Run workflow**.
3. Quand le run est vert : **Releases** → `app-debug.apk`.

## Premiers pas
1. Créez une clé sur audd.io (quota d'essai, puis éventuellement payant : vérifiez leur site) et collez-la : Paramètres → *Reconnaissance en ligne*.
2. Page centrale → touchez le bouton, autorisez le micro.

## Vie privée
Micro seulement quand vous touchez le bouton, ou pendant l'écoute continue que vous activez. Aucun compte, publicité ni télémétrie. Historique, favoris, empreintes, extraits en attente, clé et réglages restent dans le stockage privé. Réseau : AudD (extrait audio, si activé), Apple (Tops, pochettes) et Spotify/Apple (pochettes et extraits renvoyés par AudD).
