# HEXZAM

Reconnaissance musicale Android, **noir et blanc**, un projet **CENTRAL-HEX**. Touchez le bouton hexagonal : HEXZAM écoute quelques secondes, calcule une empreinte sonore et vous donne le titre.

> ⚠️ Écrit sans pouvoir être compilé ni testé (pas d'Android SDK à disposition). Attendez-vous à corriger quelques erreurs au premier build, et à régler la reconnaissance à l'usage.

## Deux moteurs
1. **Local (par défaut)** : empreintes de type « constellation » (spectrogramme → pics → paires hachées → vote sur le décalage temporel), calculées sur l'appareil à partir de **votre bibliothèque** (onglet BIBLIO). Aucun réseau. Ne reconnaît que les morceaux que vous avez ajoutés.
2. **En ligne (optionnel, désactivé par défaut)** : si la recherche locale échoue, l'extrait enregistré est envoyé au service **AudD** (`api.audd.io`) avec **votre** clé API. Réglages → *Reconnaissance en ligne*. Rien d'autre n'est envoyé.

## Fonctions
- Bouton d'écoute animé (anneaux pendant l'écoute, rotation pendant l'analyse), durée 5 / 8 / 12 s
- Résultat : titre, artiste, album, origine (LOCAL / EN LIGNE) ; ouverture dans Spotify, YouTube, Apple Music, Deezer ; partage
- Historique avec date et origine, suppression, export CSV
- Bibliothèque : ajout d'un dossier de musique (sélecteur système, lecture seule, fichiers non copiés), progression, arrêt, retrait par morceau
- Réglages : thème Noir / Blanc / Système, durée d'écoute, exigence (Souple / Normal / Strict), vibration, reconnaissance en ligne + clé, données, section **CENTRAL-HEX** (communauté, partage), à propos

## Obtenir l'APK
1. Mettez le projet (ou `Hexzam.zip`) à la racine d'un dépôt GitHub, avec `.github/workflows/build.yml`.
2. **Actions** → **Build HEXZAM (Android)** → **Run workflow**.
3. Quand le run est vert : **Releases** → `app-debug.apk` → installez.

## Premiers pas
1. Onglet **BIBLIO** → *Ajouter un dossier de musique* (l'analyse prend quelques secondes par morceau ; formats mp3, m4a, aac, flac, ogg, opus, wav).
2. Onglet **ÉCOUTER** → touchez l'hexagone (autorisez le micro), approchez le téléphone d'un morceau de votre bibliothèque.
3. Pour tout reconnaître : Réglages → activez *en ligne* et collez votre clé AudD.

## Vie privée
Micro uniquement quand vous touchez le bouton, application au premier plan. Aucun compte, publicité ni télémétrie. Historique, empreintes, clé et réglages restent dans le stockage privé de l'application. La permission INTERNET n'est utilisée que si vous activez la reconnaissance en ligne.

## Limites connues
Reconnaissance locale sensible au bruit (fiable si l'extrait est net, ≥ 8 s) ; seuls les 6 premières minutes de chaque morceau sont indexées ; la qualité n'a pas été mesurée ; l'API AudD est appelée d'après sa documentation, sans test.

## Structure
```
Fingerprint.kt  FFT, pics, hachage        Matcher.kt   vote sur le décalage
Audio.kt        décodage, rééchantillonnage 8 kHz, WAV    Library.kt   indexation
Recognizer.kt   enregistrement + local puis en ligne      Online.kt    client AudD
Db.kt           SQLite privée               Prefs.kt / Theme.kt   réglages, noir & blanc
HexButton.kt, Ui.kt, *Screen.kt, MainActivity.kt          interface
```
