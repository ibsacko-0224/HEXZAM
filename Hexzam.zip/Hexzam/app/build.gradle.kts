plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hexzam.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hexzam.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Clé AudD fournie à la compilation par une variable d'environnement (secret GitHub), jamais écrite dans le code.
        buildConfigField("String", "AUDD_TOKEN", "\"${System.getenv("AUDD_TOKEN") ?: ""}\"")
        buildConfigField("String", "JAMENDO_ID", "\"${System.getenv("JAMENDO_CLIENT_ID") ?: ""}\"")
    }
    buildFeatures { buildConfig = true }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Aucune dépendance : uniquement l’API Android.
