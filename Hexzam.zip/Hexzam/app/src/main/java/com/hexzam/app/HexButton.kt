package com.hexzam.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Gros bouton hexagonal : anneaux qui s'étendent pendant l'écoute, rotation continue pendant l'analyse. */
class HexButton(context: Context, private val fg: Int, private val bg: Int) : View(context) {
    enum class State { IDLE, LISTENING, ANALYZING }

    var state = State.IDLE
        set(v) { field = v; invalidate() }
    private var level = 0f
    private var smooth = 0f
    private var phase = 0f
    private val path = Path()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; style = Paint.Style.STROKE; strokeWidth = context.dp(2).toFloat() }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; smooth += (level - smooth) * 0.25f; invalidate() }
    }

    fun setLevel(l: Float) { level = l.coerceIn(0f, 1f) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun hex(c: Canvas, cx: Float, cy: Float, r: Float, paint: Paint) {
        path.reset()
        for (i in 0 until 6) {
            val a = (-90 + 60 * i) * PI / 180
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, paint)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.58f
        if (state == State.IDLE) {
            ring.alpha = 70
            hex(c, cx, cy, r * 1.22f, ring)
            ring.alpha = 35
            hex(c, cx, cy, r * 1.42f, ring)
        } else if (state == State.LISTENING) {
            for (i in 0 until 3) {
                val p = (phase + i / 3f) % 1f
                ring.alpha = (230 * (1f - p)).toInt()
                hex(c, cx, cy, r * (1.05f + 0.7f * p), ring)
            }
        }
        val scale = if (state == State.LISTENING) 1f + 0.16f * smooth else 1f
        c.save()
        if (state == State.ANALYZING) c.rotate(phase * 60f, cx, cy)   // 60° = symétrie de l'hexagone : boucle sans à-coup
        hex(c, cx, cy, r * scale, fill)
        c.restore()
        glyph.textSize = r * 0.95f
        c.drawText("H", cx, cy + glyph.textSize * 0.34f, glyph)
    }
}
