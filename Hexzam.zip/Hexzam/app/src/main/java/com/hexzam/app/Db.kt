package com.hexzam.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Track(val id: Long, val title: String, val artist: String, val album: String, val hashes: Int)
data class HistoryItem(val id: Long, val title: String, val artist: String, val album: String, val source: String, val link: String?, val ts: Long)

/** Base privée : bibliothèque (empreintes) et historique. Tout reste sur l'appareil. */
class HexDb(context: Context) : SQLiteOpenHelper(context.applicationContext, "hexzam.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tracks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, artist TEXT NOT NULL, album TEXT NOT NULL, uri TEXT NOT NULL UNIQUE, added INTEGER NOT NULL, hashes INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE fp(hash INTEGER NOT NULL, track INTEGER NOT NULL, t INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX fp_hash ON fp(hash)")
        db.execSQL("CREATE INDEX fp_track ON fp(track)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, artist TEXT NOT NULL, album TEXT NOT NULL, source TEXT NOT NULL, link TEXT, ts INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    // ───── Bibliothèque
    fun hasTrack(uri: String): Boolean =
        readableDatabase.rawQuery("SELECT 1 FROM tracks WHERE uri = ?", arrayOf(uri)).use { it.moveToFirst() }

    fun addTrack(title: String, artist: String, album: String, uri: String, fp: IntArray): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues()
            cv.put("title", title); cv.put("artist", artist); cv.put("album", album)
            cv.put("uri", uri); cv.put("added", System.currentTimeMillis()); cv.put("hashes", fp.size / 2)
            val id = db.insertOrThrow("tracks", null, cv)
            val st = db.compileStatement("INSERT INTO fp(hash, track, t) VALUES(?, ?, ?)")
            var i = 0
            while (i < fp.size) {
                st.clearBindings()
                st.bindLong(1, fp[i].toLong()); st.bindLong(2, id); st.bindLong(3, fp[i + 1].toLong())
                st.executeInsert()
                i += 2
            }
            db.setTransactionSuccessful()
            return id
        } finally {
            db.endTransaction()
        }
    }

    fun tracks(): List<Track> {
        val out = ArrayList<Track>()
        readableDatabase.rawQuery("SELECT id, title, artist, album, hashes FROM tracks ORDER BY artist COLLATE NOCASE, title COLLATE NOCASE", null).use {
            while (it.moveToNext()) out.add(Track(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getInt(4)))
        }
        return out
    }

    fun track(id: Long): Track? =
        readableDatabase.rawQuery("SELECT id, title, artist, album, hashes FROM tracks WHERE id = ?", arrayOf(id.toString())).use {
            if (it.moveToFirst()) Track(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getInt(4)) else null
        }

    fun deleteTrack(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("fp", "track = ?", arrayOf(id.toString()))
            db.delete("tracks", "id = ?", arrayOf(id.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun clearLibrary() {
        val db = writableDatabase
        db.beginTransaction()
        try { db.delete("fp", null, null); db.delete("tracks", null, null); db.setTransactionSuccessful() } finally { db.endTransaction() }
    }

    /** Appelle [fn] pour chaque empreinte de la base dont le hash figure dans [hashes]. */
    fun forEachHit(hashes: IntArray, fn: (hash: Int, track: Long, t: Int) -> Unit) {
        val db = readableDatabase
        var i = 0
        while (i < hashes.size) {
            val end = minOf(i + 400, hashes.size)
            val list = (i until end).joinToString(",") { hashes[it].toString() }   // entiers : pas d'injection possible
            db.rawQuery("SELECT hash, track, t FROM fp WHERE hash IN ($list)", null).use {
                while (it.moveToNext()) fn(it.getInt(0), it.getLong(1), it.getInt(2))
            }
            i = end
        }
    }

    // ───── Historique
    fun addHistory(title: String, artist: String, album: String, source: String, link: String?) {
        val cv = ContentValues()
        cv.put("title", title); cv.put("artist", artist); cv.put("album", album)
        cv.put("source", source); cv.put("link", link); cv.put("ts", System.currentTimeMillis())
        writableDatabase.insert("history", null, cv)
    }

    fun history(): List<HistoryItem> {
        val out = ArrayList<HistoryItem>()
        readableDatabase.rawQuery("SELECT id, title, artist, album, source, link, ts FROM history ORDER BY ts DESC", null).use {
            while (it.moveToNext()) out.add(HistoryItem(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4), it.getString(5), it.getLong(6)))
        }
        return out
    }

    fun deleteHistory(id: Long) { writableDatabase.delete("history", "id = ?", arrayOf(id.toString())) }
    fun clearHistory() { writableDatabase.delete("history", null, null) }
}
