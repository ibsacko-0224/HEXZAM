package com.hexzam.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.math.sqrt

sealed class Outcome {
    data class Found(val title: String, val artist: String, val album: String, val source: String, val link: String?) : Outcome()
    object NotFound : Outcome()
    object Cancelled : Outcome()
    data class Failed(val message: String) : Outcome()
}

class Recognizer(private val ctx: Context, private val db: HexDb) {

    /** À appeler hors du thread principal. [onPhase] reçoit « listening », « analyzing » ou « online ». */
    fun run(seconds: Int, onLevel: (Float) -> Unit, onPhase: (String) -> Unit, cancelled: () -> Boolean): Outcome {
        val rate = 44100
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return Outcome.Failed("Micro indisponible sur cet appareil.")
        val online = Prefs.online(ctx) && Prefs.token(ctx).isNotBlank()
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, rate))
        } catch (e: Exception) { return Outcome.Failed("Impossible d’ouvrir le micro.") }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return Outcome.Failed("Impossible d’ouvrir le micro (utilisé par une autre application ?).") }

        val fb = FloatBuf()
        val raw = ByteArrayOutputStream()          // conservé seulement si la reconnaissance en ligne est active
        val rs = StreamResampler(rate) { fb.add(it) }
        val buf = ShortArray(2048)
        val total = rate * seconds
        var got = 0
        var energy = 0.0
        onPhase("listening")
        try {
            rec.startRecording()
            while (got < total && !cancelled()) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) break
                var sum = 0.0
                for (i in 0 until n) {
                    val s = buf[i].toInt()
                    rs.push(s / 32768f)
                    sum += s.toDouble() * s
                    if (online) { raw.write(s and 0xFF); raw.write((s shr 8) and 0xFF) }
                }
                got += n
                energy += sum
                onLevel(minOf(1f, (sqrt(sum / n) / 6000.0).toFloat()))
            }
        } finally {
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
        }
        if (cancelled()) return Outcome.Cancelled
        if (got < rate * 2) return Outcome.Failed("Enregistrement trop court.")
        if (sqrt(energy / got) < 80.0) return Outcome.Failed("Aucun son détecté : rapprochez le téléphone de la source.")

        onPhase("analyzing")
        val hashes = Fingerprint.hashes(fb.a, fb.n)
        val hit = Matcher.match(db, hashes, Prefs.minVotes(ctx))
        if (hit != null) {
            val t = db.track(hit.trackId)
            if (t != null) return Outcome.Found(t.title, t.artist, t.album, "LOCAL", null)
        }
        if (!online) return Outcome.NotFound

        onPhase("online")
        return try {
            val r = Online.recognize(Prefs.token(ctx), Wav.encode(raw.toByteArray(), rate))
            if (r == null) Outcome.NotFound else Outcome.Found(r.title, r.artist, r.album, "EN LIGNE", r.link)
        } catch (e: IOException) {
            Outcome.Failed("Reconnaissance en ligne impossible : ${e.message ?: "réseau indisponible"}")
        }
    }
}
