package com.hexzam.app

import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import java.io.IOException

/** Top 50 d'un pays (chansons ou albums), via le flux public d'Apple. */
class ChartScreen(app: MainActivity, private val kind: String, private var country: String) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)
    private lateinit var frameView: LinearLayout

    private fun countryName() = Charts.countries.firstOrNull { it.first == country }?.second ?: country
    private fun heading() = (if (kind == "songs") "Top 50 · " else "Albums populaires · ") + countryName()

    init {
        list.orientation = LinearLayout.VERTICAL
        val change = app.icon("🌍") {
            val names = Charts.countries.map { it.second }.toTypedArray()
            AlertDialog.Builder(app).setTitle("Pays").setItems(names) { _, i -> country = Charts.countries[i].first; load() }.show()
        }
        view = app.frame(heading(), app.scroll(list), change)
        frameView = view as LinearLayout
        load()
    }

    private fun load() {
        ((frameView.getChildAt(0) as LinearLayout).getChildAt(1) as android.widget.TextView).text = heading()
        list.removeAllViews()
        list.addView(app.tv("Chargement…", 15f, p.mute).apply { gravity = Gravity.CENTER; setPadding(0, app.dp(48), 0, 0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val c = country
        app.bg.execute {
            val result = try { Result.success(Charts.fetch(c, kind)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread { if (c == country) render(result) }
        }
    }

    private fun render(r: Result<List<Charts.Item>>) {
        list.removeAllViews()
        val items = r.getOrNull()
        if (items == null) {
            list.addView(app.tv("Impossible de charger le classement (${r.exceptionOrNull()?.message ?: "réseau"}).", 15f, p.mute).apply { setPadding(app.dp(24), app.dp(40), app.dp(24), app.dp(12)) })
            list.addView(app.flatButton("Réessayer", p, true) { load() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(24), 0, app.dp(24), 0) })
            return
        }
        for (it in items) {
            val row = LinearLayout(app)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(app.dp(16), app.dp(10), app.dp(16), app.dp(10))
            row.addView(app.tv("${it.rank}", 15f, p.mute, bold = true, mono = true), LinearLayout.LayoutParams(app.dp(34), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(app.thumb(it.cover, 56))
            val col = LinearLayout(app)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(app.dp(14), 0, 0, 0)
            col.addView(app.tv(it.title, 16f, p.fg, bold = true))
            col.addView(app.tv(it.artist, 13f, p.mute))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { _ ->
                app.push(TrackScreen(app, TrackInfo(it.title, it.artist, if (kind == "albums") it.title else "", "TOP · " + countryName().uppercase(), it.url, it.cover, null, it.genre, null)))
            }
            list.addView(row)
            list.addView(app.hairline(p))
        }
    }
}
