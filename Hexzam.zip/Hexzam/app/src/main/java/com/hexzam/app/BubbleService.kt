package com.hexzam.app

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/** Pop-up HEXZAM : bouton flottant déplaçable, visible par-dessus les autres applications. Un appui lance l'écoute. */
class BubbleService : Service() {
    companion object {
        val running = AtomicBoolean(false)
        const val ACTION_STOP = "com.hexzam.app.STOP_BUBBLE"
        const val ID = 12
    }

    private var wm: WindowManager? = null
    private var bubble: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = Notifier.bubbleNotification(this)
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(ID, n)
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (running.compareAndSet(false, true)) addBubble()
        return START_NOT_STICKY
    }

    private fun addBubble() {
        val manager = getSystemService(WindowManager::class.java)
        wm = manager
        val d = resources.displayMetrics.density
        val size = (58 * d).toInt()
        val b = TextView(this)
        b.text = "H"
        b.gravity = Gravity.CENTER
        b.textSize = 24f
        b.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        b.setTextColor(Color.BLACK)
        b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke((2 * d).toInt(), Color.BLACK) }
        b.elevation = 8 * d
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (220 * d).toInt() }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm?.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) launch(); true }
                else -> false
            }
        }
        manager.addView(b, lp)
        bubble = b
    }

    private fun launch() {
        startActivity(Intent(this, MainActivity::class.java).putExtra("autostart", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    override fun onDestroy() {
        bubble?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
        bubble = null
        running.set(false)
        getSystemService(NotificationManager::class.java).cancel(ID)
        super.onDestroy()
    }
}
