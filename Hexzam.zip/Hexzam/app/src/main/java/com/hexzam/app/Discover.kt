package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.IOException

private fun MainActivity.chipsRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
    val p = palette
    val hs = HorizontalScrollView(this)
    hs.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(this)
    row.setPadding(dp(12), dp(12), dp(12), dp(4))
    labels.forEachIndexed { i, l ->
        val on = i == selected
        val t = tv(l.uppercase(), 12f, if (on) p.bg else p.fg, bold = true, mono = true)
        t.setPadding(dp(14), dp(9), dp(14), dp(9))
        t.background = GradientDrawable().apply { setColor(if (on) p.fg else p.bg); setStroke(dp(1), p.fg) }
        t.setOnClickListener { onPick(i) }
        row.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
    }
    hs.addView(row)
    return hs
}

/** Nouveautés du monde entier par genre, affichées en grille de cartes comme dans Spotify. */
class NewReleasesScreen(app: MainActivity) : Screen(app) {
    override val view: View
    private val chipHost = LinearLayout(app)
    private val list = LinearLayout(app)
    private var selected = 0
    private var genres: List<Deezer.Genre> = emptyList()

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        chipHost.orientation = LinearLayout.VERTICAL
        col.addView(chipHost)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Nouveautés", app.scroll(col))
        drawChips()
        load()
        app.bg.execute {
            val g = try { Deezer.genres() } catch (e: IOException) { emptyList() }
            app.runOnUiThread { genres = g; drawChips() }
        }
    }

    private fun drawChips() {
        chipHost.removeAllViews()
        val labels = listOf("Tous les genres") + genres.map { it.name }
        chipHost.addView(app.chipsRow(labels, selected) { selected = it; drawChips(); load() })
    }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val my = selected
        val gid = if (my == 0) 0L else genres.getOrNull(my - 1)?.id ?: 0L
        app.bg.execute {
            val r = try { Result.success(Deezer.releases(gid, 60)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != selected) return@runOnUiThread
                list.removeAllViews()
                val albums = r.getOrNull()
                if (albums == null) { list.addView(app.centered("Impossible de charger les nouveautés (${r.exceptionOrNull()?.message ?: "réseau"}).")); return@runOnUiThread }
                if (albums.isEmpty()) { list.addView(app.centered("Aucune nouveauté pour ce genre pour l’instant.")); return@runOnUiThread }
                val cards = albums.sortedByDescending { it.date ?: "" }.map { a ->
                    Card(a.cover, a.title, a.artist, "ALBUM · ${prettyDate(a.date)}".trim(), { app.push(AlbumScreen(app, a)) })
                }
                val w = (app.resources.displayMetrics.widthPixels - app.dp(32) - app.dp(12)) / 2
                val grid = LinearLayout(app)
                grid.orientation = LinearLayout.VERTICAL
                grid.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(32))
                for (pair in cards.chunked(2)) {
                    val row = LinearLayout(app)
                    pair.forEachIndexed { i, c -> row.addView(app.cardView(c, w), LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (i > 0) leftMargin = app.dp(12) }) }
                    grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = app.dp(18) })
                }
                list.addView(grid)
            }
        }
    }
}

/**
 * Un pays, façon Spotify. Du plus frais au moins frais :
 *  1. « Nouveautés de vos artistes » (artistes suivis : vraies sorties, triées par date) ;
 *  2. « Nouvelles sorties · pays » (MusicBrainz, base communautaire) ;
 *  3. « Nouveautés » du genre ou de l'Afrique (Deezer, monde / continent) ;
 *  4. « Les plus écoutés » (Apple Music, si le pays en a un) ;
 *  5. « Titres populaires » du pays (recherche par mots-clés : pas des nouveautés).
 */
class CountryScreen(app: MainActivity, private val code: String) : Screen(app) {
    override val view: View
    private val chipHost = LinearLayout(app)
    private val list = LinearLayout(app)
    private val name = Countries.name(code)
    private val africa = setOf("dz","ao","bj","bw","bf","bi","cm","cv","cf","td","km","cg","cd","ci","dj","eg","gq","er","sz","et","ga","gm","gh","gn","gw","ke","ls","lr","ly","mg","mw","ml","mr","mu","ma","mz","na","ne","ng","rw","st","sn","sc","sl","so","za","ss","sd","tz","tg","tn","ug","zm","zw")

    // libellé, mots-clés de recherche, filtre MusicBrainz, expression de genre Deezer
    private class Style(val label: String, val kw: String, val tags: String?, val genre: String?)
    private val styles: List<Style> = buildList {
        add(Style("Tous", "", null, if (code in africa) "afric" else null))
        add(Style("Rap / Hip-Hop", "rap hip hop", "rap OR \"hip hop\" OR hip-hop", "rap"))
        add(Style("Afro", "afro", "afrobeat OR afro OR african", "afric"))
        add(Style("Pop", "pop", "pop", "pop"))
        add(Style("R&B", "r&b", "r&b OR rnb", "r&b|rnb|soul"))
        if (code == "gn") add(Style("Mamaya", "mamaya", "mamaya OR mandingue OR mandinka", "afric"))
        add(Style("Traditionnel", "traditionnel", "folk OR traditional OR world", "afric|world|monde"))
    }
    private var selected = 0
    private var seq = 0

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        chipHost.orientation = LinearLayout.VERTICAL
        col.addView(chipHost)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, app.dp(32))
        col.addView(list)
        view = app.frame(name, app.scroll(col), app.icon("☆") { app.push(MyArtistsScreen(app)) })
        drawChips()
        load()
    }

    private fun drawChips() {
        chipHost.removeAllViews()
        chipHost.addView(app.chipsRow(styles.map { it.label }, selected) { selected = it; drawChips(); load() })
    }

    private fun <T> safe(f: () -> T): Result<T> = try { Result.success(f()) } catch (e: IOException) { Result.failure(e) }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val my = ++seq
        val st = styles[selected]
        val days = Prefs.releaseDays(app)
        app.bg.execute {
            val mine = safe { Follows.releases(app) }
            val mb = safe { MusicBrainz.recent(code, days, st.tags) }
            val genreName = st.genre?.let { rx -> safe { Deezer.genres() }.getOrNull()?.firstOrNull { Regex(rx, RegexOption.IGNORE_CASE).containsMatchIn(it.name) } }
            val fresh = genreName?.let { g -> safe { Deezer.releases(g.id, 40) } }
            val chart = if (selected == 0) safe { Charts.fetch(code, "songs") } else null
            val pop = safe { Deezer.search(("$name ${st.kw}").trim(), 30) }
            app.runOnUiThread {
                if (my != seq) return@runOnUiThread
                render(mine.getOrNull() ?: emptyList(), mb, genreName, fresh, chart, pop, days)
            }
        }
    }

    private fun note(text: String) = list.addView(app.tv(text, 12f, app.palette.mute).apply { setPadding(app.dp(16), app.dp(14), app.dp(16), 0) })

    private fun render(mine: List<Deezer.Album>, mb: Result<List<MusicBrainz.Release>>, genre: Deezer.Genre?, fresh: Result<List<Deezer.Album>>?,
                       chart: Result<List<Charts.Item>>?, pop: Result<List<Deezer.Track>>, days: Int) {
        list.removeAllViews()

        // 1. Artistes suivis
        if (mine.isNotEmpty()) {
            val cards = Follows.toCards(app, mine.take(60), days)
            app.carousel(list, "Nouveautés de vos artistes", cards) { app.push(CardsGridScreen(app, "Nouveautés de vos artistes", cards)) }
        } else {
            list.addView(app.flatButton("☆ Suivre des artistes pour voir leurs nouveautés", app.palette) { app.push(MyArtistsScreen(app)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(16), app.dp(16), 0) })
            note("C’est la façon fiable d’avoir les vraies sorties de $name : aucune source gratuite ne les publie toutes.")
        }

        // 2. MusicBrainz
        val releases = mb.getOrNull()
        if (releases != null && releases.isNotEmpty()) {
            val cards = releases.map { r ->
                Card(r.cover, r.title, r.artist, "${r.type.uppercase()} · ${prettyDate(r.date)}", {
                    app.push(TrackScreen(app, TrackInfo(r.title, r.artist, r.title, "NOUVEAUTÉ · ${name.uppercase()}", null, r.cover, null, null, null)))
                })
            }
            app.carousel(list, "Nouvelles sorties · $name", cards) { app.push(CardsGridScreen(app, "Nouvelles sorties · $name", cards)) }
        } else {
            note(if (releases == null) "Sorties de $name : service indisponible (${mb.exceptionOrNull()?.message ?: "réseau"})."
                 else "Aucune sortie répertoriée pour $name ces $days derniers jours dans MusicBrainz (base libre, remplie par sa communauté).")
        }

        // 3. Nouveautés du genre / de l'Afrique (Deezer)
        val albums = fresh?.getOrNull()
        if (genre != null && albums != null && albums.isNotEmpty()) {
            val cards = albums.sortedByDescending { it.date ?: "" }.map { a ->
                Card(a.cover, a.title, a.artist, "ALBUM · ${prettyDate(a.date)}".trim(), { app.push(AlbumScreen(app, a)) })
            }
            app.carousel(list, "Nouveautés · ${genre.name}", cards) { app.push(CardsGridScreen(app, "Nouveautés · ${genre.name}", cards)) }
            note("Sélection mondiale du genre (Deezer), pas limitée à $name.")
        }

        // 4. Classement Apple Music
        val items = chart?.getOrNull()
        if (items != null && items.isNotEmpty()) {
            val cards = items.map { it ->
                Card(it.cover, it.title, it.artist, "N°${it.rank}", {
                    app.push(TrackScreen(app, TrackInfo(it.title, it.artist, "", "TOP · ${name.uppercase()}", it.url, it.cover, null, it.genre, null)))
                })
            }
            app.carousel(list, "Les plus écoutés", cards) { app.push(CardsGridScreen(app, "Top · $name", cards)) }
        } else if (chart != null) note("Pas de classement officiel Apple Music pour $name.")

        // 5. Titres populaires (pas des nouveautés)
        val tracks = pop.getOrNull()
        if (tracks != null && tracks.isNotEmpty()) {
            val cards = tracks.mapIndexed { i, t -> t.toCard(app, tracks, i) }
            app.carousel(list, "Titres populaires", cards) { app.push(CardsGridScreen(app, "Titres populaires · $name", cards)) }
            note("Recherche par mots-clés (Deezer) : titres connus, pas forcément récents.")
        }
    }
}
