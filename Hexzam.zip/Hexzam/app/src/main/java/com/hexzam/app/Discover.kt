package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.IOException

private fun MainActivity.chipsRow(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
    val p = palette
    val hs = HorizontalScrollView(this)
    hs.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(this)
    row.setPadding(dp(12), dp(12), dp(12), dp(4))
    labels.forEachIndexed { i, l ->
        val on = i == selected
        val t = tv(l.uppercase(), 12f, if (on) p.bg else p.fg, bold = true, mono = true)
        t.setPadding(dp(14), dp(9), dp(14), dp(9))
        t.background = GradientDrawable().apply { setColor(if (on) p.fg else p.bg); setStroke(dp(1), p.fg) }
        t.setOnClickListener { onPick(i) }
        row.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
    }
    hs.addView(row)
    return hs
}

/** Nouveautés du monde entier par genre, affichées en grille de cartes comme dans Spotify. */
class NewReleasesScreen(app: MainActivity) : Screen(app) {
    override val view: View
    private val chipHost = LinearLayout(app)
    private val list = LinearLayout(app)
    private var selected = 0
    private var genres: List<Deezer.Genre> = emptyList()

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        chipHost.orientation = LinearLayout.VERTICAL
        col.addView(chipHost)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Nouveautés", app.scroll(col))
        drawChips()
        load()
        app.bg.execute {
            val g = try { Deezer.genres() } catch (e: IOException) { emptyList() }
            app.runOnUiThread { genres = g; drawChips() }
        }
    }

    private fun drawChips() {
        chipHost.removeAllViews()
        val labels = listOf("Tous les genres") + genres.map { it.name }
        chipHost.addView(app.chipsRow(labels, selected) { selected = it; drawChips(); load() })
    }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val my = selected
        val gid = if (my == 0) 0L else genres.getOrNull(my - 1)?.id ?: 0L
        app.bg.execute {
            val r = try { Result.success(Deezer.releases(gid, 60)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != selected) return@runOnUiThread
                list.removeAllViews()
                val albums = r.getOrNull()
                if (albums == null) { list.addView(app.centered("Impossible de charger les nouveautés (${r.exceptionOrNull()?.message ?: "réseau"}).")); return@runOnUiThread }
                if (albums.isEmpty()) { list.addView(app.centered("Aucune nouveauté pour ce genre pour l’instant.")); return@runOnUiThread }
                val cards = albums.sortedByDescending { it.date ?: "" }.map { a ->
                    Card(a.cover, a.title, a.artist, "ALBUM · ${prettyDate(a.date)}".trim(), { app.push(AlbumScreen(app, a)) })
                }
                val w = (app.resources.displayMetrics.widthPixels - app.dp(32) - app.dp(12)) / 2
                val grid = LinearLayout(app)
                grid.orientation = LinearLayout.VERTICAL
                grid.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(32))
                for (pair in cards.chunked(2)) {
                    val row = LinearLayout(app)
                    pair.forEachIndexed { i, c -> row.addView(app.cardView(c, w), LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (i > 0) leftMargin = app.dp(12) }) }
                    grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = app.dp(18) })
                }
                list.addView(grid)
            }
        }
    }
}

/**
 * Un pays, façon Spotify : « Nouvelles sorties » (MusicBrainz), « Les plus écoutés » (Apple Music, si le pays en a un)
 * et « Découvertes » par style (Deezer), chacun en carrousel de pochettes avec « Voir tout ».
 */
class CountryScreen(app: MainActivity, private val code: String) : Screen(app) {
    override val view: View
    private val chipHost = LinearLayout(app)
    private val list = LinearLayout(app)
    private val name = Countries.name(code)
    private val styles: List<Triple<String, String, String?>> = buildList {
        add(Triple("Tous", "", null))
        add(Triple("Rap / Hip-Hop", "rap hip hop", "rap OR \"hip hop\" OR hip-hop"))
        add(Triple("Afro", "afro", "afrobeat OR afro OR african"))
        add(Triple("Pop", "pop", "pop"))
        add(Triple("R&B", "r&b", "r&b OR rnb"))
        if (code == "gn") add(Triple("Mamaya", "mamaya", "mamaya OR mandingue OR mandinka"))
        add(Triple("Traditionnel", "traditionnel", "folk OR traditional OR world"))
    }
    private var selected = 0
    private var seq = 0

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        chipHost.orientation = LinearLayout.VERTICAL
        col.addView(chipHost)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, app.dp(32))
        col.addView(list)
        view = app.frame(name, app.scroll(col))
        drawChips()
        load()
    }

    private fun drawChips() {
        chipHost.removeAllViews()
        chipHost.addView(app.chipsRow(styles.map { it.first }, selected) { selected = it; drawChips(); load() })
    }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val my = ++seq
        val style = styles[selected]
        val days = Prefs.releaseDays(app)
        app.bg.execute {
            val mb = try { Result.success(MusicBrainz.recent(code, days, style.third)) } catch (e: IOException) { Result.failure(e) }
            val chart = if (selected == 0) (try { Result.success(Charts.fetch(code, "songs")) } catch (e: IOException) { Result.failure(e) }) else null
            val dz = try { Result.success(Deezer.search(("$name ${style.second}").trim(), 30)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread { if (my == seq) render(mb, chart, dz, days, style.second) }
        }
    }

    private fun render(mb: Result<List<MusicBrainz.Release>>, chart: Result<List<Charts.Item>>?, dz: Result<List<Deezer.Track>>, days: Int, kw: String) {
        list.removeAllViews()

        // 1. Nouvelles sorties du pays
        val releases = mb.getOrNull()
        if (releases != null && releases.isNotEmpty()) {
            val cards = releases.map { r ->
                Card(r.cover, r.title, r.artist, "${r.type.uppercase()} · ${prettyDate(r.date)}", {
                    app.push(TrackScreen(app, TrackInfo(r.title, r.artist, r.title, "NOUVEAUTÉ · ${name.uppercase()}", null, r.cover, null, null, null)))
                })
            }
            app.carousel(list, "Nouvelles sorties · $name", cards) { app.push(CardsGridScreen(app, "Nouvelles sorties · $name", cards)) }
        } else {
            list.addView(app.tv(
                if (releases == null) "Nouvelles sorties : service indisponible (${mb.exceptionOrNull()?.message ?: "réseau"})."
                else "Aucune sortie répertoriée pour $name ces $days derniers jours dans MusicBrainz (base libre alimentée par sa communauté).",
                13f, app.palette.mute).apply { setPadding(app.dp(16), app.dp(16), app.dp(16), 0) })
        }

        // 2. Les plus écoutés (classement Apple Music)
        val items = chart?.getOrNull()
        if (items != null && items.isNotEmpty()) {
            val cards = items.map { it ->
                Card(it.cover, it.title, it.artist, "N°${it.rank}", {
                    app.push(TrackScreen(app, TrackInfo(it.title, it.artist, "", "TOP · ${name.uppercase()}", it.url, it.cover, null, it.genre, null)))
                })
            }
            app.carousel(list, "Les plus écoutés", cards) { app.push(CardsGridScreen(app, "Top · $name", cards)) }
        } else if (chart != null) {
            list.addView(app.tv("Pas de classement officiel Apple Music pour $name.", 13f, app.palette.mute).apply { setPadding(app.dp(16), app.dp(16), app.dp(16), 0) })
        }

        // 3. Découvertes par style
        val tracks = dz.getOrNull()
        if (tracks != null && tracks.isNotEmpty()) {
            val cards = tracks.mapIndexed { i, t -> t.toCard(app, tracks, i) }
            app.carousel(list, if (kw.isEmpty()) "Découvertes" else "Découvertes · $kw", cards) { app.push(CardsGridScreen(app, "Découvertes · $name", cards)) }
            list.addView(app.tv("Découvertes par mots-clés (Deezer) : ce n’est pas un classement officiel.", 11f, app.palette.mute, mono = true).apply { setPadding(app.dp(16), app.dp(8), app.dp(16), 0) })
        }
    }
}
