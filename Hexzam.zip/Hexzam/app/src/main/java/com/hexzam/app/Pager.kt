package com.hexzam.app

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs

/** Trois pages côte à côte, glissement horizontal (comme Bibliothèque ◂ Écouter ▸ Tops). */
class Pager(context: Context, private val pages: List<View>, start: Int, private val onPage: (Int) -> Unit) : FrameLayout(context) {
    var index = start
        private set
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    init { pages.forEach { addView(it, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)) } }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        place(false)
    }

    fun go(i: Int) { index = i.coerceIn(0, pages.size - 1); place(true) }

    private fun place(animated: Boolean) {
        val w = width.toFloat()
        pages.forEachIndexed { i, v ->
            val tx = (i - index) * w
            if (animated) v.animate().translationX(tx).setDuration(220).start() else v.translationX = tx
        }
        onPage(index)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.5f) dragging = true
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                pages.forEachIndexed { i, v -> v.translationX = (i - index) * width + dx }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val dx = e.x - downX
                if (dx < -width * 0.2f && index < pages.size - 1) index++ else if (dx > width * 0.2f && index > 0) index--
                dragging = false
                place(true)
            }
        }
        return true
    }
}
