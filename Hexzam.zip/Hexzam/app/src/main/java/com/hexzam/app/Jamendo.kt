package com.hexzam.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Jamendo : musique publiée par ses artistes sous licences Creative Commons. Écoute complète en streaming,
 * téléchargement uniquement quand l'artiste l'autorise (champ audiodownload_allowed).
 */
object Jamendo {
    data class JTrack(
        val id: String, val title: String, val artist: String, val album: String, val cover: String?,
        val audio: String?, val download: String?, val downloadAllowed: Boolean,
        val license: String?, val licenseUrl: String?, val share: String?,
    )

    val styles = listOf(
        Triple("Populaires", null as String?, "popularity_week"),
        Triple("Nouveautés", null, "releasedate_desc"),
        Triple("Hip-Hop", "hiphop", "popularity_week"),
        Triple("Afro", "afrobeat", "popularity_week"),
        Triple("Reggae", "reggae", "popularity_week"),
        Triple("Électro", "electronic", "popularity_week"),
        Triple("Pop", "pop", "popularity_week"),
        Triple("Rock", "rock", "popularity_week"),
        Triple("Jazz", "jazz", "popularity_week"),
        Triple("Monde", "world", "popularity_week"),
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun https(s: String?) = s?.takeIf { it.startsWith("https://") }

    /** « https://creativecommons.org/licenses/by-nc-sa/3.0/ » → « CC BY-NC-SA 3.0 ». */
    private fun pretty(url: String?): String? {
        val m = Regex("/licenses/([a-z\\-]+)/([0-9.]+)").find(url ?: "") ?: return null
        return "CC " + m.groupValues[1].uppercase() + " " + m.groupValues[2]
    }

    @Throws(IOException::class)
    fun tracks(clientId: String, search: String?, tag: String?, order: String, limit: Int = 40, dlFormat: String = "mp32"): List<JTrack> {
        val sb = StringBuilder("https://api.jamendo.com/v3.0/tracks/?client_id=${enc(clientId)}&format=json&limit=$limit&imagesize=300&audiodlformat=${enc(dlFormat)}")
        if (!search.isNullOrBlank()) sb.append("&search=").append(enc(search.trim())).append("&order=relevance")
        else sb.append("&order=").append(enc(order))
        if (!tag.isNullOrBlank() && search.isNullOrBlank()) sb.append("&tags=").append(enc(tag))
        val c = URL(sb.toString()).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 12000
            val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (e: Exception) { throw IOException("Réponse inattendue (HTTP ${c.responseCode})") }
            val h = json.optJSONObject("headers")
            if (h != null && h.optString("status") != "success") throw IOException(h.optString("error_message").ifEmpty { "Erreur du service" })
            val arr = json.optJSONArray("results") ?: return emptyList()
            return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map { o ->
                val ccUrl = o.optString("license_ccurl").ifEmpty { null }
                JTrack(
                    o.optString("id"), o.optString("name"), o.optString("artist_name"), o.optString("album_name"),
                    https(o.optString("image").ifEmpty { null } ?: o.optString("album_image")),
                    https(o.optString("audio").ifEmpty { null }),
                    https(o.optString("audiodownload").ifEmpty { null }),
                    o.optBoolean("audiodownload_allowed", false),
                    pretty(ccUrl), https(ccUrl), https(o.optString("shareurl").ifEmpty { null }),
                )
            }.filter { it.title.isNotEmpty() && it.audio != null }
        } finally { c.disconnect() }
    }
}

fun Jamendo.JTrack.toPlayable() = Deezer.Track(0, title, artist, album, cover, audio, share)
