package com.hexzam.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** API publique de Deezer (sans clé) : recherche, meilleurs titres d'un artiste, nouveautés par genre. Extraits de 30 s uniquement. */
object Deezer {
    data class Track(val id: Long, val title: String, val artist: String, val album: String, val cover: String?, val preview: String?, val link: String?)
    data class Album(val id: Long, val title: String, val artist: String, val cover: String?, val date: String?, val type: String? = null)
    data class Artist(val id: Long, val name: String, val picture: String?)
    data class Genre(val id: Long, val name: String)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun https(s: String?) = s?.takeIf { it.startsWith("https://") }

    @Throws(IOException::class)
    private fun get(path: String): JSONObject {
        val c = URL("https://api.deezer.com$path").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 12000
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val json = try { JSONObject(text) } catch (e: Exception) { throw IOException("Réponse inattendue") }
            json.optJSONObject("error")?.let { throw IOException(it.optString("message", "Erreur du service")) }
            return json
        } finally { c.disconnect() }
    }

    private fun track(o: JSONObject, fallbackCover: String? = null, fallbackAlbum: String = ""): Track {
        val album = o.optJSONObject("album")
        return Track(
            o.optLong("id"), o.optString("title"),
            o.optJSONObject("artist")?.optString("name") ?: "",
            album?.optString("title") ?: fallbackAlbum,
            https(album?.optString("cover_big")?.ifEmpty { null } ?: album?.optString("cover_medium")) ?: fallbackCover,
            https(o.optString("preview").ifEmpty { null }), https(o.optString("link").ifEmpty { null }),
        )
    }

    private fun tracks(json: JSONObject, cover: String? = null, album: String = ""): List<Track> {
        val arr = json.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map { track(it, cover, album) }.filter { it.title.isNotEmpty() }
    }

    @Throws(IOException::class)
    fun search(q: String, limit: Int = 30): List<Track> = tracks(get("/search?q=${enc(q)}&limit=$limit"))

    /** Autres morceaux d'un artiste (ses titres les plus écoutés). */
    @Throws(IOException::class)
    fun artistTop(name: String, limit: Int = 12): List<Track> {
        val found = get("/search/artist?q=${enc(name)}&limit=1").optJSONArray("data")?.optJSONObject(0) ?: return emptyList()
        // On exige un nom d'artiste proche, pour ne pas afficher les titres d'un homonyme éloigné.
        if (!found.optString("name").lowercase().contains(name.lowercase().take(6))) return emptyList()
        return tracks(get("/artist/${found.optLong("id")}/top?limit=$limit"))
    }

    private var genreCache: List<Genre>? = null

    @Throws(IOException::class)
    fun genres(): List<Genre> {
        genreCache?.let { return it }
        val arr = get("/genre").optJSONArray("data") ?: return emptyList()
        val list = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            .map { Genre(it.optLong("id"), it.optString("name")) }.filter { it.id != 0L && it.name.isNotEmpty() }
        genreCache = list
        return list
    }

    /** Nouveautés du moment : genre 0 = tous les genres. */
    @Throws(IOException::class)
    fun releases(genreId: Long, limit: Int = 50): List<Album> {
        val arr = get("/editorial/$genreId/releases?limit=$limit").optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map {
            Album(it.optLong("id"), it.optString("title"), it.optJSONObject("artist")?.optString("name") ?: "",
                https(it.optString("cover_big").ifEmpty { null } ?: it.optString("cover_medium")), it.optString("release_date").ifEmpty { null })
        }.filter { it.title.isNotEmpty() }
    }

    @Throws(IOException::class)
    fun albumTracks(a: Album): List<Track> =
        tracks(get("/album/${a.id}/tracks?limit=60"), a.cover, a.title).map { if (it.artist.isEmpty()) it.copy(artist = a.artist) else it }

    private fun artists(json: JSONObject): List<Artist> {
        val arr = json.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map {
            Artist(it.optLong("id"), it.optString("name"), https(it.optString("picture_medium").ifEmpty { null }))
        }.filter { it.name.isNotEmpty() }
    }

    @Throws(IOException::class)
    fun searchArtists(q: String, limit: Int = 15): List<Artist> = artists(get("/search/artist?q=${enc(q)}&limit=$limit"))

    /** Premier artiste dont le nom correspond vraiment à la recherche (évite les homonymes éloignés). */
    @Throws(IOException::class)
    fun findArtist(name: String): Artist? =
        searchArtists(name, 5).firstOrNull { it.name.lowercase().contains(name.lowercase().take(6)) || name.lowercase().contains(it.name.lowercase().take(6)) }

    /** Sorties d'un artiste (albums, EP, singles), avec leur date. */
    @Throws(IOException::class)
    fun artistAlbums(artist: Artist, limit: Int = 12): List<Album> {
        val arr = get("/artist/${artist.id}/albums?limit=$limit").optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map {
            Album(it.optLong("id"), it.optString("title"), artist.name,
                https(it.optString("cover_big").ifEmpty { null } ?: it.optString("cover_medium")),
                it.optString("release_date").ifEmpty { null }, it.optString("record_type").ifEmpty { null })
        }.filter { it.title.isNotEmpty() }
    }
}
