package com.hexzam.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Détail d'un titre : pochette, extrait de 30 s, favori, ouverture dans l'application de musique, paroles, partage. */
class TrackScreen(app: MainActivity, private val info: TrackInfo, private val justAdded: Boolean = false) : Screen(app) {
    private val p = app.palette
    override val view: View

    init {
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(app.dp(24), app.dp(12), app.dp(24), app.dp(32))

        val size = app.resources.displayMetrics.widthPixels - app.dp(48)
        if (info.cover != null) {
            val img = ImageView(app)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(p.card)
            c.addView(img, LinearLayout.LayoutParams(size, size))
            ImageLoader.load(app, info.cover, Prefs.coverBw(app), img)
        } else {
            val ph = app.tv("⬢", 90f, p.fg)
            ph.gravity = Gravity.CENTER
            ph.setBackgroundColor(p.card)
            c.addView(ph, LinearLayout.LayoutParams(size, size))
        }
        if (justAdded) {
            val note = LinearLayout(app)
            note.gravity = Gravity.CENTER_VERTICAL
            note.setPadding(app.dp(14), app.dp(10), app.dp(14), app.dp(10))
            note.background = android.graphics.drawable.GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
            note.addView(app.tv("✓ Ajouté à votre Bibliothèque", 13f, p.fg, bold = true, mono = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            note.addView(app.tv("VOIR ›", 12f, p.fg, bold = true, mono = true).apply { setPadding(app.dp(10), 0, 0, 0) })
            note.setOnClickListener { app.showLibrary() }
            c.addSpaced(note, 14)
        }
        c.addSpaced(app.tv(info.source + (info.genre?.let { " · ${it.uppercase()}" } ?: ""), 11f, p.mute, bold = true, mono = true, spacing = 0.12f), 18)
        c.addSpaced(app.tv(info.title, 28f, p.fg, bold = true), 4)
        c.addSpaced(app.tv(info.artist, 18f, p.fg), 2)
        if (info.album.isNotEmpty()) c.addSpaced(app.tv(info.album, 14f, p.mute), 2)

        fun row(vararg b: View): LinearLayout {
            val r = LinearLayout(app)
            b.forEachIndexed { i, v -> r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) leftMargin = app.dp(8) }) }
            return r
        }

        val line = LinearLayout(app)
        line.orientation = LinearLayout.VERTICAL
        val secondary = ArrayList<View>()
        info.preview?.let { url ->
            secondary.add(app.flatButton("▶ Extrait 30 s", p) {
                if (Player.current?.preview == url) Player.toggle()
                else Player.playOne(Deezer.Track(0, info.title, info.artist, info.album, info.cover, url, info.link))
            })
        }
        info.historyId?.let { id ->
            var fav = app.db.history().firstOrNull { it.id == id }?.fav ?: false
            lateinit var fb: TextView
            fb = app.flatButton(if (fav) "♥ Favori" else "♡ Favori", p) {
                fav = !fav
                app.db.setFav(id, fav)
                fb.text = (if (fav) "♥ FAVORI" else "♡ FAVORI")
            }
            secondary.add(fb)
        }
        if (secondary.isNotEmpty()) line.addView(row(*secondary.toTypedArray()))
        c.addSpaced(line, 18)

        fun go(key: String) = app.openService(key, info.title, info.artist)
        val def = Links.apps.firstOrNull { it.first == Prefs.musicApp(app) } ?: Links.apps[0]
        c.addSpaced(app.flatButton("Ouvrir dans ${def.second}", p, true) { go(def.first) }, 10)
        val others = Links.apps.filter { it.first != def.first }
        c.addSpaced(row(*others.map { o -> app.flatButton(o.second, p) { go(o.first) } }.toTypedArray()), 8)
        c.addSpaced(row(
            app.flatButton("Paroles", p) { app.push(LyricsScreen(app, info.title, info.artist)) },
            app.flatButton("Partager", p) { Links.share(app, "« ${info.title} » de ${info.artist} (avec HEXZAM)" + (info.link?.let { "\n$it" } ?: "")) }), 8)
        if (info.link != null) c.addSpaced(app.flatButton("Ouvrir la page du titre", p) { Links.open(app, info.link) }, 8)

        // Autres morceaux de l'artiste
        val more = LinearLayout(app)
        more.orientation = LinearLayout.VERTICAL
        c.addSpaced(more, 26)
        view = app.frame("", app.scroll(c))
        app.bg.execute {
            val others = try { Deezer.artistTop(info.artist).filter { !it.title.equals(info.title, ignoreCase = true) }.take(8) } catch (e: Exception) { emptyList() }
            app.runOnUiThread {
                if (others.isEmpty()) return@runOnUiThread
                more.addView(app.tv("Autres morceaux de ${info.artist}", 18f, p.fg, bold = true).apply { setPadding(0, 0, 0, app.dp(6)) })
                more.addView(app.hairline(p))
                app.addTrackRows(more, others)
            }
        }
    }

    override fun onClose() {}
}
