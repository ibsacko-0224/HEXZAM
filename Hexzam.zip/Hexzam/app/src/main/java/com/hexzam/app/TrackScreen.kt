package com.hexzam.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Détail d'un titre : pochette, extrait de 30 s, favori, ouverture dans l'application de musique, paroles, partage. */
class TrackScreen(app: MainActivity, private val info: TrackInfo) : Screen(app) {
    private val p = app.palette
    override val view: View

    init {
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(app.dp(24), app.dp(12), app.dp(24), app.dp(32))

        val size = app.resources.displayMetrics.widthPixels - app.dp(48)
        if (info.cover != null) {
            val img = ImageView(app)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(p.card)
            c.addView(img, LinearLayout.LayoutParams(size, size))
            ImageLoader.load(app, info.cover, Prefs.coverBw(app), img)
        } else {
            val ph = app.tv("⬢", 90f, p.fg)
            ph.gravity = Gravity.CENTER
            ph.setBackgroundColor(p.card)
            c.addView(ph, LinearLayout.LayoutParams(size, size))
        }
        c.addSpaced(app.tv(info.source + (info.genre?.let { " · ${it.uppercase()}" } ?: ""), 11f, p.mute, bold = true, mono = true, spacing = 0.12f), 18)
        c.addSpaced(app.tv(info.title, 28f, p.fg, bold = true), 4)
        c.addSpaced(app.tv(info.artist, 18f, p.fg), 2)
        if (info.album.isNotEmpty()) c.addSpaced(app.tv(info.album, 14f, p.mute), 2)

        fun row(vararg b: View): LinearLayout {
            val r = LinearLayout(app)
            b.forEachIndexed { i, v -> r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) leftMargin = app.dp(8) }) }
            return r
        }

        val line = LinearLayout(app)
        line.orientation = LinearLayout.VERTICAL
        val secondary = ArrayList<View>()
        info.preview?.let { url ->
            lateinit var btn: TextView
            btn = app.flatButton("▶ Extrait 30 s", p) {
                Preview.toggle(url) { playing -> app.runOnUiThread { btn.text = if (playing) "■ ARRÊTER" else "▶ EXTRAIT 30 S" } }
            }
            secondary.add(btn)
        }
        info.historyId?.let { id ->
            var fav = app.db.history().firstOrNull { it.id == id }?.fav ?: false
            lateinit var fb: TextView
            fb = app.flatButton(if (fav) "♥ Favori" else "♡ Favori", p) {
                fav = !fav
                app.db.setFav(id, fav)
                fb.text = (if (fav) "♥ FAVORI" else "♡ FAVORI")
            }
            secondary.add(fb)
        }
        if (secondary.isNotEmpty()) line.addView(row(*secondary.toTypedArray()))
        c.addSpaced(line, 18)

        val def = Links.apps.firstOrNull { it.first == Prefs.musicApp(app) } ?: Links.apps[0]
        c.addSpaced(app.flatButton("Ouvrir dans ${def.second}", p, true) { Links.open(app, Links.urlFor(def.first, info.title, info.artist)) }, 10)
        val others = Links.apps.filter { it.first != def.first }
        c.addSpaced(row(*others.map { o -> app.flatButton(o.second, p) { Links.open(app, Links.urlFor(o.first, info.title, info.artist)) } }.toTypedArray()), 8)
        c.addSpaced(row(
            app.flatButton("Paroles", p) { Links.open(app, Links.lyrics(info.title, info.artist)) },
            app.flatButton("Partager", p) { Links.share(app, "« ${info.title} » de ${info.artist} (avec HEXZAM)" + (info.link?.let { "\n$it" } ?: "")) }), 8)
        if (info.link != null) c.addSpaced(app.flatButton("Ouvrir la page du titre", p) { Links.open(app, info.link) }, 8)

        view = app.frame("", app.scroll(c))
    }

    override fun onClose() { Preview.stop() }
}
