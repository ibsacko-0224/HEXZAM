package com.hexzam.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/** Widget d'écran d'accueil : un appui lance l'écoute. */
class ListenWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.widget)
            v.setOnClickPendingIntent(R.id.widget_root, Notifier.listenIntent(context))
            manager.updateAppWidget(id, v)
        }
    }
}
