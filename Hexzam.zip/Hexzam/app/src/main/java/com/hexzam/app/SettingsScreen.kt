package com.hexzam.app

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

class SettingsScreen(private val a: MainActivity, private val p: Palette) {
    val view: View
    private val root = LinearLayout(a)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(a.dp(20), a.dp(24), a.dp(20), a.dp(32))
        root.addView(a.tv("RÉGLAGES", 18f, p.fg, bold = true, mono = true, spacing = 0.25f))
        build()
        val s = ScrollView(a)
        s.addView(root)
        view = s
    }

    fun refresh() {}

    private fun section(title: String) {
        root.addSpaced(a.hairline(p), 26)
        root.addSpaced(a.tv(title, 12f, p.fg, bold = true, mono = true, spacing = 0.2f), 14)
    }

    private fun note(text: String, top: Int = 6) = root.addSpaced(a.tv(text, 13f, p.mute), top)

    private fun label(text: String) = root.addSpaced(a.tv(text, 15f, p.fg), 14)

    private fun segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        val row = LinearLayout(a)
        options.forEachIndexed { i, o ->
            val b = a.flatButton(o, p, filled = i == selected) { onSelect(i) }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) leftMargin = a.dp(-1) })
        }
        root.addSpaced(row, 8)
    }

    private fun toggle(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(a)
        sw.text = text
        sw.setTextColor(p.fg)
        sw.textSize = 15f
        sw.isChecked = checked
        sw.thumbTintList = ColorStateList.valueOf(p.fg)
        sw.trackTintList = ColorStateList.valueOf(p.mute)
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        root.addSpaced(sw, 14)
    }

    private fun build() {
        root.removeViews(1, root.childCount - 1)

        section("APPARENCE")
        label("Thème")
        val themes = listOf("dark", "light", "system")
        segmented(listOf("Noir", "Blanc", "Système"), themes.indexOf(Prefs.theme(a)).coerceAtLeast(0)) { i ->
            Prefs.setTheme(a, themes[i]); a.recreate()
        }

        section("ÉCOUTE")
        label("Durée d’écoute")
        val secs = listOf(5, 8, 12)
        segmented(secs.map { "$it s" }, secs.indexOf(Prefs.listenSeconds(a)).coerceAtLeast(0)) { i ->
            Prefs.setListenSeconds(a, secs[i]); build()
        }
        note("Plus c’est long, plus la reconnaissance est fiable dans le bruit.")
        label("Exigence de reconnaissance")
        segmented(listOf("Souple", "Normal", "Strict"), Prefs.strictness(a)) { i -> Prefs.setStrictness(a, i); build() }
        note("Strict évite les faux positifs ; Souple reconnaît plus facilement mais peut se tromper.")
        toggle("Vibration à la reconnaissance", Prefs.haptics(a)) { Prefs.setHaptics(a, it) }

        section("RECONNAISSANCE EN LIGNE (OPTIONNELLE)")
        note("Désactivée par défaut. Si vous l’activez, quand votre bibliothèque ne reconnaît pas un extrait, ce court extrait audio est envoyé au service AudD (api.audd.io) pour identifier le morceau. Rien d’autre n’est envoyé. Il faut votre propre clé.", 8)
        toggle("Autoriser la reconnaissance en ligne", Prefs.online(a)) { Prefs.setOnline(a, it) }
        label("Clé API AudD")
        val token = EditText(a)
        token.setText(Prefs.token(a))
        token.hint = "Collez votre clé ici"
        token.setTextColor(p.fg)
        token.setHintTextColor(p.mute)
        token.textSize = 14f
        token.setSingleLine()
        token.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        token.setPadding(a.dp(12), a.dp(12), a.dp(12), a.dp(12))
        token.background = GradientDrawable().apply { setColor(p.bg); setStroke(a.dp(1), p.fg) }
        token.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { Prefs.setToken(a, s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        root.addSpaced(token, 6)
        note("La clé reste sur votre téléphone (stockage privé de l’application).")
        root.addSpaced(a.flatButton("Obtenir une clé (audd.io)", p) { Links.open(a, "https://audd.io") }, 10)

        section("DONNÉES")
        root.addSpaced(a.flatButton("Exporter l’historique (CSV)", p) { a.exportHistory() }, 12)
        root.addSpaced(a.flatButton("Vider l’historique", p) {
            AlertDialog.Builder(a).setMessage("Effacer tout l’historique ?")
                .setPositiveButton("Effacer") { _, _ -> a.db.clearHistory() }.setNegativeButton("Annuler", null).show()
        }, 8)
        root.addSpaced(a.flatButton("Supprimer la bibliothèque", p) {
            AlertDialog.Builder(a).setMessage("Supprimer toutes les empreintes ? (vos fichiers musicaux ne sont pas touchés)")
                .setPositiveButton("Supprimer") { _, _ -> a.db.clearLibrary() }.setNegativeButton("Annuler", null).show()
        }, 8)
        note("Historique, empreintes et réglages sont stockés uniquement sur cet appareil.", 10)

        // ───── CENTRAL-HEX
        section("CENTRAL-HEX")
        val card = LinearLayout(a)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16))
        card.background = GradientDrawable().apply { setColor(p.card); setStroke(a.dp(1), p.fg) }
        card.addView(a.tv("⬢ CENTRAL-HEX", 18f, p.fg, bold = true, mono = true, spacing = 0.15f))
        card.addView(a.tv("La communauté Tech & Digital", 14f, p.fg, bold = true).apply { setPadding(0, a.dp(4), 0, 0) })
        card.addView(a.tv("Où la technologie rencontre la créativité. Ici, on ne reste pas spectateur : on apprend, on applique, on évolue.", 13f, p.mute).apply { setPadding(0, a.dp(8), 0, 0) })
        root.addSpaced(card, 12)
        root.addSpaced(a.flatButton("Rejoindre la communauté", p, true) { Links.open(a, Links.COMMUNITY) }, 10)
        root.addSpaced(a.flatButton("Partager HEXZAM", p) {
            Links.share(a, "HEXZAM — reconnaissance musicale, noir & blanc, par CENTRAL-HEX.\nRejoins la communauté : ${Links.COMMUNITY}")
        }, 8)

        section("À PROPOS")
        val version = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName } catch (e: Exception) { "?" }
        note("HEXZAM $version · un projet CENTRAL-HEX", 8)
        note("Micro : utilisé seulement quand vous touchez le bouton, application ouverte. Aucun compte, aucune publicité, aucune télémétrie.")
    }
}
