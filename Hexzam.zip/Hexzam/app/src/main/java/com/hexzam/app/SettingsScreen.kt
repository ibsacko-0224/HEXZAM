package com.hexzam.app

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch

/** Paramètres, organisés comme ceux de Shazam : conseils, façons de reconnaître, préférences, aide, compte. */
class SettingsScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    private val root = LinearLayout(app)
    override val view: View = app.frame("Paramètres", app.scroll(root))

    init { build() }

    private fun header(text: String) = root.addSpaced(app.tv(text, 20f, p.fg, bold = true), 28).also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = app.dp(4) }

    private fun panel(vararg rows: View) {
        val box = LinearLayout(app)
        box.orientation = LinearLayout.VERTICAL
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.line) }
        rows.forEachIndexed { i, r -> if (i > 0) box.addView(app.hairline(p)); box.addView(r) }
        root.addSpaced(box, 10)
    }

    private fun toggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(app)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(app.dp(16), app.dp(14), app.dp(16), app.dp(14))
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.addView(app.tv(title, 16f, p.fg, bold = true))
        if (sub != null) col.addView(app.tv(sub, 13f, p.mute))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(app)
        sw.isChecked = checked
        sw.thumbTintList = ColorStateList.valueOf(p.fg)
        sw.trackTintList = ColorStateList.valueOf(p.mute)
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(sw)
        return row
    }

    private fun card(title: String, sub: String, button: String, onClick: () -> Unit): View {
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(app.dp(18), app.dp(18), app.dp(18), app.dp(18))
        c.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        c.addView(app.tv("⬢", 30f, p.fg))
        c.addView(app.tv(title, 16f, p.fg, bold = true).apply { setPadding(0, app.dp(8), 0, 0) })
        c.addView(app.tv(sub, 13f, p.mute).apply { setPadding(0, app.dp(4), 0, app.dp(12)) })
        c.addView(app.flatButton(button, p, true, onClick))
        return c
    }

    private fun build() {
        root.removeAllViews()
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(app.dp(16), app.dp(4), app.dp(16), app.dp(40))

        // ───── Conseils et recommandations
        header("Conseils et recommandations")
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        val cards = LinearLayout(app)
        val cw = app.resources.displayMetrics.widthPixels * 72 / 100
        fun add(v: View) = cards.addView(v, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.MATCH_PARENT).apply { rightMargin = app.dp(10) })
        add(card("Application de musique par défaut", "Ouvrir les titres reconnus dans votre application préférée", "Choisir") { app.chooseMusicApp { build() } })
        add(card("Reconnaître toute musique", "Collez votre clé AudD pour identifier n’importe quel titre", "Ajouter ma clé") { app.promptKey { build() } })
        add(card("Sauvegarde", "Exportez vos titres reconnus en fichier CSV", "Exporter") { app.exportHistory() })
        hs.addView(cards)
        root.addSpaced(hs, 10)

        // ───── Plus de façons de reconnaître
        header("Plus de façons de reconnaître")
        panel(
            toggleRow("Barre de notification", "Accédez à HEXZAM depuis la barre de notification", Prefs.quickNotif(app)) {
                Prefs.setQuickNotif(app, it); if (it) app.askNotifPermission(); Notifier.syncQuick(app)
            },
            toggleRow("Pop-up HEXZAM", "Afficher un bouton flottant persistant sur votre téléphone", BubbleService.running.get()) { if (it) app.startBubble() else app.stopBubble() },
            toggleRow("Auto-HEXZAM", "Reconnaît la musique en continu, en arrière-plan", AutoListenService.running.get()) { if (it) app.startAuto() else app.stopAuto() },
            app.menuRow("Intervalle de l’écoute continue", "${Prefs.autoInterval(app)} s") {
                val v = listOf(30, 60, 180)
                app.choose("Intervalle", v.map { "$it s" }, v.indexOf(Prefs.autoInterval(app))) { i -> Prefs.setAutoInterval(app, v[i]); build() }
            },
        )
        root.addSpaced(app.tv("Tuile : balayez les réglages rapides, touchez le crayon et ajoutez HEXZAM. Widget : appui long sur l’écran d’accueil → Widgets → HEXZAM. L’écoute continue garde le micro actif tant que sa notification est visible (batterie et données).", 12f, p.mute), 8)

        // ───── Application de musique
        header("Préférence pour l’application de musique")
        val cur = Links.apps.firstOrNull { it.first == Prefs.musicApp(app) } ?: Links.apps[0]
        panel(app.menuRow("Ouvrir les titres dans…", cur.second, "Sélectionner le service par défaut") { app.chooseMusicApp { build() } })

        // ───── Préférences HEXZAM
        header("Préférences HEXZAM")
        val themes = listOf("dark" to "Noir", "light" to "Blanc", "system" to "Valeur par défaut du système")
        val secs = listOf(5, 8, 12)
        val strict = listOf("Souple", "Normal", "Strict")
        panel(
            toggleRow("Reconnaître au démarrage", null, Prefs.listenOnStart(app)) { Prefs.setListenOnStart(app, it) },
            toggleRow("Vibrer en cas de résultat", null, Prefs.haptics(app)) { Prefs.setHaptics(app, it) },
            toggleRow("Notification quand un titre est reconnu", "Écoute continue et extraits reconnus après coup", Prefs.notifyResult(app)) { Prefs.setNotifyResult(app, it); if (it) app.askNotifPermission() },
            toggleRow("Pochettes en noir et blanc", null, Prefs.coverBw(app)) { Prefs.setCoverBw(app, it) },
            app.menuRow("Apparence", themes.first { it.first == Prefs.theme(app) }.second) {
                app.choose("Apparence", themes.map { it.second }, themes.indexOfFirst { it.first == Prefs.theme(app) }) { i ->
                    Prefs.setTheme(app, themes[i].first); app.recreateKeepingSettings()
                }
            },
            app.menuRow("Durée d’écoute", "${Prefs.listenSeconds(app)} s", "Plus c’est long, plus c’est fiable dans le bruit") {
                app.choose("Durée d’écoute", secs.map { "$it s" }, secs.indexOf(Prefs.listenSeconds(app))) { i -> Prefs.setListenSeconds(app, secs[i]); build() }
            },
            app.menuRow("Exigence de reconnaissance", strict[Prefs.strictness(app)], "Strict évite les faux positifs") {
                app.choose("Exigence", strict, Prefs.strictness(app)) { i -> Prefs.setStrictness(app, i); build() }
            },
            app.menuRow("Gérer les notifications") { app.openNotificationSettings() },
        )

        // ───── Reconnaissance en ligne
        header("Reconnaissance en ligne")
        val token = EditText(app)
        token.setText(Prefs.token(app))
        token.hint = "Clé API AudD"
        token.setTextColor(p.fg)
        token.setHintTextColor(p.mute)
        token.textSize = 14f
        token.setSingleLine()
        token.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        token.setPadding(app.dp(14), app.dp(14), app.dp(14), app.dp(14))
        token.background = null
        token.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { Prefs.setToken(app, s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        panel(
            toggleRow("Autoriser la reconnaissance en ligne", "Permet de reconnaître n’importe quelle musique d’un seul appui", Prefs.online(app)) { Prefs.setOnline(app, it) },
            token,
            app.menuRow("Obtenir une clé (audd.io)") { Links.open(app, "https://audd.io") },
        )
        root.addSpaced(app.tv("Quand votre bibliothèque ne reconnaît pas l’extrait, ces quelques secondes d’audio sont envoyées au service tiers AudD (api.audd.io) avec votre clé ; rien d’autre. AudD peut être payant après un quota d’essai : vérifiez sur son site. La clé reste dans le stockage privé de l’application.", 12f, p.mute), 8)

        // ───── Données
        header("Données")
        panel(
            app.menuRow("Exporter l’historique (CSV)") { app.exportHistory() },
            app.menuRow("Vider l’historique") {
                AlertDialog.Builder(app).setMessage("Effacer tout l’historique ?").setPositiveButton("Effacer") { _, _ -> app.db.clearHistory() }.setNegativeButton("Annuler", null).show()
            },
            app.menuRow("Vider les extraits en attente", "${Pending.count(app)}") { Pending.clear(app); build() },
            app.menuRow("Supprimer ma musique locale") {
                AlertDialog.Builder(app).setMessage("Supprimer toutes les empreintes ? (vos fichiers ne sont pas touchés)").setPositiveButton("Supprimer") { _, _ -> app.db.clearLibrary() }.setNegativeButton("Annuler", null).show()
            },
        )

        // ───── CENTRAL-HEX
        header("CENTRAL-HEX")
        val ch = LinearLayout(app)
        ch.orientation = LinearLayout.VERTICAL
        ch.setPadding(app.dp(18), app.dp(18), app.dp(18), app.dp(18))
        ch.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(2), p.fg) }
        ch.addView(app.tv("⬢ CENTRAL-HEX", 20f, p.fg, bold = true, mono = true, spacing = 0.12f))
        ch.addView(app.tv("La communauté Tech & Digital", 15f, p.fg, bold = true).apply { setPadding(0, app.dp(4), 0, 0) })
        ch.addView(app.tv("Où la technologie rencontre la créativité. Ici, on ne reste pas spectateur : on apprend, on applique, on évolue.", 13f, p.mute).apply { setPadding(0, app.dp(8), 0, app.dp(14)) })
        ch.addView(app.flatButton("Rejoindre la communauté", p, true) { Links.open(app, Links.COMMUNITY) })
        ch.addView(app.flatButton("Partager HEXZAM", p) { Links.share(app, "HEXZAM — reconnaissance musicale par CENTRAL-HEX.\nRejoins la communauté : ${Links.COMMUNITY}") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(8) })
        root.addSpaced(ch, 10)

        // ───── Aide
        header("Aide")
        val version = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName } catch (e: Exception) { "?" }
        panel(
            app.menuRow("Info", "v$version") {
                AlertDialog.Builder(app).setTitle("HEXZAM $version")
                    .setMessage("Un projet CENTRAL-HEX.\n\nMicro : utilisé quand vous touchez le bouton, ou pendant l’écoute continue que vous activez. Aucun compte, aucune publicité, aucune télémétrie.\n\nLes Tops viennent des flux publics d’Apple Music ; l’identification en ligne, du service AudD. HEXZAM n’est pas affilié à Shazam ni à Apple.")
                    .setPositiveButton("OK", null).show()
            },
            app.menuRow("Foire aux questions") {
                AlertDialog.Builder(app).setTitle("Foire aux questions").setMessage(
                    "Comment reconnaître un titre ?\nTouchez le grand bouton de la page centrale.\n\n" +
                    "Pourquoi « Clé API manquante » ?\nL’identification de n’importe quelle musique passe par le service AudD : créez une clé sur audd.io et collez-la dans Paramètres.\n\n" +
                    "Ça marche sans connexion ?\nOui pour votre musique locale ; sinon l’extrait est gardé et reconnu au retour du réseau.\n\n" +
                    "Où sont mes titres ?\nUniquement sur ce téléphone. Exportez-les en CSV dans Paramètres.\n\n" +
                    "Le pop-up ne s’affiche pas ?\nAutorisez « Affichage par-dessus les autres applications » pour HEXZAM."
                ).setPositiveButton("OK", null).show()
            },
        )

        // ───── Compte
        header("Compte")
        panel(app.tv("Pas de compte. Vos titres, favoris et réglages restent sur ce téléphone : rien n’est synchronisé ni envoyé.", 14f, p.mute).apply { setPadding(app.dp(16), app.dp(16), app.dp(16), app.dp(16)) })
    }
}
