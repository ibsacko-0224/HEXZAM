package com.hexzam.app

import android.app.AlertDialog
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast
import java.io.File
import java.io.IOException

/** Paramètres : état de l'application, façons de reconnaître, reconnaissance, affichage, données, confidentialité, aide, à propos. */
class SettingsScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    private val root = LinearLayout(app)
    override val view: View = app.frame("Paramètres", app.scroll(root))

    init { build() }

    override fun onShow() { build() }

    // ───── composants
    private fun header(text: String, sub: String? = null) {
        root.addSpaced(app.tv(text.uppercase(), 12f, p.mute, bold = true, mono = true, spacing = 0.15f), 28).also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = app.dp(4) }
        if (sub != null) root.addSpaced(app.tv(sub, 13f, p.mute), 4).also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = app.dp(4) }
    }

    private fun panel(vararg rows: View) {
        val box = LinearLayout(app)
        box.orientation = LinearLayout.VERTICAL
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.line) }
        rows.forEachIndexed { i, r -> if (i > 0) box.addView(app.hairline(p)); box.addView(r) }
        root.addSpaced(box, 10)
    }

    private fun toggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(app)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(app.dp(16), app.dp(14), app.dp(16), app.dp(14))
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.addView(app.tv(title, 16f, p.fg, bold = true))
        if (sub != null) col.addView(app.tv(sub, 13f, p.mute))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(app)
        sw.isChecked = checked
        sw.thumbTintList = ColorStateList.valueOf(p.fg)
        sw.trackTintList = ColorStateList.valueOf(p.mute)
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(sw)
        return row
    }

    private fun statusRow(label: String, ok: Boolean, detail: String, fix: () -> Unit): View {
        val row = LinearLayout(app)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(app.dp(16), app.dp(13), app.dp(16), app.dp(13))
        row.addView(app.tv(if (ok) "✓" else "✕", 16f, p.fg, bold = true, mono = true), LinearLayout.LayoutParams(app.dp(26), ViewGroup.LayoutParams.WRAP_CONTENT))
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.addView(app.tv(label, 15f, p.fg, bold = true))
        col.addView(app.tv(detail, 12f, p.mute))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!ok) row.addView(app.tv("CORRIGER ›", 11f, p.fg, bold = true, mono = true))
        row.setOnClickListener { if (!ok) fix() }
        return row
    }

    private fun card(title: String, sub: String, button: String, onClick: () -> Unit): View {
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(app.dp(18), app.dp(18), app.dp(18), app.dp(18))
        c.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        c.addView(app.tv("⬢", 28f, p.fg))
        c.addView(app.tv(title, 16f, p.fg, bold = true).apply { setPadding(0, app.dp(8), 0, 0) })
        c.addView(app.tv(sub, 13f, p.mute).apply { setPadding(0, app.dp(4), 0, app.dp(12)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        c.addView(app.flatButton(button, p, true, onClick))
        return c
    }

    private fun note(text: String) = root.addSpaced(app.tv(text, 12f, p.mute), 8).also { (it.layoutParams as LinearLayout.LayoutParams).leftMargin = app.dp(4) }

    private fun coverCacheBytes(): Long = File(app.cacheDir, "covers").listFiles()?.sumOf { it.length() } ?: 0L
    private fun size(b: Long) = if (b < 1024 * 1024) "${b / 1024} Ko" else String.format("%.1f Mo", b / 1048576.0)

    // ───── écran
    private fun build() {
        root.removeAllViews()
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(app.dp(16), app.dp(4), app.dp(16), app.dp(40))
        val hasMic = app.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val hasKey = Prefs.token(app).isNotBlank()
        val history = app.db.history()

        // 1. État de l'application
        header("État de l’application", "Tout doit être au vert pour reconnaître n’importe quelle musique.")
        panel(
            statusRow("Clé API AudD", hasKey, if (hasKey) "Enregistrée" else "Manquante : sans elle, seule votre musique locale est reconnue") { app.promptKey { build() } },
            statusRow("Micro", hasMic, if (hasMic) "Autorisé" else "Non autorisé") { app.requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), MainActivity.REQ_MIC) },
            statusRow("Notifications", Notifier.canPost(app), if (Notifier.canPost(app)) "Autorisées" else "Non autorisées") { app.askNotifPermission(); app.openNotificationSettings() },
            statusRow("Réseau", Pending.networkAvailable(app), if (Pending.networkAvailable(app)) "Connecté" else "Hors-ligne : les extraits sont gardés puis reconnus plus tard") { },
        )

        // 2. Conseils
        header("Conseils et recommandations")
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        val cards = LinearLayout(app)
        val cw = app.resources.displayMetrics.widthPixels * 72 / 100
        fun add(v: View) = cards.addView(v, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.MATCH_PARENT).apply { rightMargin = app.dp(10) })
        add(card("Application par défaut", "Le gros bouton de chaque titre ouvre cette application", "Choisir") { app.chooseMusicApp { build() } })
        add(card("Reconnaître toute musique", "Collez votre clé AudD pour identifier n’importe quel titre", "Ajouter ma clé") { app.promptKey { build() } })
        add(card("Sauvegarde", "Exportez vos titres reconnus en fichier CSV", "Exporter") { app.exportHistory() })
        hs.addView(cards)
        root.addSpaced(hs, 10)

        // 3. Façons de reconnaître
        header("Plus de façons de reconnaître")
        panel(
            toggleRow("Barre de notification", "Un bouton Écouter dans vos notifications", Prefs.quickNotif(app)) { Prefs.setQuickNotif(app, it); if (it) app.askNotifPermission(); Notifier.syncQuick(app) },
            toggleRow("Pop-up HEXZAM", "Bouton flottant déplaçable, par-dessus les autres applications", BubbleService.running.get()) { if (it) app.startBubble() else app.stopBubble() },
            toggleRow("Auto-HEXZAM", "Écoute continue en arrière-plan (micro actif)", AutoListenService.running.get()) { if (it) app.startAuto() else app.stopAuto() },
            app.menuRow("Intervalle de l’écoute continue", "${Prefs.autoInterval(app)} s") {
                val v = listOf(30, 60, 180)
                app.choose("Intervalle", v.map { "$it s" }, v.indexOf(Prefs.autoInterval(app))) { i -> Prefs.setAutoInterval(app, v[i]); build() }
            },
            toggleRow("Reconnaître au démarrage", "Lance l’écoute dès l’ouverture", Prefs.listenOnStart(app)) { Prefs.setListenOnStart(app, it) },
        )
        note("Tuile : balayez les réglages rapides → crayon → HEXZAM. Widget : appui long sur l’accueil → Widgets → HEXZAM.")

        // 4. Reconnaissance
        header("Reconnaissance")
        val token = EditText(app)
        token.setText(Prefs.token(app))
        token.hint = "Clé API AudD"
        token.setTextColor(p.fg)
        token.setHintTextColor(p.mute)
        token.textSize = 14f
        token.setSingleLine()
        token.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        token.setPadding(app.dp(16), app.dp(14), app.dp(16), app.dp(14))
        token.background = null
        token.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { Prefs.setToken(app, s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        val secs = listOf(5, 8, 12)
        val strict = listOf("Souple", "Normal", "Strict")
        panel(
            toggleRow("Reconnaissance en ligne", "Permet de reconnaître n’importe quelle musique d’un seul appui", Prefs.online(app)) { Prefs.setOnline(app, it) },
            token,
            app.menuRow("Vérifier la clé", null, "Envoie 1 s de silence au service (consomme 1 requête)") { checkKey() },
            app.menuRow("Obtenir une clé (audd.io)") { Links.open(app, "https://dashboard.audd.io") },
            app.menuRow("Durée d’écoute", "${Prefs.listenSeconds(app)} s", "Plus c’est long, plus c’est fiable dans le bruit") {
                app.choose("Durée d’écoute", secs.map { "$it s" }, secs.indexOf(Prefs.listenSeconds(app))) { i -> Prefs.setListenSeconds(app, secs[i]); build() }
            },
            app.menuRow("Exigence (musique locale)", strict[Prefs.strictness(app)], "Strict évite les faux positifs") {
                app.choose("Exigence", strict, Prefs.strictness(app)) { i -> Prefs.setStrictness(app, i); build() }
            },
        )
        note("Quand votre bibliothèque ne reconnaît pas l’extrait, ces quelques secondes d’audio sont envoyées au service tiers AudD (api.audd.io) avec votre clé. AudD peut être payant après un quota d’essai.")

        // 5. Application de musique
        header("Application de musique")
        val cur = Links.apps.firstOrNull { it.first == Prefs.musicApp(app) } ?: Links.apps[0]
        panel(
            app.menuRow("Ouvrir les titres dans…", cur.second, "Bouton principal de l’écran d’un titre") { app.chooseMusicApp { build() } },
            app.menuRow("VidMate", null, "Ouvrir l’application, ou la page de téléchargement") { app.openVidmate(null) },
        )
        note("VidMate est une application tierce, sans lien avec HEXZAM. Ne téléchargez que ce que vous avez le droit de télécharger.")

        // 6. Affichage et confort
        val themes = listOf("dark" to "Noir", "light" to "Blanc", "system" to "Système")
        header("Affichage et confort")
        panel(
            app.menuRow("Apparence", themes.first { it.first == Prefs.theme(app) }.second) {
                app.choose("Apparence", themes.map { it.second }, themes.indexOfFirst { it.first == Prefs.theme(app) }) { i -> Prefs.setTheme(app, themes[i].first); app.recreateKeepingSettings() }
            },
            toggleRow("Vibrer en cas de résultat", null, Prefs.haptics(app)) { Prefs.setHaptics(app, it) },
            toggleRow("Notification de titre reconnu", "Écoute continue et extraits reconnus après coup", Prefs.notifyResult(app)) { Prefs.setNotifyResult(app, it); if (it) app.askNotifPermission() },
            toggleRow("Pochettes en noir et blanc", null, Prefs.coverBw(app)) { Prefs.setCoverBw(app, it) },
            toggleRow("Pochettes en Wi-Fi uniquement", "Économise vos données mobiles", Prefs.coverWifiOnly(app)) { Prefs.setCoverWifiOnly(app, it) },
            app.menuRow("Gérer les notifications") { app.openNotificationSettings() },
        )

        // 7. Données et stockage
        header("Données et stockage")
        panel(
            app.menuRow("Titres reconnus", "${history.size}", "${history.count { it.fav }} favori(s)") { app.showLibrary() },
            app.menuRow("Extraits en attente", "${Pending.count(app)}", "Reconnus dès que le réseau revient") { app.retryPending() },
            app.menuRow("Cache des pochettes", size(coverCacheBytes()), "Toucher pour vider") {
                File(app.cacheDir, "covers").listFiles()?.forEach { it.delete() }; Toast.makeText(app, "Cache vidé.", Toast.LENGTH_SHORT).show(); build()
            },
            app.menuRow("Exporter l’historique (CSV)") { app.exportHistory() },
            app.menuRow("Vider l’historique") {
                AlertDialog.Builder(app).setMessage("Effacer tout l’historique ?").setPositiveButton("Effacer") { _, _ -> app.db.clearHistory(); build() }.setNegativeButton("Annuler", null).show()
            },
            app.menuRow("Supprimer ma musique locale", "${app.db.tracks().size}") {
                AlertDialog.Builder(app).setMessage("Supprimer toutes les empreintes ? (vos fichiers ne sont pas touchés)").setPositiveButton("Supprimer") { _, _ -> app.db.clearLibrary(); build() }.setNegativeButton("Annuler", null).show()
            },
            app.menuRow("Réinitialiser les réglages", null, "Efface aussi la clé enregistrée dans l’app") {
                AlertDialog.Builder(app).setMessage("Remettre tous les réglages par défaut ? L’historique est conservé.").setPositiveButton("Réinitialiser") { _, _ -> Prefs.resetAll(app); app.recreateKeepingSettings() }.setNegativeButton("Annuler", null).show()
            },
        )

        // 8. Confidentialité
        header("Confidentialité")
        panel(app.menuRow("Ce que fait HEXZAM de vos données") {
            AlertDialog.Builder(app).setTitle("Confidentialité").setMessage(
                "• Micro : seulement quand vous touchez Écouter, ou pendant l’écoute continue que vous activez.\n" +
                "• Envoyé : quelques secondes d’audio à AudD, uniquement si la reconnaissance en ligne est active et que votre bibliothèque n’a rien trouvé. Titres de paroles : titre et artiste.\n" +
                "• Stocké sur ce téléphone : historique, favoris, clé, extraits en attente, pochettes en cache.\n" +
                "• Jamais : compte, publicité, télémétrie, synchronisation."
            ).setPositiveButton("OK", null).show()
        })

        // 9. Aide
        val version = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName } catch (e: Exception) { "?" }
        header("Aide")
        panel(
            app.menuRow("Foire aux questions") {
                AlertDialog.Builder(app).setTitle("Foire aux questions").setMessage(
                    "Comment reconnaître un titre ?\nTouchez le grand bouton de la page centrale.\n\n" +
                    "Où retrouver mes musiques ?\nDans la Bibliothèque (onglet en bas) : tous les titres reconnus, artistes, favoris, playlists.\n\n" +
                    "Pourquoi « Clé API manquante » ?\nL’identification passe par AudD : créez une clé et collez-la dans Paramètres.\n\n" +
                    "Ça marche sans connexion ?\nL’extrait est gardé et reconnu au retour du réseau.\n\n" +
                    "Paroles indisponibles ?\nLe service n’en propose que pour certains titres.\n\n" +
                    "Le pop-up ne s’affiche pas ?\nAutorisez « Affichage par-dessus les autres applications »."
                ).setPositiveButton("OK", null).show()
            },
            app.menuRow("Poser une question à la communauté") { Links.open(app, Links.COMMUNITY) },
        )

        // 10. À propos — CENTRAL-HEX
        header("À propos")
        val about = LinearLayout(app)
        about.orientation = LinearLayout.VERTICAL
        about.setPadding(app.dp(18), app.dp(18), app.dp(18), app.dp(18))
        about.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(2), p.fg) }
        val logo = android.widget.ImageView(app)
        logo.setImageResource(R.drawable.logo)
        logo.contentDescription = "HEXZAM par CENTRAL-HEX"
        about.addView(logo, LinearLayout.LayoutParams(app.dp(120), app.dp(120)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = app.dp(12) })
        about.addView(app.tv("⬢ CENTRAL-HEX", 22f, p.fg, bold = true, mono = true, spacing = 0.12f))
        about.addView(app.tv("La communauté Tech & Digital", 16f, p.fg, bold = true).apply { setPadding(0, app.dp(4), 0, 0) })
        about.addView(app.tv("La plateforme ultime pour les passionnés de technologie et de digital.", 13f, p.mute).apply { setPadding(0, app.dp(6), 0, app.dp(10)) })
        for (line in listOf("Explorer la tech & l’IA : bots, automatisation, intelligence artificielle",
            "Créer ton univers digital : sites web, outils, projets en ligne",
            "Développer et automatiser tes idées : bots WhatsApp, scripts, solutions pratiques",
            "Accéder à des ressources exclusives : guides, tutoriels, astuces avancées",
            "Innover & partager : idées business, projets collaboratifs, challenges créatifs"))
            about.addView(app.tv("⬢  $line", 13f, p.fg).apply { setPadding(0, app.dp(3), 0, app.dp(3)) })
        about.addView(app.tv("Notre mission : construire une communauté forte, active et innovante, où l’apprentissage se transforme en action. Ici, on ne reste pas spectateur. On apprend, on applique, on évolue.", 13f, p.mute).apply { setPadding(0, app.dp(10), 0, app.dp(14)) })
        about.addView(app.flatButton("Rejoindre la communauté", p, true) { Links.open(app, Links.COMMUNITY) })
        about.addView(app.flatButton("Partager HEXZAM", p) { Links.share(app, "HEXZAM — reconnaissance musicale par CENTRAL-HEX.\nRejoins la communauté : ${Links.COMMUNITY}") },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(8) })
        about.addView(app.tv("Où la technologie rencontre la créativité.", 12f, p.mute, mono = true).apply { setPadding(0, app.dp(14), 0, 0) })
        root.addSpaced(about, 10)
        panel(
            app.menuRow("Version", version ?: "?") { },
            app.menuRow("Mentions") {
                AlertDialog.Builder(app).setTitle("HEXZAM $version").setMessage(
                    "Un projet CENTRAL-HEX.\n\nLes Tops viennent des flux publics d’Apple Music ; l’identification et les paroles, du service AudD ; les pochettes et extraits, d’Apple et Spotify. HEXZAM n’est affilié à aucun d’eux, ni à Shazam, ni à VidMate."
                ).setPositiveButton("OK", null).show()
            },
        )

        // 11. Compte
        header("Compte")
        panel(app.tv("Pas de compte. Vos titres, favoris et réglages restent sur ce téléphone : rien n’est synchronisé.", 14f, p.mute).apply { setPadding(app.dp(16), app.dp(16), app.dp(16), app.dp(16)) })
    }

    private fun checkKey() {
        val t = Prefs.token(app)
        if (t.isBlank()) { Toast.makeText(app, "Aucune clé à vérifier.", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(app, "Vérification…", Toast.LENGTH_SHORT).show()
        app.bg.execute {
            val msg = try { Online.checkKey(t); "Clé valide ✓" }
            catch (e: IOException) { if (Pending.isNetworkError(e)) "Pas de connexion : impossible de vérifier." else "Clé refusée : ${e.message}" }
            app.runOnUiThread { AlertDialog.Builder(app).setMessage(msg).setPositiveButton("OK", null).show() }
        }
    }
}
