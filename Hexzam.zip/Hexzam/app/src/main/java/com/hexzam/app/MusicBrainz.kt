package com.hexzam.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Sorties récentes par pays d'après MusicBrainz (base libre, sans clé, alimentée par sa communauté).
 * La couverture varie selon les pays : ce n'est pas une liste exhaustive de tout ce qui sort.
 */
object MusicBrainz {
    data class Release(val title: String, val artist: String, val date: String, val type: String, val cover: String?)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    @Throws(IOException::class)
    fun recent(countryCode: String, days: Int, tags: String?): List<Release> {
        require(Regex("^[a-z]{2}$").matches(countryCode))
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val to = Calendar.getInstance()
        val from = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -days) }
        var q = "country:${countryCode.uppercase()} AND date:[${fmt.format(from.time)} TO ${fmt.format(to.time)}] AND status:official"
        if (!tags.isNullOrBlank()) q += " AND tag:($tags)"
        val c = URL("https://musicbrainz.org/ws/2/release/?query=${enc(q)}&fmt=json&limit=100").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 9000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", "HEXZAM/1.0 ( https://whatsapp.com/channel/0029VbDCmVWISTkNEy1D3p3H )")   // exigé par MusicBrainz
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val arr = json.optJSONArray("releases") ?: return emptyList()
            val seen = HashSet<String>()
            val out = ArrayList<Release>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("title")
                val artist = o.optJSONArray("artist-credit")?.optJSONObject(0)?.optString("name") ?: ""
                val date = o.optString("date")
                val type = o.optJSONObject("release-group")?.optString("primary-type")?.ifEmpty { null } ?: "Sortie"
                if (title.isEmpty() || artist.isEmpty() || date.length < 7) continue
                if (!seen.add("$title|$artist".lowercase())) continue
                out.add(Release(title, artist, date, type, "https://coverartarchive.org/release/${o.optString("id")}/front-250"))
            }
            return out.sortedByDescending { it.date }
        } catch (e: org.json.JSONException) {
            throw IOException("Réponse inattendue")
        } finally { c.disconnect() }
    }
}
