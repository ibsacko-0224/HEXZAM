package com.hexzam.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Cercles concentriques façon Shazam : ils pulsent avec le son ; l'hexagone tourne pendant l'analyse. */
class ListeningView(context: Context, private val p: Palette) : View(context) {
    enum class Mode { IDLE, LISTENING, ANALYZING }

    var mode = Mode.IDLE
        set(v) { field = v; invalidate() }
    private var level = 0f
    private var smooth = 0f
    private var phase = 0f
    private val path = Path()
    private val layer = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val hexPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = p.fg; style = Paint.Style.FILL }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = p.bg; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = p.fg; strokeCap = Paint.Cap.ROUND }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; smooth += (level - smooth) * 0.2f; invalidate() }
    }

    fun setLevel(l: Float) { level = l.coerceIn(0f, 1f) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun hex(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        for (i in 0 until 6) {
            val a = (-90 + 60 * i) * PI / 180
            val x = cx + r * cos(a).toFloat()
            val y = cy + r * sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, hexPaint)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.34f
        val wave = sin(phase * 2 * PI).toFloat()
        val pulse = when (mode) {
            Mode.LISTENING -> 1f + 0.10f * smooth + 0.025f * wave
            Mode.ANALYZING -> 1f + 0.02f * wave
            Mode.IDLE -> 1f + 0.012f * wave
        }
        layer.color = p.fg
        layer.alpha = 22; c.drawCircle(cx, cy, base * 2.75f * pulse, layer)
        layer.alpha = 38; c.drawCircle(cx, cy, base * 1.95f * pulse, layer)
        layer.alpha = 64; c.drawCircle(cx, cy, base * 1.38f * pulse, layer)
        layer.alpha = 90; c.drawCircle(cx, cy, base * 1.0f, layer)

        c.save()
        if (mode == Mode.ANALYZING) c.rotate(phase * 60f, cx, cy)   // 60° = symétrie de l'hexagone : boucle continue
        hex(c, cx, cy, base * 0.66f)
        c.restore()
        glyph.textSize = base * 0.62f
        c.drawText("H", cx, cy + glyph.textSize * 0.34f, glyph)

        if (mode == Mode.LISTENING) {                               // petite onde sous les cercles
            val by = cy + base * 3.25f
            val w = base * 0.09f
            bar.strokeWidth = w
            for (i in 0 until 5) {
                val h = base * (0.12f + 0.38f * (0.25f + 0.75f * smooth) * abs(sin((phase * 2 + i * 0.37f) * PI).toFloat()))
                val x = cx + (i - 2) * w * 2.6f
                c.drawLine(x, by - h, x, by + h, bar)
            }
        }
    }
}
