package com.hexzam.app

import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Tops : flux public d'Apple (Marketing Tools RSS), sans clé ni compte. Ce ne sont pas les classements de Shazam. */
object Charts {
    data class Item(val rank: Int, val title: String, val artist: String, val cover: String?, val url: String?, val genre: String?)

    val countries = listOf(
        "fr" to "France", "us" to "États-Unis", "gb" to "Royaume-Uni", "de" to "Allemagne", "es" to "Espagne",
        "it" to "Italie", "be" to "Belgique", "ch" to "Suisse", "ca" to "Canada", "br" to "Brésil",
        "mx" to "Mexique", "jp" to "Japon", "kr" to "Corée du Sud", "au" to "Australie", "nl" to "Pays-Bas",
        "pt" to "Portugal", "ma" to "Maroc", "dz" to "Algérie", "tn" to "Tunisie", "sn" to "Sénégal",
        "ci" to "Côte d’Ivoire", "cm" to "Cameroun", "ng" to "Nigeria", "za" to "Afrique du Sud", "in" to "Inde",
    )
    private val cache = HashMap<String, List<Item>>()

    @Throws(IOException::class)
    fun fetch(country: String, kind: String): List<Item> {
        require(countries.any { it.first == country } && (kind == "songs" || kind == "albums"))
        val key = "$country/$kind"
        cache[key]?.let { return it }
        var last: IOException? = null
        for (host in listOf("rss.marketingtools.apple.com", "rss.applemarketingtools.com")) {
            try {
                val c = URL("https://$host/api/v2/$country/music/most-played/50/$kind.json").openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 8000
                    c.readTimeout = 12000
                    if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONObject(text).getJSONObject("feed").getJSONArray("results")
                    val items = (0 until arr.length()).map { i ->
                        val o = arr.getJSONObject(i)
                        Item(
                            i + 1, o.optString("name"), o.optString("artistName"),
                            o.optString("artworkUrl100").takeIf { it.startsWith("https://") }?.replace("100x100", "400x400"),
                            o.optString("url").takeIf { it.startsWith("https://") },
                            o.optJSONArray("genres")?.optJSONObject(0)?.optString("name")?.takeIf { it.isNotEmpty() },
                        )
                    }
                    cache[key] = items
                    return items
                } finally { c.disconnect() }
            } catch (e: IOException) { last = e }
            catch (e: JSONException) { last = IOException("Réponse inattendue du service") }
        }
        throw last ?: IOException("Service indisponible")
    }
}
