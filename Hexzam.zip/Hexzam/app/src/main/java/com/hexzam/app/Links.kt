package com.hexzam.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object Links {
    private fun q(title: String, artist: String) = Uri.encode("$artist $title".trim())

    fun spotify(t: String, a: String) = "https://open.spotify.com/search/${q(t, a)}"
    fun youtube(t: String, a: String) = "https://www.youtube.com/results?search_query=${q(t, a)}"
    fun apple(t: String, a: String) = "https://music.apple.com/search?term=${q(t, a)}"
    fun deezer(t: String, a: String) = "https://www.deezer.com/search/${q(t, a)}"

    val apps = listOf("vidmate" to "VidMate", "spotify" to "Spotify", "youtube" to "YouTube", "deezer" to "Deezer")

    fun urlFor(app: String, t: String, a: String) = when (app) {
        "spotify" -> spotify(t, a); "deezer" -> deezer(t, a); else -> youtube(t, a)
    }

    fun lyrics(t: String, a: String) = "https://genius.com/search?q=${q(t, a)}"

    fun open(ctx: Context, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Aucune application pour ouvrir ce lien.", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(ctx: Context, text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    const val VIDMATE = "http://www.vidmate.mobi/puredownload?p=Mjg&f=co"
    const val VIDMATE_PKG = "com.nemo.vidmate"
    const val COMMUNITY = "https://whatsapp.com/channel/0029VbC8YkY7oQhiOiiSpy1z"
}
