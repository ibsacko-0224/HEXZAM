package com.hexzam.app

import android.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

/** Vignette carrée : pochette si disponible, sinon hexagone. */
fun MainActivity.thumb(url: String?, sizeDp: Int): View {
    val size = dp(sizeDp)
    if (url != null) {
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setBackgroundColor(palette.card)
        img.layoutParams = LinearLayout.LayoutParams(size, size)
        ImageLoader.load(this, url, Prefs.coverBw(this), img)
        return img
    }
    val t = tv("⬢", sizeDp * 0.45f, palette.fg)
    t.gravity = Gravity.CENTER
    t.setBackgroundColor(palette.card)
    t.layoutParams = LinearLayout.LayoutParams(size, size)
    return t
}

/** Menu ⋮ d'un titre de l'historique. */
fun MainActivity.trackMenu(h: HistoryItem, refresh: () -> Unit) {
    val names = arrayOf("Ouvrir", if (h.fav) "Retirer des favoris" else "Ajouter aux favoris", "Paroles", "Partager", "Supprimer")
    AlertDialog.Builder(this).setTitle(h.title).setItems(names) { _, i ->
        when (i) {
            0 -> push(TrackScreen(this, h.toInfo()))
            1 -> { db.setFav(h.id, !h.fav); refresh() }
            2 -> Links.open(this, Links.lyrics(h.title, h.artist))
            3 -> Links.share(this, "« ${h.title} » de ${h.artist} (avec HEXZAM)" + (h.link?.let { "\n$it" } ?: ""))
            4 -> { db.deleteHistory(h.id); refresh() }
        }
    }.show()
}

/** Liste de titres (tous, favoris, par artiste, par playlist) avec recherche. */
class TitlesScreen(app: MainActivity, private val title: String, private val filter: (HistoryItem) -> Boolean) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)
    private var query = ""

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val search = EditText(app)
        search.hint = "Rechercher"
        search.setHintTextColor(p.mute)
        search.setTextColor(p.fg)
        search.setSingleLine()
        search.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        search.setBackgroundColor(p.card)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim()?.lowercase() ?: ""; render() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(12), app.dp(16), app.dp(4)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame(title, app.scroll(col))
        render()
    }

    override fun onShow() = render()

    private fun render() {
        list.removeAllViews()
        val items = app.db.history().filter(filter).filter { query.isEmpty() || (it.title + " " + it.artist).lowercase().contains(query) }
        if (items.isEmpty()) {
            val t = app.tv("Aucun titre.", 15f, p.mute)
            t.gravity = Gravity.CENTER
            t.setPadding(0, app.dp(48), 0, 0)
            list.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        val fmt = DateFormat.getDateInstance(DateFormat.MEDIUM)
        for (h in items) {
            val row = LinearLayout(app)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(app.dp(16), app.dp(10), app.dp(4), app.dp(10))
            row.addView(app.thumb(h.cover, 56))
            val col = LinearLayout(app)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(app.dp(14), 0, app.dp(8), 0)
            col.addView(app.tv((if (h.fav) "♥ " else "") + h.title, 16f, p.fg, bold = true))
            col.addView(app.tv(h.artist, 13f, p.fg))
            col.addView(app.tv("${fmt.format(Date(h.ts))} · ${h.source}", 11f, p.mute, mono = true))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(app.icon("⋮") { app.trackMenu(h) { render() } })
            row.setOnClickListener { app.push(TrackScreen(app, h.toInfo())) }
            list.addView(row)
            list.addView(app.hairline(p))
        }
    }
}

class ArtistsScreen(app: MainActivity) : Screen(app) {
    override val view: View

    init {
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        val groups = app.db.history().groupBy { it.artist }.entries.sortedByDescending { it.value.size }
        if (groups.isEmpty()) c.addView(app.tv("Aucun artiste pour l’instant.", 15f, app.palette.mute).apply { setPadding(app.dp(24), app.dp(40), app.dp(24), 0) })
        for ((artist, items) in groups) {
            c.addView(app.menuRow(artist, "${items.size}") { app.push(TitlesScreen(app, artist) { it.artist == artist }) })
            c.addView(app.hairline(app.palette))
        }
        view = app.frame("Artistes", app.scroll(c))
    }
}

class PlaylistsScreen(app: MainActivity) : Screen(app) {
    override val view: View

    init {
        val now = System.currentTimeMillis()
        val day = 24L * 3600 * 1000
        val all = app.db.history()
        val lists = listOf<Pair<String, (HistoryItem) -> Boolean>>(
            "Cette semaine" to { h -> now - h.ts < 7 * day },
            "Ce mois-ci" to { h -> now - h.ts < 30 * day },
            "Favoris" to { h -> h.fav },
            "Découvertes en ligne" to { h -> h.source == "EN LIGNE" },
            "Reconnus dans ma bibliothèque" to { h -> h.source == "LOCAL" },
        )
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        for ((name, f) in lists) {
            c.addView(app.menuRow(name, "${all.count(f)}") { app.push(TitlesScreen(app, name, f)) })
            c.addView(app.hairline(app.palette))
        }
        view = app.frame("Playlists pour vous", app.scroll(c))
    }
}
