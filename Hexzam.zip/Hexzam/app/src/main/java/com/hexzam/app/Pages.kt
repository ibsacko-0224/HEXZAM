package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

/** Page centrale : le grand bouton. */
class HomePage(private val app: MainActivity) {
    private val p = app.palette
    val view: View
    private val notes = LinearLayout(app)

    init {
        val root = FrameLayout(app)
        root.setBackgroundColor(p.bg)
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val logo = android.widget.ImageView(app)
        logo.setImageResource(R.drawable.logo)
        logo.contentDescription = "HEXZAM"
        col.addView(logo, LinearLayout.LayoutParams(app.dp(72), app.dp(72)).apply { topMargin = app.dp(8) })
        val circles = ListeningView(app, p)
        circles.setOnClickListener { app.startListening() }
        circles.contentDescription = "Reconnaître une musique"
        col.addView(circles, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(app.tv("Touchez pour reconnaître", 20f, p.fg, bold = true).apply { gravity = Gravity.CENTER })
        col.addView(app.tv("Un seul appui : HEXZAM écoute et trouve le titre", 13f, p.mute).apply { gravity = Gravity.CENTER; setPadding(0, app.dp(4), 0, 0) })
        notes.orientation = LinearLayout.VERTICAL
        col.addView(notes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(20), app.dp(16), app.dp(20), app.dp(28)) })
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { topMargin = app.dp(56) })
        root.addView(app.icon("⚙") { app.openSettings() }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(26); leftMargin = app.dp(6) })
        view = root
        refresh()
    }

    fun refresh() {
        notes.removeAllViews()
        if (Prefs.online(app) && Prefs.token(app).isBlank()) {
            notes.addView(app.flatButton("Clé API manquante · ouvrir les réglages", p, true) { app.openSettings() })
        }
        val n = Pending.count(app)
        if (n > 0) notes.addSpaced(app.flatButton("$n extrait(s) en attente de connexion · réessayer", p) { app.retryPending() }, 8)
    }
}

/** Page de gauche : Bibliothèque (titres, artistes, favoris, playlists, explorer, récents). */
class LibraryPage(private val app: MainActivity) {
    private val p = app.palette
    val view: View
    private val body = LinearLayout(app)

    init {
        val root = FrameLayout(app)
        root.setBackgroundColor(p.bg)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(app.dp(16), app.dp(64), app.dp(16), app.dp(32))
        root.addView(app.scroll(body), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(app.icon("⚙") { app.openSettings() }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(26); leftMargin = app.dp(6) })
        root.addView(app.tv("Bibliothèque", 20f, p.fg, bold = true).apply { gravity = Gravity.CENTER },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(36) })
        view = root
        refresh()
    }

    private fun card(label: String, value: String?, onClick: () -> Unit): View {
        val row = LinearLayout(app)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(app.dp(16), app.dp(18), app.dp(16), app.dp(18))
        row.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.line) }
        row.addView(app.tv("⬢", 18f, p.fg).apply { setPadding(0, 0, app.dp(14), 0) })
        row.addView(app.tv(label, 17f, p.fg, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (value != null) row.addView(app.tv(value, 16f, p.mute, mono = true))
        row.setOnClickListener { onClick() }
        return row
    }

    fun refresh() {
        body.removeAllViews()
        val all = app.db.history()
        body.addSpaced(card("Titres", "${all.size}") { app.push(TitlesScreen(app, "Titres") { true }) }, 0)
        body.addSpaced(card("Artistes", null) { app.push(ArtistsScreen(app)) }, 8)
        body.addSpaced(card("Favoris", "${all.count { it.fav }}") { app.push(TitlesScreen(app, "Favoris") { it.fav }) }, 8)
        body.addSpaced(card("Playlists pour vous", null) { app.push(PlaylistsScreen(app)) }, 8)
        body.addSpaced(card("Ma musique locale", "${app.db.tracks().size}") { app.push(LocalLibraryScreen(app)) }, 8)

        // Explorer : meilleurs artistes et genres
        val artists = all.groupBy { it.artist }.entries.sortedByDescending { it.value.size }.take(6)
        val genres = all.mapNotNull { it.genre }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(4)
        if (artists.isNotEmpty()) {
            val head = LinearLayout(app)
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(app.tv("Explorer", 24f, p.fg, bold = true))
            head.addView(app.tv("NOUVEAU", 10f, p.bg, bold = true, mono = true).apply { setPadding(app.dp(8), app.dp(3), app.dp(8), app.dp(3)); setBackgroundColor(p.fg) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = app.dp(10) })
            body.addSpaced(head, 28)
            body.addSpaced(app.tv("Vos artistes et genres préférés, d’après vos titres reconnus", 13f, p.mute), 4)
            val hs = HorizontalScrollView(app)
            hs.isHorizontalScrollBarEnabled = false
            val chips = LinearLayout(app)
            fun chip(label: String, count: Int, cover: String?, f: (HistoryItem) -> Unit) {
                val c = LinearLayout(app)
                c.gravity = Gravity.CENTER_VERTICAL
                c.setPadding(app.dp(10), app.dp(10), app.dp(18), app.dp(10))
                c.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.line) }
                c.addView(app.thumb(cover, 40))
                c.addView(app.tv("$label ($count)", 15f, p.fg, bold = true).apply { setPadding(app.dp(10), 0, 0, 0) })
                c.setOnClickListener { f(all.first()) }
                chips.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = app.dp(8) })
            }
            for ((a, items) in artists) {
                chip(a, items.size, items.firstOrNull { it.cover != null }?.cover) { app.push(TitlesScreen(app, a) { it.artist == a }) }
            }
            for ((g, n) in genres) chip(g, n, all.firstOrNull { it.genre == g && it.cover != null }?.cover) { app.push(TitlesScreen(app, g) { it.genre == g }) }
            hs.addView(chips)
            body.addSpaced(hs, 12)
        }

        // Récents : grille de pochettes
        body.addSpaced(app.tv("Récents", 24f, p.fg, bold = true), 28)
        val recent = all.take(6)
        if (recent.isEmpty()) {
            body.addSpaced(app.tv("Rien pour l’instant. Touchez le bouton de la page centrale pour reconnaître votre première musique.", 14f, p.mute), 8)
        }
        val screenW = app.resources.displayMetrics.widthPixels
        val cardW = (screenW - app.dp(32) - app.dp(12)) / 2
        for (pair in recent.chunked(2)) {
            val row = LinearLayout(app)
            for ((i, h) in pair.withIndex()) {
                val c = LinearLayout(app)
                c.orientation = LinearLayout.VERTICAL
                c.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.line) }
                c.addView(app.thumb(h.cover, 10).apply { layoutParams = LinearLayout.LayoutParams(cardW, cardW) })
                c.addView(app.tv(h.title, 15f, p.fg, bold = true).apply { setPadding(app.dp(12), app.dp(10), app.dp(12), 0); maxLines = 2 })
                c.addView(app.tv(h.artist, 13f, p.mute).apply { setPadding(app.dp(12), 0, app.dp(12), app.dp(4)); maxLines = 1 })
                c.addView(app.icon("⋮") { app.trackMenu(h) { refresh() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END })
                c.setOnClickListener { app.push(TrackScreen(app, h.toInfo())) }
                row.addView(c, LinearLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (i > 0) leftMargin = app.dp(12) })
            }
            body.addSpaced(row, 12)
        }
    }
}

/** Page de droite : Les Tops. */
class TopsPage(private val app: MainActivity) {
    private val p = app.palette
    val view: View

    init {
        val root = FrameLayout(app)
        root.setBackgroundColor(p.bg)
        val c = LinearLayout(app)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(app.dp(16), app.dp(64), app.dp(16), app.dp(32))
        c.addView(app.tv("Les plus belles découvertes musicales du monde entier", 24f, p.fg, bold = true).apply { gravity = Gravity.CENTER; setPadding(app.dp(8), app.dp(8), app.dp(8), app.dp(8)) })
        c.addSpaced(app.tv("Nouveautés par genre, classements et découvertes pays par pays.", 13f, p.mute).apply { gravity = Gravity.CENTER }, 0)
        fun big(symbol: String, small: String, big: String, onClick: () -> Unit) {
            val row = LinearLayout(app)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(app.dp(18), app.dp(22), app.dp(18), app.dp(22))
            row.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(2), p.fg) }
            val box = app.tv(symbol, 34f, p.bg).apply { gravity = Gravity.CENTER; setBackgroundColor(p.fg) }
            row.addView(box, LinearLayout.LayoutParams(app.dp(84), app.dp(84)))
            val col = LinearLayout(app)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(app.dp(18), 0, 0, 0)
            col.addView(app.tv(small, 13f, p.mute, mono = true))
            col.addView(app.tv(big, 22f, p.fg, bold = true))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { onClick() }
            c.addSpaced(row, 14)
        }
        big("☆", "Leurs vraies sorties, par date", "Mes artistes") { app.push(MyArtistsScreen(app)) }
        big("NEW", "Chaque semaine", "Nouveautés") { app.push(NewReleasesScreen(app)) }
        big("★", "Nouvelles sorties, classement, styles", "Mon pays : ${Countries.name(Prefs.myCountry(app))}") { app.push(CountryScreen(app, Prefs.myCountry(app))) }
        big("🌍", "Tous les pays du monde", "Top par pays") { app.pickCountry { code -> app.push(CountryScreen(app, code)) } }
        big("♪", "Écoute complète · téléchargement légal", "Musique libre") { app.push(FreeMusicScreen(app)) }
        big("◉", "Top 50", "Albums populaires") { app.pickCountry { code -> app.push(ChartScreen(app, "albums", code)) } }
        root.addView(app.scroll(c), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(app.tv("Les Tops", 20f, p.fg, bold = true).apply { gravity = Gravity.CENTER },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(36) })
        view = root
    }
}
