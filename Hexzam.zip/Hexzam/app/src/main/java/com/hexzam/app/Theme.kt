package com.hexzam.app

import android.content.Context
import android.content.res.Configuration

/** Noir et blanc uniquement. */
class Palette(val dark: Boolean, val bg: Int, val fg: Int, val mute: Int, val line: Int, val card: Int)

object Theme {
    fun palette(c: Context): Palette {
        val dark = when (Prefs.theme(c)) {
            "light" -> false
            "system" -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            else -> true
        }
        return if (dark) Palette(true, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF8C8C8C.toInt(), 0xFF2B2B2B.toInt(), 0xFF111111.toInt())
        else Palette(false, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF6E6E6E.toInt(), 0xFFD9D9D9.toInt(), 0xFFF2F2F2.toInt())
    }
}
