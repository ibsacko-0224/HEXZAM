package com.hexzam.app

import android.app.AlertDialog
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.IOException

/** Musique libre : écoute complète et téléchargement légal (licences Creative Commons, via Jamendo). */
class FreeMusicScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val chips = LinearLayout(app)
    private val list = LinearLayout(app)
    private val handler = Handler(Looper.getMainLooper())
    private var selected = 0
    private var query = ""
    private var seq = 0

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val box = EditText(app)
        box.hint = "Rechercher de la musique libre"
        box.setHintTextColor(p.mute)
        box.setTextColor(p.fg)
        box.setSingleLine()
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        box.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        box.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { handler.removeCallbacksAndMessages(null); query = box.text.toString(); load(); true } else false }
        box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { handler.removeCallbacksAndMessages(null); handler.postDelayed({ query = s?.toString() ?: ""; load() }, 600) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(12), app.dp(16), app.dp(4)) })
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        col.addView(hs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(12), app.dp(6), app.dp(12), app.dp(4)) })
        col.addView(app.tv("Musique publiée par ses artistes sous licence Creative Commons. Écoute complète ; ⬇ quand l’artiste autorise le téléchargement. Respectez la licence de chaque titre.", 12f, p.mute).apply { setPadding(app.dp(16), app.dp(4), app.dp(16), app.dp(8)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        val downloads = app.icon("⬇") { app.openDownloads() }
        view = app.frame("Musique libre", app.scroll(col), downloads)
        drawChips()
        load()
    }

    private fun drawChips() {
        chips.removeAllViews()
        Jamendo.styles.forEachIndexed { i, s ->
            val on = i == selected && query.isBlank()
            val t = app.tv(s.first.uppercase(), 12f, if (on) p.bg else p.fg, bold = true, mono = true)
            t.setPadding(app.dp(14), app.dp(9), app.dp(14), app.dp(9))
            t.background = GradientDrawable().apply { setColor(if (on) p.fg else p.bg); setStroke(app.dp(1), p.fg) }
            t.setOnClickListener { selected = i; query = ""; drawChips(); load() }
            chips.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = app.dp(8) })
        }
    }

    private fun load() {
        list.removeAllViews()
        val id = Prefs.jamendoId(app)
        if (id.isBlank()) {
            list.addView(app.centered("Cette section demande un identifiant gratuit Jamendo (client_id). Créez-le sur devportal.jamendo.com puis saisissez-le ici."))
            list.addView(app.flatButton("Saisir mon identifiant", p, true) { app.promptJamendo { load() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(24), app.dp(8), app.dp(24), 0) })
            list.addView(app.flatButton("Créer un identifiant", p) { Links.open(app, "https://devportal.jamendo.com") }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(24), app.dp(8), app.dp(24), 0) })
            return
        }
        list.addView(app.centered("Chargement…"))
        val my = ++seq
        val style = Jamendo.styles[selected]
        val q = query
        app.bg.execute {
            val r = try { Result.success(Jamendo.tracks(id, q, style.second, style.third, dlFormat = Prefs.dlFormat(app))) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != seq) return@runOnUiThread
                list.removeAllViews()
                val tracks = r.getOrNull()
                when {
                    tracks == null -> list.addView(app.centered("Impossible de charger (${r.exceptionOrNull()?.message ?: "réseau"})."))
                    tracks.isEmpty() -> list.addView(app.centered("Aucun résultat."))
                    else -> show(tracks)
                }
            }
        }
    }

    private fun show(tracks: List<Jamendo.JTrack>) {
        val playable = tracks.map { it.toPlayable() }
        tracks.forEachIndexed { i, t ->
            val row = app.musicRow(null, t.cover, t.title, t.artist, t.license, onPlay = { Player.play(playable, i) }) { details(t, playable, i) } as LinearLayout
            if (t.downloadAllowed) row.addView(app.icon("⬇") { app.downloadTrack(t) })
            list.addView(row)
            list.addView(app.hairline(p))
        }
    }

    private fun details(t: Jamendo.JTrack, playable: List<Deezer.Track>, i: Int) {
        val b = AlertDialog.Builder(app).setTitle(t.title)
            .setMessage("${t.artist}\n${t.album}\n\nLicence : ${t.license ?: "Creative Commons"}\n\nCe titre est publié par son artiste sous licence Creative Commons : respectez ses conditions (attribution, usage non commercial…).")
            .setPositiveButton("Écouter") { _, _ -> Player.play(playable, i) }
            .setNeutralButton("Page Jamendo") { _, _ -> t.share?.let { Links.open(app, it) } }
        if (t.downloadAllowed) b.setNegativeButton("Télécharger") { _, _ -> app.downloadTrack(t) } else b.setNegativeButton("Fermer", null)
        b.show()
    }
}
