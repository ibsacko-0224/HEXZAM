package com.hexzam.app

import android.content.Context

/** Réglages locaux (SharedPreferences privées). Rien n'est envoyé nulle part. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hexzam", Context.MODE_PRIVATE)

    fun theme(c: Context): String = sp(c).getString("theme", "dark") ?: "dark"          // dark | light | system
    fun setTheme(c: Context, v: String) = sp(c).edit().putString("theme", v).apply()

    fun listenSeconds(c: Context) = sp(c).getInt("listen", 8)
    fun setListenSeconds(c: Context, v: Int) = sp(c).edit().putInt("listen", v).apply()

    fun strictness(c: Context) = sp(c).getInt("strict", 1)                              // 0 souple, 1 normal, 2 strict
    fun setStrictness(c: Context, v: Int) = sp(c).edit().putInt("strict", v).apply()
    fun minVotes(c: Context) = when (strictness(c)) { 0 -> 4; 2 -> 10; else -> 6 }

    fun haptics(c: Context) = sp(c).getBoolean("haptics", true)
    fun setHaptics(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptics", v).apply()

    fun online(c: Context) = sp(c).getBoolean("online", true)                           // reconnaissance directe par défaut
    fun setOnline(c: Context, v: Boolean) = sp(c).edit().putBoolean("online", v).apply()

    fun token(c: Context): String = (sp(c).getString("token", "") ?: "").ifBlank { BuildConfig.AUDD_TOKEN }
    fun setToken(c: Context, v: String) = sp(c).edit().putString("token", v.trim()).apply()

    fun notifyResult(c: Context) = sp(c).getBoolean("notify_result", true)
    fun setNotifyResult(c: Context, v: Boolean) = sp(c).edit().putBoolean("notify_result", v).apply()

    fun quickNotif(c: Context) = sp(c).getBoolean("quick_notif", false)
    fun setQuickNotif(c: Context, v: Boolean) = sp(c).edit().putBoolean("quick_notif", v).apply()

    fun autoInterval(c: Context) = sp(c).getInt("auto_interval", 60)
    fun setAutoInterval(c: Context, v: Int) = sp(c).edit().putInt("auto_interval", v).apply()

    fun coverBw(c: Context) = sp(c).getBoolean("cover_bw", true)
    fun setCoverBw(c: Context, v: Boolean) = sp(c).edit().putBoolean("cover_bw", v).apply()

    fun musicApp(c: Context): String = sp(c).getString("music_app", "vidmate") ?: "vidmate"
    fun setMusicApp(c: Context, v: String) = sp(c).edit().putString("music_app", v).apply()

    fun listenOnStart(c: Context) = sp(c).getBoolean("listen_on_start", false)
    fun setListenOnStart(c: Context, v: Boolean) = sp(c).edit().putBoolean("listen_on_start", v).apply()

    fun coverWifiOnly(c: Context) = sp(c).getBoolean("cover_wifi", false)
    fun setCoverWifiOnly(c: Context, v: Boolean) = sp(c).edit().putBoolean("cover_wifi", v).apply()

    fun resetAll(c: Context) = sp(c).edit().clear().apply()

    fun jamendoId(c: Context): String = (sp(c).getString("jamendo", "") ?: "").ifBlank { BuildConfig.JAMENDO_ID }
    fun setJamendoId(c: Context, v: String) = sp(c).edit().putString("jamendo", v.trim()).apply()

    /** Mon pays : région du téléphone, sinon la Guinée. */
    fun myCountry(c: Context): String = sp(c).getString("my_country", null)
        ?: java.util.Locale.getDefault().country.lowercase().ifBlank { "gn" }
    fun setMyCountry(c: Context, v: String) = sp(c).edit().putString("my_country", v).apply()

    fun releaseDays(c: Context) = sp(c).getInt("release_days", 90)
    fun setReleaseDays(c: Context, v: Int) = sp(c).edit().putInt("release_days", v).apply()

    fun startTab(c: Context) = sp(c).getInt("start_tab", 1)
    fun setStartTab(c: Context, v: Int) = sp(c).edit().putInt("start_tab", v).apply()

    fun autoNext(c: Context) = sp(c).getBoolean("auto_next", true)
    fun setAutoNext(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_next", v).apply()

    fun dlFormat(c: Context): String = sp(c).getString("dl_format", "mp32") ?: "mp32"      // mp32 = MP3, ogg = OGG
    fun setDlFormat(c: Context, v: String) = sp(c).edit().putString("dl_format", v).apply()

    fun vidmateMode(c: Context): String = sp(c).getString("vidmate_mode", "app") ?: "app"   // app | search | link
    fun setVidmateMode(c: Context, v: String) = sp(c).edit().putString("vidmate_mode", v).apply()
}
