package com.hexzam.app

import android.content.Context

/** Réglages locaux (SharedPreferences privées). Rien n'est envoyé nulle part. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hexzam", Context.MODE_PRIVATE)

    fun theme(c: Context): String = sp(c).getString("theme", "dark") ?: "dark"          // dark | light | system
    fun setTheme(c: Context, v: String) = sp(c).edit().putString("theme", v).apply()

    fun listenSeconds(c: Context) = sp(c).getInt("listen", 8)
    fun setListenSeconds(c: Context, v: Int) = sp(c).edit().putInt("listen", v).apply()

    fun strictness(c: Context) = sp(c).getInt("strict", 1)                              // 0 souple, 1 normal, 2 strict
    fun setStrictness(c: Context, v: Int) = sp(c).edit().putInt("strict", v).apply()
    fun minVotes(c: Context) = when (strictness(c)) { 0 -> 4; 2 -> 10; else -> 6 }

    fun haptics(c: Context) = sp(c).getBoolean("haptics", true)
    fun setHaptics(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptics", v).apply()

    fun online(c: Context) = sp(c).getBoolean("online", false)                          // désactivé par défaut
    fun setOnline(c: Context, v: Boolean) = sp(c).edit().putBoolean("online", v).apply()

    fun token(c: Context): String = sp(c).getString("token", "") ?: ""
    fun setToken(c: Context, v: String) = sp(c).edit().putString("token", v.trim()).apply()
}
