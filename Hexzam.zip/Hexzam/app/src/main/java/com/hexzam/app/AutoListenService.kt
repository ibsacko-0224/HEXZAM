package com.hexzam.app

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.app.NotificationManager
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Écoute continue (comme « Auto Shazam ») : toutes les N secondes, écoute 8 s et reconnaît.
 * Démarrée par l'utilisateur depuis l'application, affiche une notification permanente avec bouton « Arrêter ».
 */
class AutoListenService : Service() {
    companion object {
        const val ACTION_STOP = "com.hexzam.app.STOP_AUTO"
        val running = AtomicBoolean(false)
    }

    @Volatile private var stopFlag = false
    private var thread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = Notifier.autoNotification(this, "À l’écoute…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(Notifier.ID_AUTO, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(Notifier.ID_AUTO, n)
        if (running.compareAndSet(false, true)) {
            stopFlag = false
            thread = Thread { loop() }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun loop() {
        val db = HexDb(this)
        var last = ""
        while (!stopFlag) {
            val out = try { Recognizer(this, db).run(8, {}, {}, { stopFlag }) } catch (e: Exception) { Outcome.NotFound }
            if (out is Outcome.Found) {
                val key = out.title + "|" + out.artist
                if (key != last) {                              // pas de doublon pour le même morceau
                    last = key
                    db.addHistory(out.title, out.artist, out.album, out.source, out.link, out.cover, out.preview, out.genre)
                    Notifier.showResult(this, out.title, out.artist)
                }
            }
            var waited = 0
            val gap = Prefs.autoInterval(this)
            while (!stopFlag && waited < gap) { try { Thread.sleep(1000) } catch (e: InterruptedException) { return }; waited++ }
        }
    }

    override fun onDestroy() {
        stopFlag = true
        running.set(false)
        thread?.interrupt()
        getSystemService(NotificationManager::class.java).cancel(Notifier.ID_AUTO)
        super.onDestroy()
    }
}
