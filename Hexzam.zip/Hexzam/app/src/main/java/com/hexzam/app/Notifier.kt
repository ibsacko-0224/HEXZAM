package com.hexzam.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build

object Notifier {
    const val CH_RESULT = "result"
    const val CH_AUTO = "auto"
    const val CH_QUICK = "quick"
    const val ID_QUICK = 10
    const val ID_AUTO = 11

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RESULT, "Titres reconnus", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_AUTO, "Écoute continue", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_QUICK, "Bouton d’écoute rapide", NotificationManager.IMPORTANCE_LOW))
    }

    fun canPost(c: Context) =
        Build.VERSION.SDK_INT < 33 || c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Ouvre l'application et lance l'écoute immédiatement. */
    fun listenIntent(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).putExtra("autostart", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(c, 1, i, FLAGS)
    }

    private fun openIntent(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(c, 2, i, FLAGS)
    }

    fun showResult(c: Context, title: String, artist: String) {
        if (!Prefs.notifyResult(c) || !canPost(c)) return
        ensureChannels(c)
        val n = Notification.Builder(c, CH_RESULT)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(openIntent(c))
            .setAutoCancel(true)
            .build()
        c.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % 100000).toInt() + 100, n)
    }

    /** Notification permanente avec bouton « Écouter » (comme le raccourci de Shazam). */
    fun syncQuick(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!Prefs.quickNotif(c) || !canPost(c)) { nm.cancel(ID_QUICK); return }
        ensureChannels(c)
        val action = Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_notif), "Écouter", listenIntent(c)).build()
        val n = Notification.Builder(c, CH_QUICK)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("HEXZAM")
            .setContentText("Touchez pour reconnaître une musique")
            .setContentIntent(listenIntent(c))
            .addAction(action)
            .setOngoing(true)
            .build()
        nm.notify(ID_QUICK, n)
    }

    fun autoNotification(c: Context, text: String): Notification {
        ensureChannels(c)
        val stop = PendingIntent.getService(c, 3, Intent(c, AutoListenService::class.java).setAction(AutoListenService.ACTION_STOP), FLAGS)
        return Notification.Builder(c, CH_AUTO)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("HEXZAM · écoute continue")
            .setContentText(text)
            .setContentIntent(openIntent(c))
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_notif), "Arrêter", stop).build())
            .setOngoing(true)
            .build()
    }

    fun bubbleNotification(c: Context): Notification {
        ensureChannels(c)
        val stop = PendingIntent.getService(c, 5, Intent(c, BubbleService::class.java).setAction(BubbleService.ACTION_STOP), FLAGS)
        return Notification.Builder(c, CH_AUTO)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Pop-up HEXZAM")
            .setContentText("Le bouton flottant est actif")
            .setContentIntent(openIntent(c))
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_notif), "Arrêter", stop).build())
            .setOngoing(true)
            .build()
    }
}
