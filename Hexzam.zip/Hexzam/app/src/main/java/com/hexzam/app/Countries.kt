package com.hexzam.app

import java.util.Locale

/** Tous les pays du monde (noms en français, d'après la liste ISO du téléphone). */
object Countries {
    data class C(val code: String, val name: String)

    val all: List<C> by lazy {
        Locale.getISOCountries().map { C(it.lowercase(), Locale("", it).getDisplayCountry(Locale.FRENCH)) }
            .filter { it.name.isNotBlank() && it.name.length > 1 }
            .sortedBy { java.text.Normalizer.normalize(it.name, java.text.Normalizer.Form.NFD).lowercase() }
    }

    fun name(code: String) = all.firstOrNull { it.code == code }?.name ?: code.uppercase()
}
