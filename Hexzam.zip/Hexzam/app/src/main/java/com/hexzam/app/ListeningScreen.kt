package com.hexzam.app

import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Écran d'écoute plein écran : cercles qui pulsent, ✕ pour annuler. Se transforme en écran de résultat. */
class ListeningScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val circles = ListeningView(app, p)
    private val title: TextView = app.tv("En écoute de musique", 22f, p.fg, bold = true)
    private val sub: TextView = app.tv("Assurez-vous que votre appareil peut entendre clairement le titre", 14f, p.mute)
    private val actions = LinearLayout(app)
    @Volatile private var cancelled = false
    @Volatile private var closed = false

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(p.bg)
        col.addView(app.icon("✕") { app.pop() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(12); leftMargin = app.dp(8) })
        col.addView(circles, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        title.gravity = Gravity.CENTER
        sub.gravity = Gravity.CENTER
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = app.dp(24); rightMargin = app.dp(24) })
        col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(6); leftMargin = app.dp(24); rightMargin = app.dp(24) })
        actions.orientation = LinearLayout.VERTICAL
        col.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(16); leftMargin = app.dp(24); rightMargin = app.dp(24); bottomMargin = app.dp(36) })
        view = col
        start()
    }

    private fun start() {
        cancelled = false
        actions.removeAllViews()
        title.text = "En écoute de musique"
        sub.text = "Assurez-vous que votre appareil peut entendre clairement le titre"
        circles.mode = ListeningView.Mode.LISTENING
        val secs = Prefs.listenSeconds(app)
        app.worker.execute {
            val outcome = try {
                Recognizer(app, app.db).run(secs,
                    { l -> app.runOnUiThread { circles.setLevel(l) } },
                    { ph -> app.runOnUiThread { phase(ph) } },
                    { cancelled })
            } catch (e: Exception) {
                Outcome.Failed("Erreur inattendue : ${e.message ?: "inconnue"}")
            }
            app.runOnUiThread { finish(outcome) }
        }
    }

    private fun phase(ph: String) {
        if (closed) return
        circles.mode = ListeningView.Mode.ANALYZING
        title.text = if (ph == "online") "Recherche en ligne…" else "Analyse…"
        sub.text = "Un instant"
    }

    private fun finish(o: Outcome) {
        if (closed) return
        circles.mode = ListeningView.Mode.IDLE
        circles.setLevel(0f)
        when (o) {
            is Outcome.Found -> {
                val id = app.db.addHistory(o.title, o.artist, o.album, o.source, o.link, o.cover, o.preview, o.genre)
                if (Prefs.haptics(app)) circles.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                app.replaceTop(TrackScreen(app, TrackInfo(o.title, o.artist, o.album, o.source, o.link, o.cover, o.preview, o.genre, id)))
            }
            Outcome.NotFound -> message(
                "Aucun résultat",
                if (Prefs.online(app) && Prefs.token(app).isNotBlank()) "Impossible de trouver une correspondance. Rapprochez-vous de la source et réessayez."
                else "Morceau absent de votre bibliothèque. Pour reconnaître n’importe quelle musique, activez la reconnaissance en ligne et collez votre clé dans les réglages.",
                retry = true
            )
            Outcome.Queued -> message("Hors-ligne", "Pas de connexion : l’extrait est gardé sur le téléphone et sera reconnu dès que le réseau revient.", retry = false)
            Outcome.Cancelled -> app.pop()
            is Outcome.Failed -> message("Erreur", o.message, retry = true)
        }
    }

    private fun message(t: String, text: String, retry: Boolean) {
        title.text = t
        sub.text = text
        actions.removeAllViews()
        if (retry) actions.addView(app.flatButton("Réessayer", p, true) { start() })
        actions.addSpaced(app.flatButton("Fermer", p) { app.pop() }, 8)
    }

    override fun onClose() { closed = true; cancelled = true }
}
