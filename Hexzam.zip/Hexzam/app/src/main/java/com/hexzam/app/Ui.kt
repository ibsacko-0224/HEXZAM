package com.hexzam.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.tv(text: String, size: Float, color: Int, bold: Boolean = false, mono: Boolean = false, spacing: Float = 0f): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    t.setTextColor(color)
    t.typeface = if (mono) Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
    else Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    if (spacing != 0f) t.letterSpacing = spacing
    return t
}

/** Bouton plat, angles droits, filet d'un pixel : noir et blanc uniquement. */
fun Context.flatButton(text: String, p: Palette, filled: Boolean = false, onClick: () -> Unit): TextView {
    val t = tv(text.uppercase(), 12f, if (filled) p.bg else p.fg, bold = true, mono = true, spacing = 0.08f)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(13), dp(14), dp(13))
    fun shape(fill: Int) = GradientDrawable().apply { setColor(fill); setStroke(dp(1), p.fg) }
    t.background = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), shape(p.mute))
        addState(intArrayOf(), shape(if (filled) p.fg else p.bg))
    }
    t.setOnClickListener { onClick() }
    return t
}

fun Context.hairline(p: Palette): View {
    val v = View(this)
    v.setBackgroundColor(p.line)
    v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    return v
}

fun LinearLayout.addSpaced(v: View, top: Int = 0, ctx: Context = context): View {
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = ctx.dp(top)
    addView(v, lp)
    return v
}
