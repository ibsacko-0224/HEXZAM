package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import java.io.IOException
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Artistes suivis : leurs vraies sorties récentes, triées par date (comme « Nouveautés » de Spotify). */
object Follows {
    fun list(app: MainActivity): List<Deezer.Artist> = Prefs.follows(app).mapNotNull {
        val parts = it.split("|", limit = 2)
        parts[0].toLongOrNull()?.let { id -> Deezer.Artist(id, parts.getOrElse(1) { "" }, null) }
    }.sortedBy { it.name.lowercase() }

    fun isFollowed(app: MainActivity, id: Long) = Prefs.follows(app).any { it.startsWith("$id|") }

    fun toggle(app: MainActivity, a: Deezer.Artist): Boolean {
        val cur = Prefs.follows(app).toMutableSet()
        val key = cur.firstOrNull { it.startsWith("${a.id}|") }
        return if (key != null) { cur.remove(key); Prefs.setFollows(app, cur); false } else { cur.add("${a.id}|${a.name}"); Prefs.setFollows(app, cur); true }
    }

    /** Dernières sorties de tous les artistes suivis, la plus récente en premier. */
    fun releases(app: MainActivity): List<Deezer.Album> {
        val artists = list(app).take(40)
        if (artists.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(4)
        try {
            val jobs = artists.map { a -> Callable { try { Deezer.artistAlbums(a, 10) } catch (e: IOException) { emptyList<Deezer.Album>() } } }
            return pool.invokeAll(jobs).flatMap { it.get() }
                .distinctBy { "${it.title}|${it.artist}".lowercase() }
                .sortedByDescending { it.date ?: "" }
        } finally { pool.shutdown() }
    }

    fun toCards(app: MainActivity, list: List<Deezer.Album>, days: Int): List<Card> {
        val limit = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -days) }
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return list.map { a ->
            val fresh = (a.date ?: "") >= fmt.format(limit.time)
            Card(a.cover, a.title, a.artist, ((if (fresh) "NOUVEAU · " else "") + (a.type ?: "album").uppercase() + " · " + prettyDate(a.date)).trim(), { app.push(AlbumScreen(app, a)) })
        }
    }
}

class MyArtistsScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val newsBox = LinearLayout(app)
    private val resultsBox = LinearLayout(app)
    private val followBox = LinearLayout(app)
    private val handler = Handler(Looper.getMainLooper())
    private var seq = 0

    companion object {
        /** Suggestions de départ pour la Guinée : à vérifier et retirer si elles ne conviennent pas. */
        val guineaSeeds = listOf("Takana Zion", "Sekouba Bambino", "Djanii Alfa", "Instinct Killers", "Soul Bang's", "Degg J Force 3", "Elie Kamano", "Ba Cissoko", "Kerfala Bantama Sidibé", "Mory Kanté")
    }

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, app.dp(32))
        val box = EditText(app)
        box.hint = "Chercher un artiste à suivre"
        box.setHintTextColor(p.mute)
        box.setTextColor(p.fg)
        box.setSingleLine()
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        box.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        box.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { handler.removeCallbacksAndMessages(null); search(box.text.toString()); true } else false }
        box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { handler.removeCallbacksAndMessages(null); handler.postDelayed({ search(s?.toString() ?: "") }, 600) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(12), app.dp(16), app.dp(4)) })
        resultsBox.orientation = LinearLayout.VERTICAL
        col.addView(resultsBox)
        newsBox.orientation = LinearLayout.VERTICAL
        col.addView(newsBox)
        followBox.orientation = LinearLayout.VERTICAL
        col.addView(followBox)
        view = app.frame("Mes artistes", app.scroll(col))
        refresh()
    }

    private fun refresh() {
        drawFollowed()
        newsBox.removeAllViews()
        if (Follows.list(app).isEmpty()) {
            newsBox.addView(app.centered("Suivez vos artistes (cherchez-les ci-dessus) : leurs nouvelles sorties s’afficheront ici, triées par date."))
            return
        }
        newsBox.addView(app.centered("Chargement des sorties…"))
        app.bg.execute {
            val list = Follows.releases(app)
            app.runOnUiThread {
                newsBox.removeAllViews()
                if (list.isEmpty()) { newsBox.addView(app.centered("Aucune sortie trouvée pour vos artistes.")); return@runOnUiThread }
                val cards = Follows.toCards(app, list.take(60), Prefs.releaseDays(app))
                app.carousel(newsBox, "Nouveautés de vos artistes", cards) { app.push(CardsGridScreen(app, "Nouveautés de vos artistes", cards)) }
            }
        }
    }

    private fun artistRow(a: Deezer.Artist): View {
        val row = LinearLayout(app)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(app.dp(16), app.dp(8), app.dp(10), app.dp(8))
        row.addView(app.thumb(a.picture, 48))
        row.addView(app.tv(a.name, 16f, p.fg, bold = true).apply { setPadding(app.dp(14), 0, 0, 0) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val btn = app.tv(if (Follows.isFollowed(app, a.id)) "SUIVI ✓" else "SUIVRE", 11f, p.fg, bold = true, mono = true)
        btn.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))
        btn.background = GradientDrawable().apply { setColor(p.bg); setStroke(app.dp(1), p.fg) }
        btn.setOnClickListener { Follows.toggle(app, a); refresh() }
        row.addView(btn)
        return row
    }

    private fun drawFollowed() {
        followBox.removeAllViews()
        val f = Follows.list(app)
        followBox.addView(app.tv("ARTISTES SUIVIS (${f.size})", 12f, p.mute, bold = true, mono = true, spacing = 0.15f).apply { setPadding(app.dp(16), app.dp(26), app.dp(16), app.dp(6)) })
        f.forEach { followBox.addView(artistRow(it)); followBox.addView(app.hairline(p)) }
        followBox.addView(app.flatButton("Ajouter des artistes guinéens suggérés", p) { addGuineaSeeds() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(16), app.dp(16), 0) })
        followBox.addView(app.tv("Suggestions de départ, à vérifier : retirez ceux qui ne conviennent pas et ajoutez les vôtres avec la recherche.", 11f, p.mute).apply { setPadding(app.dp(16), app.dp(6), app.dp(16), 0) })
    }

    private fun addGuineaSeeds() {
        Toast.makeText(app, "Recherche des artistes…", Toast.LENGTH_SHORT).show()
        app.bg.execute {
            var added = 0
            for (n in guineaSeeds) {
                val a = try { Deezer.findArtist(n) } catch (e: IOException) { null } ?: continue
                if (!Follows.isFollowed(app, a.id)) { Follows.toggle(app, a); added++ }
            }
            app.runOnUiThread { Toast.makeText(app, "$added artiste(s) ajouté(s).", Toast.LENGTH_LONG).show(); refresh() }
        }
    }

    private fun search(q: String) {
        val query = q.trim()
        resultsBox.removeAllViews()
        if (query.length < 2) { seq++; return }
        val my = ++seq
        resultsBox.addView(app.centered("Recherche…"))
        app.bg.execute {
            val r = try { Result.success(Deezer.searchArtists(query)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != seq) return@runOnUiThread
                resultsBox.removeAllViews()
                val list = r.getOrNull()
                if (list == null) { resultsBox.addView(app.centered("Recherche impossible (${r.exceptionOrNull()?.message ?: "réseau"}).")); return@runOnUiThread }
                list.forEach { resultsBox.addView(artistRow(it)); resultsBox.addView(app.hairline(p)) }
            }
        }
    }
}
