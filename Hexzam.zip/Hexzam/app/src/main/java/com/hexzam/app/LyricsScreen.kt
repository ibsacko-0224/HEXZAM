package com.hexzam.app

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.io.IOException

/** Paroles affichées dans l'application (service AudD, disponibles pour certains titres seulement). */
class LyricsScreen(app: MainActivity, private val title: String, private val artist: String) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val box = LinearLayout(app)

    companion object { private val cache = HashMap<String, String>() }   // mémoire de session uniquement

    init {
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(app.dp(24), app.dp(12), app.dp(24), app.dp(40))
        view = app.frame("Paroles", app.scroll(box))
        load()
    }

    private fun head() {
        box.removeAllViews()
        box.addView(app.tv(title, 24f, p.fg, bold = true))
        box.addSpaced(app.tv(artist, 16f, p.mute), 2)
    }

    private fun message(text: String, retry: Boolean) {
        head()
        box.addSpaced(app.tv(text, 15f, p.mute), 18)
        if (retry) box.addSpaced(app.flatButton("Réessayer", p, true) { load() }, 14)
        box.addSpaced(app.flatButton("Chercher sur Genius", p) { Links.open(app, Links.lyrics(title, artist)) }, 8)
    }

    private fun load() {
        val key = "$artist|$title".lowercase()
        cache[key]?.let { show(it); return }
        val token = Prefs.token(app)
        if (token.isBlank()) {
            head()
            box.addSpaced(app.tv("Les paroles utilisent le service AudD : ajoutez votre clé API dans les paramètres.", 15f, p.mute), 18)
            box.addSpaced(app.flatButton("Ouvrir les paramètres", p, true) { app.pop(); app.openSettings() }, 14)
            return
        }
        head()
        box.addSpaced(app.tv("Chargement des paroles…", 15f, p.mute), 18)
        app.bg.execute {
            val r = try { Result.success(Online.findLyrics(token, artist, title)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                val lyrics = r.getOrNull()
                when {
                    r.isFailure -> message("Impossible de charger les paroles (${r.exceptionOrNull()?.message ?: "réseau"}).", true)
                    lyrics == null -> message("Paroles indisponibles pour ce titre : le service n’en propose que pour certaines musiques.", false)
                    else -> { cache[key] = lyrics; show(lyrics) }
                }
            }
        }
    }

    private fun show(lyrics: String) {
        head()
        val t: TextView = app.tv(lyrics, 17f, p.fg)
        t.setLineSpacing(0f, 1.25f)
        t.setTextIsSelectable(true)
        box.addSpaced(t, 20)
        box.addSpaced(app.tv("Paroles fournies par le service AudD. Pour un usage personnel.", 11f, p.mute, mono = true), 24)
    }
}
