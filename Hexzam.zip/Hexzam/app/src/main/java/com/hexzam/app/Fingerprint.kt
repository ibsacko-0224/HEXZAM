package com.hexzam.app

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Empreinte acoustique de type « constellation » : spectrogramme → pics → paires de pics hachées.
 * Entrée : audio 8 kHz mono. Sortie : tableau aplati [hash, temps, hash, temps, …] (temps en trames de 64 ms).
 */
object Fingerprint {
    const val WIN = 1024
    const val HOP = 512
    const val FRAME_MS = 64L
    private const val LOG2 = 10
    private const val PEAKS_PER_FRAME = 3
    private const val FANOUT = 3
    private const val MAX_DT = 63
    private const val FLOOR_SQ = 4f
    private val BANDS = intArrayOf(1, 8, 16, 32, 64, 128, 256, 512)
    private const val NB = 7

    private val hann = FloatArray(WIN) { (0.5 - 0.5 * cos(2 * PI * it / (WIN - 1))).toFloat() }
    private val cosT = FloatArray(WIN / 2) { cos(2 * PI * it / WIN).toFloat() }
    private val sinT = FloatArray(WIN / 2) { (-sin(2 * PI * it / WIN)).toFloat() }
    private val rev = IntArray(WIN) { Integer.reverse(it) ushr (32 - LOG2) }

    private fun fft(re: FloatArray, im: FloatArray) {
        for (i in 0 until WIN) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= WIN) {
            val half = size / 2
            val step = WIN / size
            var i = 0
            while (i < WIN) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = sinT[k]
                    val tr = re[j + half] * wr - im[j + half] * wi
                    val ti = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - tr; im[j + half] = im[j] - ti
                    re[j] += tr; im[j] += ti
                    k += step
                }
                i += size
            }
            size *= 2
        }
    }

    fun hashes(x: FloatArray, n: Int): IntArray {
        val frames = if (n < WIN) 0 else (n - WIN) / HOP + 1
        val pt = IntList()
        val pf = IntList()
        val re = FloatArray(WIN)
        val im = FloatArray(WIN)
        val bm = FloatArray(NB)
        val bf = IntArray(NB)
        for (fr in 0 until frames) {
            val off = fr * HOP
            for (i in 0 until WIN) { re[i] = x[off + i] * hann[i]; im[i] = 0f }
            fft(re, im)
            var mx = 0f
            for (b in 0 until NB) {
                var m = 0f
                var f = BANDS[b]
                for (k in BANDS[b] until BANDS[b + 1]) {
                    val e = re[k] * re[k] + im[k] * im[k]
                    if (e > m) { m = e; f = k }
                }
                bm[b] = m; bf[b] = f
                if (m > mx) mx = m
            }
            if (mx < FLOOR_SQ) continue           // silence
            val chosen = (0 until NB).sortedByDescending { bm[it] }
                .take(PEAKS_PER_FRAME).filter { bm[it] >= mx * 0.01f }
                .map { bf[it] }.sorted()
            for (f in chosen) { pt.add(fr); pf.add(f) }
        }
        val out = IntList()
        for (i in 0 until pt.size) {
            var c = 0
            var j = i + 1
            while (j < pt.size && c < FANOUT) {
                val dt = pt[j] - pt[i]
                if (dt > MAX_DT) break
                if (dt >= 1) {
                    out.add((pf[i] shl 15) or (pf[j] shl 6) or dt)
                    out.add(pt[i])
                    c++
                }
                j++
            }
        }
        return out.toArray()
    }
}
