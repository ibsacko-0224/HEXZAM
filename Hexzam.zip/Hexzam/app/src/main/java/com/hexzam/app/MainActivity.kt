package com.hexzam.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    lateinit var db: HexDb
    lateinit var palette: Palette
    val worker: ExecutorService = Executors.newSingleThreadExecutor()   // reconnaissance
    val bg: ExecutorService = Executors.newSingleThreadExecutor()       // indexation, réseau, images

    private val stack = ArrayList<Screen>()
    private lateinit var pager: Pager
    private lateinit var dots: LinearLayout
    private lateinit var overlay: FrameLayout
    private lateinit var home: HomePage
    private lateinit var library: LibraryPage

    companion object {
        const val REQ_MIC = 1
        const val REQ_FOLDER = 2
        const val REQ_EXPORT = 3
        const val REQ_MIC_AUTO = 4
        const val REQ_NOTIF = 5
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        palette = Theme.palette(this)
        db = HexDb(this)
        home = HomePage(this)
        library = LibraryPage(this)
        val tops = TopsPage(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(palette.bg)
        dots = LinearLayout(this)
        pager = Pager(this, listOf(library.view, home.view, tops.view), 1) { updateDots(it) }
        root.addView(pager, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(dots, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(16) })
        overlay = FrameLayout(this)
        overlay.setBackgroundColor(palette.bg)
        overlay.isClickable = true
        overlay.visibility = View.GONE
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        styleBars()
        updateDots(1)
        Notifier.ensureChannels(this)

        val i = intent
        if (i?.getBooleanExtra("reopen_settings", false) == true) { i.removeExtra("reopen_settings"); openSettings() }
        else if (i?.getBooleanExtra("autostart", false) == true) handleIntent(i)
        else if (savedInstanceState == null && Prefs.listenOnStart(this)) startListening()
    }

    private fun updateDots(index: Int) {
        dots.removeAllViews()
        for (k in 0 until 3) {
            val d = View(this)
            d.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (k == index) palette.fg else palette.line) }
            dots.addView(d, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(5), 0, dp(5), 0) })
        }
        if (index == 0) library.refresh()
        if (index == 1) home.refresh()
    }

    @Suppress("DEPRECATION")
    private fun styleBars() {
        window.statusBarColor = palette.bg
        window.navigationBarColor = palette.bg
        if (Build.VERSION.SDK_INT >= 30) {
            val flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (palette.dark) 0 else flags, flags)
        } else {
            var f = 0
            if (!palette.dark) {
                f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = f
        }
    }

    // ───── Navigation par pile d'écrans
    fun push(s: Screen) {
        stack.add(s)
        overlay.removeAllViews()
        overlay.addView(s.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay.visibility = View.VISIBLE
        s.onShow()
    }

    fun pop() {
        if (stack.isEmpty()) return
        stack.removeAt(stack.size - 1).onClose()
        val top = stack.lastOrNull()
        overlay.removeAllViews()
        if (top == null) {
            overlay.visibility = View.GONE
            library.refresh()
            home.refresh()
        } else {
            overlay.addView(top.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            top.onShow()
        }
    }

    fun replaceTop(s: Screen) { pop(); push(s) }

    @Suppress("DEPRECATION")
    @Deprecated("API simple suffisante ici")
    override fun onBackPressed() {
        when {
            stack.isNotEmpty() -> pop()
            pager.index != 1 -> pager.go(1)
            else -> super.onBackPressed()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Lancé depuis la notification, la tuile, le widget ou le pop-up : retour à l'accueil et écoute immédiate. */
    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("autostart", false) != true) return
        i.removeExtra("autostart")
        while (stack.isNotEmpty()) pop()
        pager.go(1)
        startListening()
    }

    override fun onResume() {
        super.onResume()
        Notifier.syncQuick(this)
        home.refresh()
        if (Prefs.online(this) && Prefs.token(this).isNotBlank() && Pending.count(this) > 0 && Pending.networkAvailable(this)) retryPending(silent = true)
    }

    override fun onPause() {
        Preview.stop()
        super.onPause()
    }

    // ───── Actions
    fun startListening() {
        if (stack.lastOrNull() is ListeningScreen) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        push(ListeningScreen(this))
    }

    fun openSettings() = push(SettingsScreen(this))

    fun recreateKeepingSettings() {
        intent.putExtra("reopen_settings", true)
        recreate()
    }

    fun retryPending(silent: Boolean = false) {
        if (!Pending.networkAvailable(this)) {
            if (!silent) Toast.makeText(this, "Toujours pas de connexion.", Toast.LENGTH_SHORT).show()
            return
        }
        bg.execute {
            val (found, left) = Pending.retryAll(this, db)
            runOnUiThread {
                if (!silent || found > 0) Toast.makeText(this, "$found reconnu(s), $left en attente.", Toast.LENGTH_LONG).show()
                home.refresh()
                library.refresh()
            }
        }
    }

    fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.canPost(this)) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), REQ_NOTIF)
    }

    fun openNotificationSettings() {
        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    fun startAuto() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQ_MIC_AUTO)
            return
        }
        askNotifPermission()
        startForegroundService(Intent(this, AutoListenService::class.java))
    }

    fun stopAuto() { stopService(Intent(this, AutoListenService::class.java)) }

    fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorisez l’affichage par-dessus les autres applications, puis réactivez le pop-up.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        askNotifPermission()
        startForegroundService(Intent(this, BubbleService::class.java))
    }

    fun stopBubble() { stopService(Intent(this, BubbleService::class.java)) }

    // ───── Boîtes de dialogue
    fun choose(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), selected) { d, i -> d.dismiss(); onPick(i) }
            .setNegativeButton("Annuler", null).show()
    }

    fun chooseMusicApp(onDone: () -> Unit) {
        choose("Application de musique", Links.apps.map { it.second }, Links.apps.indexOfFirst { it.first == Prefs.musicApp(this) }.coerceAtLeast(0)) { i ->
            Prefs.setMusicApp(this, Links.apps[i].first); onDone()
        }
    }

    fun pickCountry(onPick: (String) -> Unit) {
        AlertDialog.Builder(this).setTitle("Pays").setItems(Charts.countries.map { it.second }.toTypedArray()) { _, i -> onPick(Charts.countries[i].first) }.show()
    }

    fun promptKey(onDone: () -> Unit) {
        val input = EditText(this)
        input.hint = "Collez votre clé API AudD"
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        input.setText(Prefs.token(this))
        AlertDialog.Builder(this).setTitle("Clé API AudD").setView(input)
            .setPositiveButton("Enregistrer") { _, _ -> Prefs.setToken(this, input.text.toString()); if (input.text.isNotBlank()) Prefs.setOnline(this, true); onDone() }
            .setNeutralButton("Obtenir une clé") { _, _ -> Links.open(this, "https://audd.io") }
            .setNegativeButton("Annuler", null).show()
    }

    // ───── Sélecteurs système
    fun pickMusicFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, REQ_FOLDER)
    }

    fun exportHistory() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/csv"
        i.putExtra(Intent.EXTRA_TITLE, "hexzam-historique.csv")
        startActivityForResult(i, REQ_EXPORT)
    }

    @Deprecated("API simple suffisante ici")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        when (requestCode) {
            REQ_FOLDER -> {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: SecurityException) { }
                (stack.lastOrNull() as? LocalLibraryScreen)?.onFolder(uri)
            }
            REQ_EXPORT -> writeCsv(uri)
        }
    }

    private fun writeCsv(uri: Uri) {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("titre,artiste,album,genre,favori,source,date\n")
        for (h in db.history()) sb.append(q(h.title)).append(',').append(q(h.artist)).append(',').append(q(h.album)).append(',')
            .append(q(h.genre ?: "")).append(',').append(if (h.fav) "oui" else "non").append(',').append(q(h.source)).append(',').append(q(fmt.format(Date(h.ts)))).append('\n')
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Historique exporté.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export impossible : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_MIC -> if (ok) startListening() else Toast.makeText(this, "Micro refusé : autorisez-le dans les réglages Android.", Toast.LENGTH_LONG).show()
            REQ_MIC_AUTO -> if (ok) startAuto() else Toast.makeText(this, "Micro refusé : écoute continue impossible.", Toast.LENGTH_LONG).show()
            REQ_NOTIF -> Notifier.syncQuick(this)
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        bg.shutdownNow()
        super.onDestroy()
    }
}
