package com.hexzam.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    lateinit var db: HexDb
    lateinit var palette: Palette
    val worker: ExecutorService = Executors.newSingleThreadExecutor()   // reconnaissance
    val bg: ExecutorService = Executors.newSingleThreadExecutor()       // indexation de la bibliothèque

    private lateinit var listen: ListenScreen
    private lateinit var history: HistoryScreen
    private lateinit var library: LibraryScreen
    private lateinit var settings: SettingsScreen
    private lateinit var content: FrameLayout
    private lateinit var tabs: List<TextView>
    private var current = 0

    companion object {
        const val REQ_MIC = 1
        const val REQ_FOLDER = 2
        const val REQ_EXPORT = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        palette = Theme.palette(this)
        db = HexDb(this)
        listen = ListenScreen(this, palette)
        history = HistoryScreen(this, palette)
        library = LibraryScreen(this, palette)
        settings = SettingsScreen(this, palette)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(palette.bg)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(hairline(palette))

        val nav = LinearLayout(this)
        val names = listOf("ÉCOUTER", "HISTORIQUE", "BIBLIO", "RÉGLAGES")
        tabs = names.mapIndexed { i, n ->
            val t = tv(n, 11f, palette.mute, bold = true, mono = true, spacing = 0.05f)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { show(i) }
            nav.addView(t, LinearLayout.LayoutParams(0, dp(54), 1f))
            t
        }
        root.addView(nav)
        setContentView(root)
        styleBars()
        show(savedInstanceState?.getInt("tab") ?: 0)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    @Suppress("DEPRECATION")
    private fun styleBars() {
        window.statusBarColor = palette.bg
        window.navigationBarColor = palette.bg
        if (Build.VERSION.SDK_INT >= 30) {
            val flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (palette.dark) 0 else flags, flags)
        } else {
            var f = 0
            if (!palette.dark) {
                f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = f
        }
    }

    private fun show(i: Int) {
        current = i
        val v = when (i) {
            0 -> listen.view
            1 -> { history.refresh(); history.view }
            2 -> { library.refresh(); library.view }
            else -> settings.view
        }
        content.removeAllViews()
        content.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tabs.forEachIndexed { k, t ->
            t.setTextColor(if (k == i) palette.fg else palette.mute)
            t.paintFlags = if (k == i) t.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            else t.paintFlags and android.graphics.Paint.UNDERLINE_TEXT_FLAG.inv()
        }
    }

    // ───── Sélecteurs système
    fun pickMusicFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, REQ_FOLDER)
    }

    fun exportHistory() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/csv"
        i.putExtra(Intent.EXTRA_TITLE, "hexzam-historique.csv")
        startActivityForResult(i, REQ_EXPORT)
    }

    @Deprecated("API simple suffisante ici")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        when (requestCode) {
            REQ_FOLDER -> {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: SecurityException) { }
                show(2)
                library.onFolder(uri)
            }
            REQ_EXPORT -> writeCsv(uri)
        }
    }

    private fun writeCsv(uri: Uri) {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("titre,artiste,album,source,date\n")
        for (h in db.history()) sb.append(q(h.title)).append(',').append(q(h.artist)).append(',').append(q(h.album))
            .append(',').append(q(h.source)).append(',').append(q(fmt.format(Date(h.ts)))).append('\n')
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Historique exporté.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export impossible : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) listen.onPermission(grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        bg.shutdownNow()
        super.onDestroy()
    }
}
