package com.hexzam.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Extraits enregistrés sans réseau : conservés localement, reconnus plus tard dès que la connexion revient. */
object Pending {
    private const val MAX = 20

    private fun dir(c: Context) = File(c.filesDir, "pending").apply { mkdirs() }
    private fun files(c: Context): List<File> = dir(c).listFiles()?.filter { it.extension == "wav" }?.sortedBy { it.name } ?: emptyList()

    fun count(c: Context) = files(c).size

    fun save(c: Context, wav: ByteArray) {
        val all = files(c)
        if (all.size >= MAX) all.first().delete()
        File(dir(c), "${System.currentTimeMillis()}.wav").writeBytes(wav)
    }

    fun clear(c: Context) { files(c).forEach { it.delete() } }

    fun isNetworkError(e: IOException) =
        e is UnknownHostException || e is ConnectException || e is SocketTimeoutException || e is SocketException

    fun networkAvailable(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun onWifi(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /** Retente chaque extrait en attente. Retourne (reconnus, restants). S'arrête à la première erreur. */
    fun retryAll(c: Context, db: HexDb): Pair<Int, Int> {
        val token = Prefs.token(c)
        if (token.isBlank()) return Pair(0, count(c))
        var found = 0
        for (f in files(c)) {
            try {
                val r = Online.recognize(token, f.readBytes())
                if (r != null) {
                    db.addHistory(r.title, r.artist, r.album, "EN LIGNE", r.link, r.cover, r.preview, r.genre)
                    Notifier.showResult(c, r.title, r.artist)
                    found++
                }
                f.delete()
            } catch (e: IOException) {
                break
            }
        }
        return Pair(found, count(c))
    }
}
