package com.hexzam.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Locale

/** Carte façon Spotify : pochette carrée, titre, « Type · date ». */
data class Card(val cover: String?, val title: String, val artist: String, val meta: String, val onClick: () -> Unit)

fun prettyDate(d: String?): String {
    if (d.isNullOrBlank()) return ""
    return try {
        when (d.length) {
            10 -> SimpleDateFormat("d MMM yyyy", Locale.FRENCH).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(d)!!)
            7 -> SimpleDateFormat("MMM yyyy", Locale.FRENCH).format(SimpleDateFormat("yyyy-MM", Locale.US).parse(d)!!)
            else -> d
        }
    } catch (e: Exception) { d }
}

fun MainActivity.cardView(c: Card, widthPx: Int): View {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(thumb(c.cover, 10).apply { layoutParams = LinearLayout.LayoutParams(widthPx, widthPx) })
    col.addView(tv(c.title, 15f, palette.fg, bold = true).apply { maxLines = 2; setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(widthPx, ViewGroup.LayoutParams.WRAP_CONTENT))
    col.addView(tv(c.artist, 13f, palette.mute).apply { maxLines = 1 }, LinearLayout.LayoutParams(widthPx, ViewGroup.LayoutParams.WRAP_CONTENT))
    if (c.meta.isNotEmpty()) col.addView(tv(c.meta, 11f, palette.mute, mono = true).apply { maxLines = 1; setPadding(0, dp(2), 0, 0) }, LinearLayout.LayoutParams(widthPx, ViewGroup.LayoutParams.WRAP_CONTENT))
    col.setOnClickListener { c.onClick() }
    return col
}

/** Section façon Spotify : titre + « VOIR TOUT » + défilement horizontal de cartes. */
fun MainActivity.carousel(box: LinearLayout, title: String, cards: List<Card>, seeAll: (() -> Unit)?) {
    val head = LinearLayout(this)
    head.gravity = Gravity.CENTER_VERTICAL
    head.setPadding(dp(16), dp(22), dp(16), dp(10))
    head.addView(tv(title, 20f, palette.fg, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    if (seeAll != null) head.addView(tv("VOIR TOUT ›", 11f, palette.fg, bold = true, mono = true).apply { setOnClickListener { seeAll() } })
    box.addView(head)
    val hs = HorizontalScrollView(this)
    hs.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(this)
    row.setPadding(dp(16), 0, dp(8), 0)
    val w = dp(150)
    for (c in cards.take(15)) row.addView(cardView(c, w), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(12) })
    hs.addView(row)
    box.addView(hs)
}

/** Toutes les nouveautés en grille de deux colonnes, la plus récente en premier. */
class CardsGridScreen(app: MainActivity, title: String, private val cards: List<Card>) : Screen(app) {
    override val view: View

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(app.dp(16), app.dp(8), app.dp(16), app.dp(32))
        col.addView(app.tv("${cards.size} titre(s), du plus récent au plus ancien", 12f, app.palette.mute, mono = true).apply { setPadding(0, 0, 0, app.dp(10)) })
        val w = (app.resources.displayMetrics.widthPixels - app.dp(32) - app.dp(12)) / 2
        for (pair in cards.chunked(2)) {
            val row = LinearLayout(app)
            pair.forEachIndexed { i, c -> row.addView(app.cardView(c, w), LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply { if (i > 0) leftMargin = app.dp(12) }) }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = app.dp(18) })
        }
        view = app.frame(title, app.scroll(col))
    }
}

fun Deezer.Track.toCard(app: MainActivity, all: List<Deezer.Track>, i: Int) =
    Card(cover, title, artist, "TITRE", { app.push(TrackScreen(app, toInfo())) })
