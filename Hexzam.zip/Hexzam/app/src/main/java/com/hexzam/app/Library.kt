package com.hexzam.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract

/** Indexation d'un dossier de musique choisi par l'utilisateur (sélecteur système, lecture seule). */
object Library {
    private val EXT = setOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav")
    private const val MAX_FILES = 2000
    private const val MAX_SECONDS = 360

    data class Entry(val uri: Uri, val name: String)

    private fun list(context: Context, tree: Uri): List<Entry> {
        val out = ArrayList<Entry>()
        val queue = ArrayDeque<String>()
        queue.add(DocumentsContract.getTreeDocumentId(tree))
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        while (queue.isNotEmpty() && out.size < MAX_FILES) {
            val id = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            context.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0)
                    val name = c.getString(1) ?: ""
                    if (name.startsWith(".")) continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) queue.add(docId)
                    else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in EXT)
                        out.add(Entry(DocumentsContract.buildDocumentUriUsingTree(tree, docId), name))
                }
            }
        }
        return out
    }

    private fun clean(s: String?) = s?.trim()?.takeIf { it.isNotEmpty() }

    data class Result(val added: Int, val skipped: Int, val failed: Int)

    fun index(context: Context, tree: Uri, db: HexDb, progress: (String) -> Unit, cancelled: () -> Boolean): Result {
        val files = list(context, tree)
        var added = 0; var skipped = 0; var failed = 0
        for ((i, e) in files.withIndex()) {
            if (cancelled()) break
            if (db.hasTrack(e.uri.toString())) { skipped++; continue }
            val base = e.name.substringBeforeLast('.')
            progress("Analyse ${i + 1}/${files.size} : $base")
            var title: String? = null; var artist: String? = null; var album: String? = null
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(context, e.uri)
                title = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE))
                artist = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST))
                album = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM))
            } catch (ex: Exception) {
            } finally { mmr.release() }

            val buf = FloatBuf()
            val ok = AudioDecoder.decode(context, e.uri, MAX_SECONDS) { buf.add(it) }
            val fp = if (ok) Fingerprint.hashes(buf.a, buf.n) else IntArray(0)
            if (fp.isEmpty()) { failed++; continue }
            try {
                db.addTrack(title ?: base, artist ?: "Artiste inconnu", album ?: "", e.uri.toString(), fp)
                added++
            } catch (ex: Exception) { failed++ }
        }
        return Result(added, skipped, failed)
    }
}
