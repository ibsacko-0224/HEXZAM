package com.hexzam.app

import android.app.AlertDialog
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Ma musique locale : morceaux dont HEXZAM connaît l'empreinte, reconnus sans réseau (facultatif). */
class LocalLibraryScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val status: TextView = app.tv("", 12f, p.mute, mono = true)
    private val list = LinearLayout(app)
    @Volatile private var indexing = false
    @Volatile private var stop = false

    init {
        val root = LinearLayout(app)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(app.dp(20), app.dp(16), app.dp(20), app.dp(24))
        root.addView(app.tv("Facultatif : ajoutez un dossier de musique et HEXZAM reconnaîtra ces morceaux sans réseau (empreintes calculées sur l’appareil, fichiers jamais copiés ni modifiés). Pour reconnaître toute autre musique, utilisez la reconnaissance en ligne.", 14f, p.mute))
        root.addSpaced(app.flatButton("Ajouter un dossier de musique", p, true) { if (!indexing) app.pickMusicFolder() }, 14)
        root.addSpaced(app.flatButton("Arrêter l’analyse", p) { stop = true }, 8)
        root.addSpaced(status, 10)
        list.orientation = LinearLayout.VERTICAL
        root.addSpaced(list, 10)
        root.addSpaced(app.flatButton("Tout supprimer", p) {
            AlertDialog.Builder(app).setMessage("Supprimer toutes les empreintes ? (vos fichiers musicaux ne sont pas touchés)")
                .setPositiveButton("Supprimer") { _, _ -> app.db.clearLibrary(); refresh() }
                .setNegativeButton("Annuler", null).show()
        }, 16)
        view = app.frame("Ma musique locale", app.scroll(root))
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val tracks = app.db.tracks()
        if (!indexing) status.text = if (tracks.isEmpty()) "AUCUN MORCEAU INDEXÉ" else "${tracks.size} MORCEAU(X) INDEXÉ(S)"
        for (t in tracks) {
            val row = LinearLayout(app)
            row.setPadding(0, app.dp(10), 0, app.dp(10))
            val col = LinearLayout(app)
            col.orientation = LinearLayout.VERTICAL
            col.addView(app.tv(t.title, 15f, p.fg, bold = true))
            col.addView(app.tv(t.artist, 12f, p.mute))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(app.flatButton("Retirer", p) { app.db.deleteTrack(t.id); refresh() })
            list.addView(row)
            list.addView(app.hairline(p))
        }
    }

    fun onFolder(tree: Uri) {
        if (indexing) return
        indexing = true
        stop = false
        status.text = "PRÉPARATION…"
        app.bg.execute {
            val r = try {
                Library.index(app, tree, app.db, { m -> app.runOnUiThread { status.text = m.uppercase() } }, { stop })
            } catch (e: Exception) { null }
            app.runOnUiThread {
                indexing = false
                refresh()
                status.text = if (r == null) "ÉCHEC DE L’ANALYSE" else "${r.added} AJOUTÉ(S) · ${r.skipped} DÉJÀ PRÉSENT(S) · ${r.failed} ILLISIBLE(S)"
            }
        }
    }
}
