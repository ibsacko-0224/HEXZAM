package com.hexzam.app

import android.content.pm.PackageManager
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ListenScreen(private val a: MainActivity, private val p: Palette) {
    val view: View
    private val hex = HexButton(a, p.fg, p.bg)
    private val status: TextView = a.tv("TOUCHEZ LE BOUTON POUR ÉCOUTER", 12f, p.mute, mono = true, spacing = 0.1f)
    private val resultBox = LinearLayout(a)
    private var running = false
    @Volatile private var cancel = false

    init {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(a.dp(24), a.dp(28), a.dp(24), a.dp(24))

        root.addView(a.tv("HEXZAM", 22f, p.fg, bold = true, mono = true, spacing = 0.35f))
        root.addView(hex, LinearLayout.LayoutParams(a.dp(280), a.dp(280)).apply { topMargin = a.dp(18) })
        hex.contentDescription = "Écouter"
        hex.setOnClickListener { toggle() }
        status.gravity = Gravity.CENTER
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(6) })

        resultBox.orientation = LinearLayout.VERTICAL
        resultBox.visibility = View.GONE
        root.addView(resultBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(22) })

        val scroll = ScrollView(a)
        scroll.isFillViewport = true
        scroll.addView(root)
        view = scroll
    }

    fun refresh() {}

    private fun toggle() {
        if (running) { cancel = true; return }
        if (a.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), MainActivity.REQ_MIC)
            return
        }
        start()
    }

    fun onPermission(granted: Boolean) {
        if (granted) start() else status.text = "MICRO REFUSÉ : AUTORISEZ-LE DANS LES RÉGLAGES ANDROID"
    }

    private fun start() {
        running = true
        cancel = false
        resultBox.visibility = View.GONE
        resultBox.removeAllViews()
        val secs = Prefs.listenSeconds(a)
        hex.state = HexButton.State.LISTENING
        status.text = "ÉCOUTE… ($secs S) · TOUCHEZ POUR ANNULER"
        a.worker.execute {
            val outcome = try {
                Recognizer(a, a.db).run(secs,
                    { l -> a.runOnUiThread { hex.setLevel(l) } },
                    { ph -> a.runOnUiThread { phase(ph) } },
                    { cancel })
            } catch (e: Exception) {
                Outcome.Failed("Erreur inattendue : ${e.message ?: "inconnue"}")
            }
            a.runOnUiThread { finish(outcome) }
        }
    }

    private fun phase(ph: String) {
        when (ph) {
            "analyzing" -> { hex.state = HexButton.State.ANALYZING; status.text = "ANALYSE…" }
            "online" -> { hex.state = HexButton.State.ANALYZING; status.text = "RECHERCHE EN LIGNE…" }
        }
    }

    private fun finish(o: Outcome) {
        running = false
        hex.state = HexButton.State.IDLE
        hex.setLevel(0f)
        status.text = "TOUCHEZ LE BOUTON POUR ÉCOUTER"
        when (o) {
            is Outcome.Found -> {
                a.db.addHistory(o.title, o.artist, o.album, o.source, o.link)
                if (Prefs.haptics(a)) hex.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showFound(o)
            }
            Outcome.NotFound -> showMessage(
                "AUCUN RÉSULTAT",
                "Rapprochez le téléphone de la source et réessayez. Pour reconnaître ce morceau, ajoutez-le à votre bibliothèque, ou activez la reconnaissance en ligne dans les réglages."
            )
            Outcome.Cancelled -> {}
            is Outcome.Failed -> showMessage("ERREUR", o.message)
        }
    }

    private fun showMessage(title: String, text: String) {
        resultBox.removeAllViews()
        resultBox.addView(a.tv(title, 12f, p.fg, bold = true, mono = true, spacing = 0.12f))
        resultBox.addSpaced(a.tv(text, 15f, p.mute), 6)
        resultBox.visibility = View.VISIBLE
    }

    private fun showFound(o: Outcome.Found) {
        resultBox.removeAllViews()
        resultBox.addView(a.hairline(p))
        resultBox.addSpaced(a.tv(o.source, 11f, p.mute, bold = true, mono = true, spacing = 0.15f), 14)
        resultBox.addSpaced(a.tv(o.title, 26f, p.fg, bold = true), 4)
        resultBox.addSpaced(a.tv(o.artist, 17f, p.fg), 2)
        if (o.album.isNotEmpty()) resultBox.addSpaced(a.tv(o.album, 14f, p.mute), 2)
        resultBox.addSpaced(actionRows(o.title, o.artist, o.link), 18)
        resultBox.visibility = View.VISIBLE
    }

    private fun actionRows(t: String, ar: String, link: String?): View {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        fun row(vararg b: View): LinearLayout {
            val r = LinearLayout(a)
            b.forEachIndexed { i, v -> r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) leftMargin = a.dp(8) }) }
            return r
        }
        box.addView(row(
            a.flatButton("Spotify", p, true) { Links.open(a, Links.spotify(t, ar)) },
            a.flatButton("YouTube", p) { Links.open(a, Links.youtube(t, ar)) }))
        box.addSpaced(row(
            a.flatButton("Apple Music", p) { Links.open(a, Links.apple(t, ar)) },
            a.flatButton("Deezer", p) { Links.open(a, Links.deezer(t, ar)) }), 8)
        box.addSpaced(row(
            a.flatButton("Partager", p) { Links.share(a, "J’ai reconnu « $t » de $ar avec HEXZAM" + (link?.let { "\n$it" } ?: "")) }), 8)
        return box
    }
}
