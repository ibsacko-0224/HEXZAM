package com.hexzam.app

import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.DateFormat
import java.util.Date

class HistoryScreen(private val a: MainActivity, private val p: Palette) {
    val view: View
    private val list = LinearLayout(a)

    init {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(a.dp(20), a.dp(24), a.dp(20), a.dp(20))
        root.addView(a.tv("HISTORIQUE", 18f, p.fg, bold = true, mono = true, spacing = 0.25f))
        val actions = LinearLayout(a)
        actions.addView(a.flatButton("Exporter CSV", p) { a.exportHistory() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(a.flatButton("Vider", p) {
            AlertDialog.Builder(a).setMessage("Effacer tout l’historique ?")
                .setPositiveButton("Effacer") { _, _ -> a.db.clearHistory(); refresh() }
                .setNegativeButton("Annuler", null).show()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = a.dp(8) })
        root.addSpaced(actions, 14)
        list.orientation = LinearLayout.VERTICAL
        root.addSpaced(list, 14)
        val s = ScrollView(a)
        s.addView(root)
        view = s
    }

    fun refresh() {
        list.removeAllViews()
        val items = a.db.history()
        if (items.isEmpty()) {
            val t = a.tv("Aucun titre reconnu pour l’instant.\nLancez une écoute depuis l’onglet ÉCOUTER.", 15f, p.mute)
            t.gravity = Gravity.CENTER
            t.setPadding(0, a.dp(48), 0, 0)
            list.addView(t)
            return
        }
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        for (h in items) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, a.dp(14), 0, a.dp(14))
            row.addView(a.tv(h.title, 17f, p.fg, bold = true))
            row.addView(a.tv(h.artist, 14f, p.fg))
            row.addView(a.tv("${fmt.format(Date(h.ts))} · ${h.source}", 11f, p.mute, mono = true))
            row.setOnClickListener { actions(h) }
            list.addView(row)
            list.addView(a.hairline(p))
        }
    }

    private fun actions(h: HistoryItem) {
        val names = arrayOf("Spotify", "YouTube", "Apple Music", "Deezer", "Partager", "Supprimer")
        AlertDialog.Builder(a).setTitle(h.title).setItems(names) { _, i ->
            when (i) {
                0 -> Links.open(a, Links.spotify(h.title, h.artist))
                1 -> Links.open(a, Links.youtube(h.title, h.artist))
                2 -> Links.open(a, Links.apple(h.title, h.artist))
                3 -> Links.open(a, Links.deezer(h.title, h.artist))
                4 -> Links.share(a, "« ${h.title} » de ${h.artist} (reconnu avec HEXZAM)" + (h.link?.let { "\n$it" } ?: ""))
                5 -> { a.db.deleteHistory(h.id); refresh() }
            }
        }.show()
    }
}
