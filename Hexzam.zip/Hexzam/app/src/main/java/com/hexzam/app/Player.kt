package com.hexzam.app

import android.media.AudioAttributes
import android.media.MediaPlayer

/** Lecteur d'extraits de 30 s avec file d'attente : enchaîne automatiquement les titres d'une liste. */
object Player {
    private var mp: MediaPlayer? = null
    var queue: List<Deezer.Track> = emptyList()
        private set
    var index = -1
        private set
    var playing = false
        private set
    var onChange: (() -> Unit)? = null
    var autoNext = true

    val current: Deezer.Track? get() = if (mp != null) queue.getOrNull(index) else null

    fun play(list: List<Deezer.Track>, i: Int) {
        queue = list
        start(i)
    }

    /** Écoute d'un seul extrait (par exemple depuis l'écran d'un titre reconnu). */
    fun playOne(t: Deezer.Track) = play(listOf(t), 0)

    private fun start(i: Int) {
        release()
        var k = i
        while (k in queue.indices && queue[k].preview == null) k++      // saute les titres sans extrait
        val t = queue.getOrNull(k)
        if (t?.preview == null) { index = -1; playing = false; onChange?.invoke(); return }
        index = k
        val m = MediaPlayer()
        mp = m
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            m.setDataSource(t.preview)
            m.setOnPreparedListener { it.start(); playing = true; onChange?.invoke() }
            m.setOnCompletionListener { if (autoNext) next() else stop() }
            m.setOnErrorListener { _, _, _ -> stop(); true }
            m.prepareAsync()
        } catch (e: Exception) { stop() }
        onChange?.invoke()
    }

    fun next() { if (index + 1 in queue.indices) start(index + 1) else stop() }

    fun toggle() {
        val m = mp ?: return
        try { if (playing) { m.pause(); playing = false } else { m.start(); playing = true } } catch (e: Exception) { stop() }
        onChange?.invoke()
    }

    private fun release() {
        try { mp?.stop() } catch (e: Exception) { }
        mp?.release()
        mp = null
        playing = false
    }

    fun stop() {
        release()
        index = -1
        onChange?.invoke()
    }
}
