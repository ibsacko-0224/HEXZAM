package com.hexzam.app

import android.app.AlertDialog
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LibraryScreen(private val a: MainActivity, private val p: Palette) {
    val view: View
    private val status: TextView = a.tv("", 12f, p.mute, mono = true)
    private val list = LinearLayout(a)
    @Volatile private var indexing = false
    @Volatile private var stop = false

    init {
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(a.dp(20), a.dp(24), a.dp(20), a.dp(20))
        root.addView(a.tv("BIBLIOTHÈQUE", 18f, p.fg, bold = true, mono = true, spacing = 0.25f))
        root.addSpaced(a.tv("Ajoutez un dossier de musique : HEXZAM en calcule l’empreinte sonore, sur l’appareil, et reconnaîtra ces morceaux sans réseau. Vos fichiers ne sont ni copiés ni modifiés.", 14f, p.mute), 8)
        root.addSpaced(a.flatButton("Ajouter un dossier de musique", p, true) { if (!indexing) a.pickMusicFolder() }, 14)
        root.addSpaced(a.flatButton("Arrêter l’analyse", p) { stop = true }, 8)
        root.addSpaced(status, 10)
        list.orientation = LinearLayout.VERTICAL
        root.addSpaced(list, 10)
        root.addSpaced(a.flatButton("Tout supprimer", p) {
            AlertDialog.Builder(a).setMessage("Supprimer toutes les empreintes de la bibliothèque ? (vos fichiers musicaux ne sont pas touchés)")
                .setPositiveButton("Supprimer") { _, _ -> a.db.clearLibrary(); refresh() }
                .setNegativeButton("Annuler", null).show()
        }, 16)
        val s = ScrollView(a)
        s.addView(root)
        view = s
    }

    fun refresh() {
        list.removeAllViews()
        val tracks = a.db.tracks()
        if (!indexing) status.text = if (tracks.isEmpty()) "AUCUN MORCEAU INDEXÉ" else "${tracks.size} MORCEAU(X) INDEXÉ(S)"
        for (t in tracks) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, a.dp(10), 0, a.dp(10))
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            col.addView(a.tv(t.title, 15f, p.fg, bold = true))
            col.addView(a.tv(t.artist, 12f, p.mute))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(a.flatButton("Retirer", p) { a.db.deleteTrack(t.id); refresh() })
            list.addView(row)
            list.addView(a.hairline(p))
        }
    }

    fun onFolder(tree: Uri) {
        if (indexing) return
        indexing = true
        stop = false
        status.text = "PRÉPARATION…"
        a.bg.execute {
            val r = try {
                Library.index(a, tree, a.db, { m -> a.runOnUiThread { status.text = m.uppercase() } }, { stop })
            } catch (e: Exception) { null }
            a.runOnUiThread {
                indexing = false
                refresh()
                status.text = if (r == null) "ÉCHEC DE L’ANALYSE" else "${r.added} AJOUTÉ(S) · ${r.skipped} DÉJÀ PRÉSENT(S) · ${r.failed} ILLISIBLE(S)"
            }
        }
    }
}
