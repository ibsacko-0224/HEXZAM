package com.hexzam.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Écran empilé au-dessus du pager (écoute, titre, listes, réglages…). */
abstract class Screen(val app: MainActivity) {
    abstract val view: View
    open fun onClose() {}
    open fun onShow() {}
}

data class TrackInfo(
    val title: String, val artist: String, val album: String, val source: String,
    val link: String?, val cover: String?, val preview: String?, val genre: String?, val historyId: Long?
)

fun HistoryItem.toInfo() = TrackInfo(title, artist, album, source, link, cover, preview, genre, id)

fun MainActivity.icon(symbol: String, onClick: () -> Unit): TextView {
    val t = tv(symbol, 22f, palette.fg, bold = true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(10), dp(14), dp(10))
    t.setOnClickListener { onClick() }
    return t
}

fun MainActivity.scroll(content: View): ScrollView {
    val s = ScrollView(this)
    s.isFillViewport = true
    s.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    return s
}

/** Barre supérieure « ← Titre » + corps. */
fun MainActivity.frame(title: String, body: View, right: View? = null): View {
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setBackgroundColor(palette.bg)
    val bar = LinearLayout(this)
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.setPadding(dp(4), 0, dp(4), 0)
    bar.addView(icon("←") { pop() })
    bar.addView(tv(title, 18f, palette.fg, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    if (right != null) bar.addView(right)
    col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
    col.addView(hairline(palette))
    col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    return col
}

/** Ligne de menu façon Shazam : libellé, valeur à droite, filet. */
fun MainActivity.menuRow(label: String, value: String? = null, sub: String? = null, onClick: () -> Unit): View {
    val p = palette
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(16), dp(16), dp(16), dp(16))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(tv(label, 17f, p.fg, bold = true))
    if (sub != null) col.addView(tv(sub, 13f, p.mute))
    row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    if (value != null) row.addView(tv(value, 16f, p.mute, mono = true))
    row.addView(tv("›", 20f, p.mute).apply { setPadding(dp(10), 0, 0, 0) })
    row.setOnClickListener { onClick() }
    return row
}
