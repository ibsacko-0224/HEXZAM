package com.hexzam.app

/** Reconnaissance locale : vote sur le décalage temporel entre l'extrait et chaque morceau de la bibliothèque. */
object Matcher {
    data class Hit(val trackId: Long, val votes: Int, val second: Int, val offsetMs: Long)

    private const val OFFSET = 1_000_000

    fun match(db: HexDb, query: IntArray, minVotes: Int): Hit? {
        if (query.size < 2 * 20) return null                       // extrait trop pauvre
        val times = HashMap<Int, MutableList<Int>>()
        var i = 0
        while (i < query.size) { times.getOrPut(query[i]) { ArrayList() }.add(query[i + 1]); i += 2 }

        val votes = HashMap<Long, Int>()
        db.forEachHit(times.keys.toIntArray()) { hash, track, t ->
            val tqs = times[hash] ?: return@forEachHit
            for (tq in tqs) {
                val key = (track shl 32) or (t - tq + OFFSET).toLong()
                votes[key] = (votes[key] ?: 0) + 1
            }
        }
        if (votes.isEmpty()) return null

        var bestKey = 0L
        var best = 0
        val perTrack = HashMap<Long, Int>()
        for ((k, v) in votes) {
            val s = v + (votes[k - 1] ?: 0) + (votes[k + 1] ?: 0)  // tolère un décalage d'une trame
            val tr = k shr 32
            if (s > (perTrack[tr] ?: 0)) perTrack[tr] = s
            if (s > best) { best = s; bestKey = k }
        }
        val bestTrack = bestKey shr 32
        val second = perTrack.filterKeys { it != bestTrack }.values.maxOrNull() ?: 0
        if (best < minVotes || best < second * 3 / 2) return null
        val delta = (bestKey and 0xFFFFFFFFL) - OFFSET
        return Hit(bestTrack, best, second, delta * Fingerprint.FRAME_MS)
    }
}
