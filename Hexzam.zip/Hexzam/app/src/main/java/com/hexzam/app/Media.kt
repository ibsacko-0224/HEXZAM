package com.hexzam.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL

/** Chargement des pochettes (https uniquement), éventuellement en noir et blanc. */
object ImageLoader {
    private val cache = LruCache<String, Bitmap>(80)

    fun load(a: MainActivity, url: String, bw: Boolean, into: ImageView) {
        if (!url.startsWith("https://")) return
        if (bw) into.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) }) else into.clearColorFilter()
        cache.get(url)?.let { into.setImageBitmap(it); return }
        a.bg.execute {
            val dir = java.io.File(a.cacheDir, "covers").apply { mkdirs() }
            val f = java.io.File(dir, java.security.MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it) })
            try {
                if (f.exists()) {
                    BitmapFactory.decodeFile(f.path)?.let { b -> cache.put(url, b); a.runOnUiThread { into.setImageBitmap(b) }; return@execute }
                }
                if (Prefs.coverWifiOnly(a) && !Pending.onWifi(a)) return@execute
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 6000
                c.readTimeout = 8000
                val bmp = try { c.inputStream.use { BitmapFactory.decodeStream(it) } } finally { c.disconnect() }
                if (bmp != null) {
                    cache.put(url, bmp)
                    try { f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) } } catch (e: Exception) { }
                    a.runOnUiThread { into.setImageBitmap(bmp) }
                }
            } catch (e: Exception) { }
        }
    }
}

/** Lecture de l'extrait de 30 s fourni par le service (streaming). */
object Preview {
    private var mp: MediaPlayer? = null

    fun stop() {
        try { mp?.stop() } catch (e: Exception) { }
        mp?.release()
        mp = null
    }

    fun toggle(url: String, onState: (Boolean) -> Unit) {
        if (mp != null) { stop(); onState(false); return }
        val m = MediaPlayer()
        mp = m
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            m.setDataSource(url)
            m.setOnPreparedListener { it.start(); onState(true) }
            m.setOnCompletionListener { stop(); onState(false) }
            m.setOnErrorListener { _, _, _ -> stop(); onState(false); true }
            m.prepareAsync()
        } catch (e: Exception) { stop(); onState(false) }
    }
}
