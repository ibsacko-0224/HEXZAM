package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.IOException

fun Deezer.Track.toInfo() = TrackInfo(title, artist, album, "DEEZER", link, cover, preview, null, null)

/** Ligne de titre : pochette, titre, artiste, bouton ▶ (écoute dans l'application). */
fun MainActivity.musicRow(rank: Int?, cover: String?, title: String, artist: String, sub: String? = null, onPlay: (() -> Unit)?, onClick: () -> Unit): View {
    val p = palette
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(16), dp(10), dp(6), dp(10))
    if (rank != null) row.addView(tv("$rank", 15f, p.mute, bold = true, mono = true), LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.WRAP_CONTENT))
    row.addView(thumb(cover, 56))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(14), 0, dp(8), 0)
    col.addView(tv(title, 16f, p.fg, bold = true).apply { maxLines = 2 })
    col.addView(tv(artist, 13f, p.mute).apply { maxLines = 1 })
    if (sub != null) col.addView(tv(sub, 11f, p.mute, mono = true))
    row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    if (onPlay != null) row.addView(icon("▶") { onPlay() })
    row.setOnClickListener { onClick() }
    return row
}

/** Ajoute à [box] la liste des titres Deezer ; ▶ lance l'écoute et enchaîne toute la liste. */
fun MainActivity.addTrackRows(box: LinearLayout, tracks: List<Deezer.Track>, startRank: Boolean = false) {
    tracks.forEachIndexed { i, t ->
        box.addView(musicRow(if (startRank) i + 1 else null, t.cover, t.title, t.artist, t.album.ifEmpty { null },
            onPlay = if (t.preview != null) ({ Player.play(tracks, i) }) else null) { push(TrackScreen(this, t.toInfo())) })
        box.addView(hairline(palette))
    }
}

fun MainActivity.centered(text: String): View =
    tv(text, 15f, palette.mute).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(48), dp(24), 0) }

/** Page « Recherche » : cherchez n'importe quel titre ou artiste et écoutez un extrait de 30 s dans l'application. */
class SearchPage(private val app: MainActivity) {
    private val p = app.palette
    val view: View
    private val results = LinearLayout(app)
    private val handler = Handler(Looper.getMainLooper())
    private var seq = 0

    init {
        val root = FrameLayout(app)
        root.setBackgroundColor(p.bg)
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, app.dp(64), 0, app.dp(24))
        val box = EditText(app)
        box.hint = "Titre, artiste, album…"
        box.setHintTextColor(p.mute)
        box.setTextColor(p.fg)
        box.setSingleLine()
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        box.setPadding(app.dp(16), app.dp(14), app.dp(16), app.dp(14))
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        box.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { handler.removeCallbacksAndMessages(null); run(box.text.toString()); true } else false }
        box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { handler.removeCallbacksAndMessages(null); handler.postDelayed({ run(s?.toString() ?: "") }, 550) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), 0, app.dp(16), app.dp(8)) })
        results.orientation = LinearLayout.VERTICAL
        col.addView(results)
        root.addView(app.scroll(col), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(app.tv("Recherche", 20f, p.fg, bold = true).apply { gravity = Gravity.CENTER },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(36) })
        view = root
        hint()
    }

    private fun hint() {
        results.removeAllViews()
        results.addView(app.centered("Recherchez une musique, puis touchez ▶ pour l’écouter ici (extrait de 30 s). Touchez un titre pour ses détails, ses paroles et les autres morceaux de l’artiste."))
    }

    private fun run(q: String) {
        val query = q.trim()
        if (query.length < 2) { seq++; hint(); return }
        val my = ++seq
        results.removeAllViews()
        results.addView(app.centered("Recherche…"))
        app.bg.execute {
            val r = try { Result.success(Deezer.search(query, 40)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != seq) return@runOnUiThread
                results.removeAllViews()
                val list = r.getOrNull()
                when {
                    list == null -> results.addView(app.centered("Recherche impossible (${r.exceptionOrNull()?.message ?: "réseau"}). Vérifiez votre connexion."))
                    list.isEmpty() -> results.addView(app.centered("Aucun résultat pour « $query »."))
                    else -> app.addTrackRows(results, list)
                }
            }
        }
    }
}

class AlbumScreen(app: MainActivity, private val album: Deezer.Album) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, app.dp(24))
        val head = LinearLayout(app)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        head.addView(app.thumb(album.cover, 110))
        val t = LinearLayout(app)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(app.dp(16), 0, 0, 0)
        t.addView(app.tv(album.title, 20f, p.fg, bold = true))
        t.addView(app.tv(album.artist, 15f, p.fg))
        t.addView(app.tv(album.date ?: "", 12f, p.mute, mono = true))
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(head)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Album", app.scroll(col))
        list.addView(app.centered("Chargement…"))
        app.bg.execute {
            val r = try { Result.success(Deezer.albumTracks(album)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                list.removeAllViews()
                val tracks = r.getOrNull()
                if (tracks == null) { list.addView(app.centered("Impossible de charger l’album.")); return@runOnUiThread }
                list.addView(app.flatButton("▶ Tout écouter", p, true) { Player.play(tracks, 0) },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), 0, app.dp(16), app.dp(8)) })
                app.addTrackRows(list, tracks, startRank = true)
            }
        }
    }
}

/** Choix du pays parmi tous les pays du monde, avec recherche. */
class CountryPickerScreen(app: MainActivity, private val onPick: (String) -> Unit) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val search = EditText(app)
        search.hint = "Rechercher un pays"
        search.setHintTextColor(p.mute)
        search.setTextColor(p.fg)
        search.setSingleLine()
        search.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        search.setBackgroundColor(p.card)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString()?.trim()?.lowercase() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(12), app.dp(16), app.dp(4)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Choisir un pays", app.scroll(col))
        render("")
    }

    private fun render(q: String) {
        list.removeAllViews()
        for (c in Countries.all.filter { q.isEmpty() || it.name.lowercase().contains(q) }) {
            list.addView(app.menuRow(c.name, c.code.uppercase()) { app.pop(); onPick(c.code) })
            list.addView(app.hairline(p))
        }
    }
}
