package com.hexzam.app

import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.io.IOException

fun Deezer.Track.toInfo() = TrackInfo(title, artist, album, "DEEZER", link, cover, preview, null, null)

/** Ligne de titre : pochette, titre, artiste, bouton ▶ (écoute dans l'application). */
fun MainActivity.musicRow(rank: Int?, cover: String?, title: String, artist: String, sub: String? = null, onPlay: (() -> Unit)?, onClick: () -> Unit): View {
    val p = palette
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(16), dp(10), dp(6), dp(10))
    if (rank != null) row.addView(tv("$rank", 15f, p.mute, bold = true, mono = true), LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.WRAP_CONTENT))
    row.addView(thumb(cover, 56))
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(14), 0, dp(8), 0)
    col.addView(tv(title, 16f, p.fg, bold = true).apply { maxLines = 2 })
    col.addView(tv(artist, 13f, p.mute).apply { maxLines = 1 })
    if (sub != null) col.addView(tv(sub, 11f, p.mute, mono = true))
    row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    if (onPlay != null) row.addView(icon("▶") { onPlay() })
    row.setOnClickListener { onClick() }
    return row
}

/** Ajoute à [box] la liste des titres Deezer ; ▶ lance l'écoute et enchaîne toute la liste. */
fun MainActivity.addTrackRows(box: LinearLayout, tracks: List<Deezer.Track>, startRank: Boolean = false) {
    tracks.forEachIndexed { i, t ->
        box.addView(musicRow(if (startRank) i + 1 else null, t.cover, t.title, t.artist, t.album.ifEmpty { null },
            onPlay = if (t.preview != null) ({ Player.play(tracks, i) }) else null) { push(TrackScreen(this, t.toInfo())) })
        box.addView(hairline(palette))
    }
}

fun MainActivity.centered(text: String): View =
    tv(text, 15f, palette.mute).apply { gravity = Gravity.CENTER; setPadding(dp(24), dp(48), dp(24), 0) }

/** Page « Recherche » : cherchez n'importe quel titre ou artiste et écoutez un extrait de 30 s dans l'application. */
class SearchPage(private val app: MainActivity) {
    private val p = app.palette
    val view: View
    private val results = LinearLayout(app)
    private val handler = Handler(Looper.getMainLooper())
    private var seq = 0

    init {
        val root = FrameLayout(app)
        root.setBackgroundColor(p.bg)
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, app.dp(64), 0, app.dp(24))
        val box = EditText(app)
        box.hint = "Titre, artiste, album…"
        box.setHintTextColor(p.mute)
        box.setTextColor(p.fg)
        box.setSingleLine()
        box.imeOptions = EditorInfo.IME_ACTION_SEARCH
        box.setPadding(app.dp(16), app.dp(14), app.dp(16), app.dp(14))
        box.background = GradientDrawable().apply { setColor(p.card); setStroke(app.dp(1), p.fg) }
        box.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { handler.removeCallbacksAndMessages(null); run(box.text.toString()); true } else false }
        box.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { handler.removeCallbacksAndMessages(null); handler.postDelayed({ run(s?.toString() ?: "") }, 550) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), 0, app.dp(16), app.dp(8)) })
        results.orientation = LinearLayout.VERTICAL
        col.addView(results)
        root.addView(app.scroll(col), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(app.tv("Recherche", 20f, p.fg, bold = true).apply { gravity = Gravity.CENTER },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = app.dp(36) })
        view = root
        hint()
    }

    private fun hint() {
        results.removeAllViews()
        results.addView(app.centered("Recherchez une musique, puis touchez ▶ pour l’écouter ici (extrait de 30 s). Touchez un titre pour ses détails, ses paroles et les autres morceaux de l’artiste."))
    }

    private fun run(q: String) {
        val query = q.trim()
        if (query.length < 2) { seq++; hint(); return }
        val my = ++seq
        results.removeAllViews()
        results.addView(app.centered("Recherche…"))
        app.bg.execute {
            val r = try { Result.success(Deezer.search(query, 40)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (my != seq) return@runOnUiThread
                results.removeAllViews()
                val list = r.getOrNull()
                when {
                    list == null -> results.addView(app.centered("Recherche impossible (${r.exceptionOrNull()?.message ?: "réseau"}). Vérifiez votre connexion."))
                    list.isEmpty() -> results.addView(app.centered("Aucun résultat pour « $query »."))
                    else -> app.addTrackRows(results, list)
                }
            }
        }
    }
}

/** Nouveautés du moment, par genre (Rap / Hip-Hop, musique africaine, pop…), dans le monde entier. */
class NewReleasesScreen(app: MainActivity) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val chips = LinearLayout(app)
    private val list = LinearLayout(app)
    private var selected = 0L
    private var genres: List<Deezer.Genre> = emptyList()

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        col.addView(hs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(12), app.dp(12), app.dp(12), app.dp(4)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Nouveautés", app.scroll(col))
        drawChips()
        load()
        app.bg.execute {
            val g = try { Deezer.genres() } catch (e: IOException) { emptyList() }
            app.runOnUiThread { genres = g; drawChips() }
        }
    }

    private fun drawChips() {
        chips.removeAllViews()
        fun chip(id: Long, label: String) {
            val on = id == selected
            val t = app.tv(label.uppercase(), 12f, if (on) p.bg else p.fg, bold = true, mono = true)
            t.setPadding(app.dp(14), app.dp(9), app.dp(14), app.dp(9))
            t.background = GradientDrawable().apply { setColor(if (on) p.fg else p.bg); setStroke(app.dp(1), p.fg) }
            t.setOnClickListener { selected = id; drawChips(); load() }
            chips.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = app.dp(8) })
        }
        chip(0L, "Tous les genres")
        genres.forEach { chip(it.id, it.name) }
    }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val g = selected
        app.bg.execute {
            val r = try { Result.success(Deezer.releases(g)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                if (g != selected) return@runOnUiThread
                list.removeAllViews()
                val albums = r.getOrNull()
                when {
                    albums == null -> list.addView(app.centered("Impossible de charger les nouveautés (${r.exceptionOrNull()?.message ?: "réseau"})."))
                    albums.isEmpty() -> list.addView(app.centered("Aucune nouveauté pour ce genre pour l’instant."))
                    else -> for (a in albums) {
                        list.addView(app.musicRow(null, a.cover, a.title, a.artist, a.date, onPlay = null) { app.push(AlbumScreen(app, a)) })
                        list.addView(app.hairline(p))
                    }
                }
            }
        }
    }
}

class AlbumScreen(app: MainActivity, private val album: Deezer.Album) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, app.dp(24))
        val head = LinearLayout(app)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        head.addView(app.thumb(album.cover, 110))
        val t = LinearLayout(app)
        t.orientation = LinearLayout.VERTICAL
        t.setPadding(app.dp(16), 0, 0, 0)
        t.addView(app.tv(album.title, 20f, p.fg, bold = true))
        t.addView(app.tv(album.artist, 15f, p.fg))
        t.addView(app.tv(album.date ?: "", 12f, p.mute, mono = true))
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(head)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Album", app.scroll(col))
        list.addView(app.centered("Chargement…"))
        app.bg.execute {
            val r = try { Result.success(Deezer.albumTracks(album)) } catch (e: IOException) { Result.failure(e) }
            app.runOnUiThread {
                list.removeAllViews()
                val tracks = r.getOrNull()
                if (tracks == null) { list.addView(app.centered("Impossible de charger l’album.")); return@runOnUiThread }
                list.addView(app.flatButton("▶ Tout écouter", p, true) { Player.play(tracks, 0) },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), 0, app.dp(16), app.dp(8)) })
                app.addTrackRows(list, tracks, startRank = true)
            }
        }
    }
}

/** Choix du pays parmi tous les pays du monde, avec recherche. */
class CountryPickerScreen(app: MainActivity, private val onPick: (String) -> Unit) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val list = LinearLayout(app)

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val search = EditText(app)
        search.hint = "Rechercher un pays"
        search.setHintTextColor(p.mute)
        search.setTextColor(p.fg)
        search.setSingleLine()
        search.setPadding(app.dp(16), app.dp(12), app.dp(16), app.dp(12))
        search.setBackgroundColor(p.card)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString()?.trim()?.lowercase() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(16), app.dp(12), app.dp(16), app.dp(4)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame("Choisir un pays", app.scroll(col))
        render("")
    }

    private fun render(q: String) {
        list.removeAllViews()
        for (c in Countries.all.filter { q.isEmpty() || it.name.lowercase().contains(q) }) {
            list.addView(app.menuRow(c.name, c.code.uppercase()) { app.pop(); onPick(c.code) })
            list.addView(app.hairline(p))
        }
    }
}

/** Un pays : classement Apple Music (si le pays en a un) et découvertes par style (rap, afro, traditionnel…). */
class CountryScreen(app: MainActivity, private val code: String) : Screen(app) {
    private val p = app.palette
    override val view: View
    private val chips = LinearLayout(app)
    private val list = LinearLayout(app)
    private val name = Countries.name(code)
    private val styles: List<Pair<String, String>> = buildList {
        add("Top" to "#top")
        add("Tous" to "")
        add("Rap / Hip-Hop" to "rap hip hop")
        add("Afro" to "afro")
        add("Pop" to "pop")
        add("R&B" to "r&b")
        if (code == "gn") add("Mamaya" to "mamaya")
        add("Traditionnel" to "traditionnel")
    }
    private var selected = 0

    init {
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        col.addView(hs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(app.dp(12), app.dp(12), app.dp(12), app.dp(4)) })
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        view = app.frame(name, app.scroll(col))
        drawChips()
        load()
    }

    private fun drawChips() {
        chips.removeAllViews()
        styles.forEachIndexed { i, s ->
            val on = i == selected
            val t = app.tv(s.first.uppercase(), 12f, if (on) p.bg else p.fg, bold = true, mono = true)
            t.setPadding(app.dp(14), app.dp(9), app.dp(14), app.dp(9))
            t.background = GradientDrawable().apply { setColor(if (on) p.fg else p.bg); setStroke(app.dp(1), p.fg) }
            t.setOnClickListener { selected = i; drawChips(); load() }
            chips.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = app.dp(8) })
        }
    }

    private fun load() {
        list.removeAllViews()
        list.addView(app.centered("Chargement…"))
        val my = selected
        val kw = styles[my].second
        app.bg.execute {
            if (kw == "#top") {
                val r = try { Result.success(Charts.fetch(code, "songs")) } catch (e: IOException) { Result.failure(e) }
                app.runOnUiThread { if (my == selected) showChart(r) }
            } else {
                val q = ("$name $kw").trim()
                val r = try { Result.success(Deezer.search(q, 40)) } catch (e: IOException) { Result.failure(e) }
                app.runOnUiThread { if (my == selected) showTracks(r, q) }
            }
        }
    }

    private fun showChart(r: Result<List<Charts.Item>>) {
        list.removeAllViews()
        val items = r.getOrNull()
        if (items == null) {
            list.addView(app.centered("Pas de classement officiel Apple Music pour $name. Essayez « Tous », « Rap / Hip-Hop » ou « Afro » : ce sont des découvertes par mots-clés."))
            return
        }
        for (it in items) {
            list.addView(app.musicRow(it.rank, it.cover, it.title, it.artist, onPlay = null) {
                app.push(TrackScreen(app, TrackInfo(it.title, it.artist, "", "TOP · " + name.uppercase(), it.url, it.cover, null, it.genre, null)))
            })
            list.addView(app.hairline(p))
        }
    }

    private fun showTracks(r: Result<List<Deezer.Track>>, q: String) {
        list.removeAllViews()
        val tracks = r.getOrNull()
        when {
            tracks == null -> list.addView(app.centered("Impossible de charger (${r.exceptionOrNull()?.message ?: "réseau"})."))
            tracks.isEmpty() -> list.addView(app.centered("Rien trouvé pour « $q »."))
            else -> {
                list.addView(app.tv("Découvertes par mots-clés : « $q ». Ce n’est pas un classement officiel.", 12f, p.mute).apply { setPadding(app.dp(16), app.dp(6), app.dp(16), app.dp(8)) })
                app.addTrackRows(list, tracks)
            }
        }
    }
}
