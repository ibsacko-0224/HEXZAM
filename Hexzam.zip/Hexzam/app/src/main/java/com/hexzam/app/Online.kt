package com.hexzam.app

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Reconnaissance en ligne OPTIONNELLE (service AudD). Seul l'extrait audio enregistré est envoyé,
 * uniquement si l'utilisateur a activé l'option ET saisi sa clé, et seulement quand la recherche locale échoue.
 */
object Online {
    data class Result(val title: String, val artist: String, val album: String, val link: String?, val cover: String? = null, val preview: String? = null, val genre: String? = null)

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

    @Throws(IOException::class)
    fun recognize(token: String, wav: ByteArray): Result? {
        val boundary = "----hexzam" + System.currentTimeMillis()
        val conn = URL("https://api.audd.io/").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 20000
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val body = ByteArrayOutputStream()
            fun field(name: String, value: String) {
                body.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("api_token", token)
            field("return", "apple_music,spotify")
            body.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"extrait.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray())
            body.write(wav)
            body.write("\r\n--$boundary--\r\n".toByteArray())
            conn.setFixedLengthStreamingMode(body.size())
            conn.outputStream.use { it.write(body.toByteArray()) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (e: Exception) { throw IOException("Réponse inattendue du service (HTTP $code)") }
            if (json.optString("status") != "success") {
                val msg = json.optJSONObject("error")?.str("error_message")?.ifEmpty { null }
                throw IOException(msg ?: "Erreur du service (HTTP $code)")
            }
            val r = json.optJSONObject("result") ?: return null
            val title = r.str("title")
            if (title.isEmpty()) return null
            var cover: String? = null
            var preview: String? = null
            var genre: String? = null
            fun https(s: String?) = s?.takeIf { it.startsWith("https://") }
            r.optJSONObject("apple_music")?.let { am ->
                cover = https(am.optJSONObject("artwork")?.str("url")?.replace("{w}", "600")?.replace("{h}", "600"))
                preview = https(am.optJSONArray("previews")?.optJSONObject(0)?.str("url"))
                genre = am.optJSONArray("genreNames")?.optString(0)?.takeIf { it.isNotEmpty() && it != "Music" }
            }
            r.optJSONObject("spotify")?.let { sp ->
                if (cover == null) cover = https(sp.optJSONObject("album")?.optJSONArray("images")?.optJSONObject(0)?.str("url"))
                if (preview == null) preview = https(sp.str("preview_url"))
            }
            return Result(title, r.str("artist"), r.str("album"), r.str("song_link").ifEmpty { null }, cover, preview, genre)
        } finally {
            conn.disconnect()
        }
    }
}
