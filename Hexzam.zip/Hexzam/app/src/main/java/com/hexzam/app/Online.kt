package com.hexzam.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Reconnaissance en ligne OPTIONNELLE (service AudD). Seul l'extrait audio enregistré est envoyé,
 * uniquement si l'utilisateur a activé l'option ET saisi sa clé, et seulement quand la recherche locale échoue.
 */
object Online {
    data class Result(val title: String, val artist: String, val album: String, val link: String?, val cover: String? = null, val preview: String? = null, val genre: String? = null)

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

    @Throws(IOException::class)
    fun recognize(token: String, wav: ByteArray): Result? {
        val boundary = "----hexzam" + System.currentTimeMillis()
        val conn = URL("https://api.audd.io/").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 20000
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val body = ByteArrayOutputStream()
            fun field(name: String, value: String) {
                body.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("api_token", token)
            field("return", "apple_music,spotify")
            body.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"extrait.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray())
            body.write(wav)
            body.write("\r\n--$boundary--\r\n".toByteArray())
            conn.setFixedLengthStreamingMode(body.size())
            conn.outputStream.use { it.write(body.toByteArray()) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (e: Exception) { throw IOException("Réponse inattendue du service (HTTP $code)") }
            if (json.optString("status") != "success") {
                val msg = json.optJSONObject("error")?.str("error_message")?.ifEmpty { null }
                throw IOException(msg ?: "Erreur du service (HTTP $code)")
            }
            val r = json.optJSONObject("result") ?: return null
            val title = r.str("title")
            if (title.isEmpty()) return null
            var cover: String? = null
            var preview: String? = null
            var genre: String? = null
            fun https(s: String?) = s?.takeIf { it.startsWith("https://") }
            r.optJSONObject("apple_music")?.let { am ->
                cover = https(am.optJSONObject("artwork")?.str("url")?.replace("{w}", "600")?.replace("{h}", "600"))
                preview = https(am.optJSONArray("previews")?.optJSONObject(0)?.str("url"))
                genre = am.optJSONArray("genreNames")?.optString(0)?.takeIf { it.isNotEmpty() && it != "Music" }
            }
            r.optJSONObject("spotify")?.let { sp ->
                if (cover == null) cover = https(sp.optJSONObject("album")?.optJSONArray("images")?.optJSONObject(0)?.str("url"))
                if (preview == null) preview = https(sp.str("preview_url"))
            }
            return Result(title, r.str("artist"), r.str("album"), r.str("song_link").ifEmpty { null }, cover, preview, genre)
        } finally {
            conn.disconnect()
        }
    }

    private fun post(url: String, form: String): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.outputStream.use { it.write(form.toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            val json = try { JSONObject(text) } catch (e: Exception) { throw IOException("Réponse inattendue du service (HTTP $code)") }
            if (json.optString("status") != "success") {
                throw IOException(json.optJSONObject("error")?.str("error_message")?.ifEmpty { null } ?: "Erreur du service (HTTP $code)")
            }
            return json
        } finally { conn.disconnect() }
    }

    /** Paroles d'un titre (service AudD, certains titres seulement). null si le service n'en a pas pour ce titre. */
    @Throws(IOException::class)
    fun findLyrics(token: String, artist: String, title: String): String? {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        val json = post("https://api.audd.io/findLyrics/", "api_token=${enc(token)}&q=${enc("$artist $title".trim())}")
        val arr = when (val r = json.opt("result")) {
            is JSONArray -> r
            is JSONObject -> JSONArray().put(r)
            else -> return null
        }
        val core = title.substringBefore('(').trim().lowercase()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val lyrics = o.str("lyrics")
            // On exige un titre qui correspond, pour ne jamais afficher les paroles d'une autre chanson.
            if (lyrics.isNotBlank() && (core.isEmpty() || o.str("title").lowercase().contains(core))) return lyrics.trim()
        }
        return null
    }

    /** Vérifie la clé en envoyant 1 s de silence : « Wrong API token » = refusée. Consomme une requête. */
    @Throws(IOException::class)
    fun checkKey(token: String) { recognize(token, Wav.encode(ByteArray(16000), 8000)) }
}
